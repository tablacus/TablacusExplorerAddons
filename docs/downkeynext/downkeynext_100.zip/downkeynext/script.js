if (window.Addon == 1) {
	const Addon_Id = "downkeynext";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
