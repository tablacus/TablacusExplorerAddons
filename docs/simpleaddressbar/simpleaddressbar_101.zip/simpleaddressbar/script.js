﻿var Addon_Id = "simpleaddressbar";
var Default = "ToolBar2Center";

if (Addon == 1) {
	g_simpleaddressbar_ChangeView = ChangeView;

	var s = '<input id="simpleaddressbar" type="text" onkeydown="return KeyDownSimpleAddressBar(this)" onfocus="this.select()" style="width: 100%; position: relative; top: -1px;">';

	var Location = null;
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		Location = items[0].getAttribute("Location");
	}
	if (!Location) {
		Location = Default;
	}
	var o = document.getElementById(Location);
	o.innerHTML += s;
	o.style.display = "block";
	external.Data["Locations"].push(Location + "\t" + Addon_Id);

	g_simpleaddressbar = o;

	ChangeView = function(FV)
	{
		if (FV.FolderItem) {
			document.F.simpleaddressbar.value = api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORADDRESSBAR | SHGDN_FORPARSING);
		}
		if (g_simpleaddressbar_ChangeView) {
			g_simpleaddressbar_ChangeView(FV);
		}
	}

	SetAddrss = function (s)
	{
		document.F.addressbar.value = s;
	}

	GetAddrss = function ()
	{
		return document.F.addressbar.value;
	}
}

function KeyDownSimpleAddressBar(o)
{
	if (event.keyCode == VK_RETURN) {
		NavigateSimpleAddressbar();
		return false;
	}
	return true;
}

function NavigateSimpleAddressbar()
{
	var o = document.F.simpleaddressbar;
	var p = GetPos(o);
	var pt = api.Memory("POINT");
	pt.x = screenLeft + p.x;
	pt.y = screenTop + p.y + o.offsetHeight;
	window.Input = o.value;
	if (ExecMenu(external.Ctrl(CTRL_WB), "Alias", pt, 2) != S_OK) {
		Navigate(o.value, external.Data["Conf_NewTab"]);
	}
}

