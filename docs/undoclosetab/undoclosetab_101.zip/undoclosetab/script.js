﻿var Addon_Id = "undoclosetab";

(function () {
	var items = te.Data.Addons.getElementsByTagName(Addon_Id);
	if (items.length) {
		var item = items[0];
		if (!item.getAttribute("Set")) {
			item.setAttribute("MenuExec", 1);
			item.setAttribute("Menu", "Tabs");
			item.setAttribute("MenuPos", 0);
			item.setAttribute("MenuName", "&Undo Close Tab");

			item.setAttribute("KeyExec", 1);
			item.setAttribute("Key", "Shift+Ctrl+T");
			item.setAttribute("KeyOn", "All");

			item.setAttribute("MouseOn", "List");
		}
	}
	if (window.Addon == 1) {
		Addons.UndoCloseTab =
		{
			MAX: 100,

			Exec: function (Ctrl, pt)
			{
				var FV = GetFolderView(Ctrl, pt);
				if (FV && te.Data.dbClosedTabs.length) {
					var s = te.Data.dbClosedTabs.shift();
					if (typeof(s) == "string") {
						var a = s.split(/\n/);
						if (a.length > 1) {
							s = te.FolderItems(a.length - 1);
							s.Index = a.pop();
							for (i in a) {
								s.AddItem(a[i]);
							}
						}
					}
					FV.Navigate(s, SBSP_NEWBROWSER);
				}
			}
		}

		te.Data.dbClosedTabs = [];

		var xmlfile = fso.BuildPath(te.Data.DataFolder, "config\\closedtabs.xml");
		var xml = te.CreateObject("Msxml2.DOMDocument");
		xml.async = false;
		xml.load(xmlfile);

		var items = xml.getElementsByTagName('Item');
		for (i = items.length - 1; i >= 0; i--) {
			te.Data.dbClosedTabs.unshift(items[i].text);
		}
		xml = null;

		AddEvent("CloseView", function (Ctrl)
		{
			if (Ctrl.FolderItem) {
				te.Data.dbClosedTabs.unshift(Ctrl.History);
				te.Data.dbClosedTabs.splice(Addons.UndoCloseTab.MAX, MAXINT);
			}
			return S_OK;
		});

		AddEvent("Finalize", function ()
		{
			var xmlfile = fso.BuildPath(te.Data.DataFolder, "config\\closedtabs.xml");
			var xml = te.CreateObject("Msxml2.DOMDocument");
			xml.async = false;

			xml.appendChild(xml.createProcessingInstruction("xml", 'version="1.0" encoding="UTF-8"'));

			var root = xml.createElement("TablacusExplorer");
			var db = te.Data.dbClosedTabs;
			while (db.length) {
				var item = xml.createElement("Item");
				var s = db.shift();
				if (typeof(s) != "string") {
					var a = [];
					for (var i = 0; i < s.Count; i++) {
						a.push(api.GetDisplayNameOf(s.Item(i), SHGDN_FORPARSING | SHGDN_FORPARSINGEX));
					}
					a.push(s.Index);
					s = a.join("\n");
				}
				item.text = s;
				root.appendChild(item);
				item = null;
			}
			xml.appendChild(root);
			xml.save(xmlfile);
			xml = null;
		});


		if (items.length) {
			var s = item.getAttribute("MenuName");
			if (s && s != "") {
				Addons.UndoCloseTab.strName = s;
			}
			//Menu
			if (item.getAttribute("MenuExec")) {
				Addons.UndoCloseTab.nPos = api.LowPart(item.getAttribute("MenuPos"));
				AddEvent(item.getAttribute("Menu"), function (Ctrl, hMenu, nPos)
				{
					api.InsertMenu(hMenu, Addons.UndoCloseTab.nPos, MF_BYPOSITION | MF_STRING | ((te.Data.dbClosedTabs.length) ? MF_ENABLED : MF_DISABLED), ++nPos, GetText(Addons.UndoCloseTab.strName));
					ExtraMenuCommand[nPos] = Addons.UndoCloseTab.Exec;
					return nPos;
				});
			}
			//Key
			if (item.getAttribute("KeyExec")) {
				SetKeyExec(item.getAttribute("KeyOn"), item.getAttribute("Key"), "Addons.UndoCloseTab.Exec();", "JScript");
			}
			//Mouse
			if (item.getAttribute("MouseExec")) {
				SetGestureExec(item.getAttribute("MouseOn"), item.getAttribute("Mouse"), "Addons.UndoCloseTab.Exec();", "JScript");
			}

			AddTypeEx("Add-ons", "Undo Close Tab", Addons.UndoCloseTab.Exec);
		}
	}
})();
