﻿if (Addon == 1) {
	MAX_UNDO_TABS = 100;
	g_Undoclosetab_CloseView = window.CloseView;
	g_Undoclosetab_Finalize = window.Finalize;
	g_Undoclosetab_ExtraMenus = ExtraMenus["Tabs"];

	external.Data.dbClosedTabs = new Array();

	var xmlfile = fso.BuildPath(external.Data.DataFolder, "config\\closedtabs.xml");
	var xml = external.CreateObject("Msxml2.DOMDocument");
	xml.async = false;
	xml.load(xmlfile);

	var items = xml.getElementsByTagName('Item');
	for (i = items.length - 1; i >= 0; i--) {
		external.Data.dbClosedTabs.unshift(items[i].text);
	}
	xml = null;

	window.CloseView = function (Ctrl)
	{
		var hr = S_OK;
		if (g_Undoclosetab_CloseView) {
			hr = g_Undoclosetab_CloseView(Ctrl);
		}
		if (Ctrl.FolderItem) {
			external.Data.dbClosedTabs.unshift(Ctrl.FolderItem);
			external.Data.dbClosedTabs.splice(MAX_UNDO_TABS, MAXINT);
		}
		return hr;
	}

	window.Finalize = function ()
	{
		var xmlfile = fso.BuildPath(external.Data.DataFolder, "config\\closedtabs.xml");
		var xml = external.CreateObject("Msxml2.DOMDocument");
		xml.async = false;

		xml.appendChild(xml.createProcessingInstruction("xml", 'version="1.0" encoding="UTF-8"'));

		var root = xml.createElement("TablacusExplorer");
		var db = external.Data.dbClosedTabs;
		while (db.length) {
			var item = xml.createElement("Item");
			var s = db.shift();
			if (typeof(s) != "string") {
				s = api.GetDisplayNameOf(s, SHGDN_FORPARSING | SHGDN_FORPARSINGEX);
			}
			item.text = s;
			root.appendChild(item);
			item = null;
		}
		xml.appendChild(root);
		xml.save(xmlfile);
		xml = null;

		if (g_Undoclosetab_Finalize) {
			return g_Undoclosetab_Finalize();
		}
	}

	ExtraMenus["Tabs"] = function (Ctrl, hMenu, nPos)
	{
		var uFlags = 0;
		if (external.Data.dbClosedTabs.length == 0) {
			uFlags = MF_GRAYED;
		}
		api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_STRING | uFlags, ++nPos, GetText('&Undo Close Tab'));
		ExtraMenuCommand[nPos] = function (Ctrl)
		{
			Ctrl.Selected.Navigate(external.Data.dbClosedTabs.shift(), SBSP_NEWBROWSER);
		}

		if (g_Undoclosetab_ExtraMenus) {
			nPos = g_Undoclosetab_ExtraMenus(Ctrl, hMenu, nPos);
		}
		return nPos;
	}
}
