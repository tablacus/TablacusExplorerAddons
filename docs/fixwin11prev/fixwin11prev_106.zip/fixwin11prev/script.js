if (window.Addon == 1) {
	const Addon_Id = "fixwin11prev";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
