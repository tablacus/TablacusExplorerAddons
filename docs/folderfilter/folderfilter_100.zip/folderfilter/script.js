if (window.Addon == 1) {
	const Addon_Id = "folderfilter";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
