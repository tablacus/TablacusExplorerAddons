﻿var Addon_Id = "refresh";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var s;
	if (window.IconSize == 16) {
		s = '<img alt="Refresh" src="../image/toolbar/s_2_3.png" bitmap="ieframe.dll,206,16,3">';
	}
	else {
		s = '<img alt="Refresh" src="../image/toolbar/m_2_3.png" bitmap="ieframe.dll,204,24,3">';
	}
	s = '<span class="button" onclick="Refresh()" onmouseover="MouseOver(this)" onmouseout="MouseOut()">' + s + '</span> ';

	SetAddon(Addon_Id, Default, s);
}
