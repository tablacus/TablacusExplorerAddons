if (window.Addon == 1) {
	const Addon_Id = "itemscount";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
