if (window.Addon == 1) {
	g_tasktray =
	{
		RestoreFromTray: window.RestoreFromTray,
		WM: TEM_APP++,

		CreateIcon: function (f)
		{
			if (f && te.Data.TrayIcon) {
				return;
			}
			te.Data.TrayIcon = true;
			if (!te.Data.TaskBarRecreate) {
				te.Data.TaskBarRecreate = api.RegisterWindowMessage("TaskbarCreated");
			}
			var NotifyData = api.Memory("NOTIFYICONDATA");
			NotifyData.cbSize = NotifyData.Size;
			NotifyData.hWnd = te.hwnd;
			NotifyData.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
			NotifyData.uCallbackMessage = this.WM;
			NotifyData.hIcon = api.GetClassLongPtr(te.hwnd, GCLP_HICONSM);
			NotifyData.szTip = "Tablacus Explorer";
			var nDog = 5;
			while (!api.Shell_NotifyIcon(NIM_ADD, NotifyData) && nDog-- >= 0) {
				api.Sleep(100);
			}
			api.DestroyIcon(NotifyData.hIcon);
			api.ShowWindow(te.hwnd, SW_HIDE);
		},

		DeleteIcon: function ()
		{
			if (te.Data.TrayIcon) {
				te.Data.TrayIcon = false;

				var NotifyData = api.Memory("NOTIFYICONDATA");
				NotifyData.cbSize = NotifyData.Size;
				NotifyData.hWnd = te.hwnd;
				var nDog = 5;
				while (!api.Shell_NotifyIcon(NIM_DELETE, NotifyData) && nDog-- >= 0) {
					api.Sleep(100);
				}
			}
		}

	}

	AddEvent("SystemMessage", function (Ctrl, hwnd, msg, wParam, lParam)
	{
		if (Ctrl.Type == CTRL_TE) {
			if (msg == WM_SYSCOMMAND) {
				if (wParam >= 0xf000) {
					switch (wParam & 0xFFF0) {
						case SC_MINIMIZE:
							var items = te.Data.Addons.getElementsByTagName("tasktray");
							if (items.length) {
								var item = items[0];
								if (item.getAttribute("MinimizeToTray")) {
							   	g_tasktray.CreateIcon(true);
									return 1;
								}
							}
							break;
						case SC_CLOSE:
							var items = te.Data.Addons.getElementsByTagName("tasktray");
							if (items.length) {
								var item = items[0];
								if (item.getAttribute("CloseToTray")) {
							   	g_tasktray.CreateIcon(true);
									return 1;
								}
							}
							break;
					}
				}
			}
			else if (msg == WM_DESTROY) {
				g_tasktray.DeleteIcon();
			}
		}
	});

	AddEvent("AppMessage", function (Ctrl, hwnd, msg, wParam, lParam)
	{
		switch (msg) {
			case g_tasktray.WM:
				switch (lParam) {
					case WM_LBUTTONUP:
					case NIN_SELECT:
						api.SetForegroundWindow(te.hwnd);
						api.PostMessage(te.hwnd, WM_NULL, 0, 0);
						RestoreFromTray();
						break;
					case WM_RBUTTONUP:
					case WM_CONTEXTMENU:
						pt = api.Memory("POINT");
						api.GetCursorPos(pt);
						api.SetForegroundWindow(te.hwnd);
						api.PostMessage(te.hwnd, WM_NULL, 0, 0);
						ExecMenu(external, "TaskTray", pt, 0);
						break;
					case WM_QUERYENDSESSION:
						return 1;
					default:
						if (lParam == te.Data.TaskBarRecreate) {
							g_tasktray.CreateIcon(false);
						}
						break;
				}
				return S_OK;
		}
	});

	RestoreFromTray = function ()
	{
		g_tasktray.DeleteIcon();
		return g_tasktray.RestoreFromTray ? g_tasktray.RestoreFromTray() : S_OK;
	}


}
