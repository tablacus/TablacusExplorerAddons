﻿if (Addon == 1) {
	g_tasktray_AppMessage = external.OnAppMessage;
	g_tasktray_SystemMessage = external.OnSystemMessage;

	external.OnSystemMessage = function (Ctrl, hwnd, msg, wParam, lParam)
	{
		if (Ctrl.Type == CTRL_TE) {
			if (msg == WM_SYSCOMMAND) {
				if (wParam >= 0xf000) {
					switch (wParam & 0xFFF0) {
						case SC_MINIMIZE:
							var items = external.Data["Addons"].getElementsByTagName("tasktray");
							if (items.length) {
								var item = items[0];
								if (item.getAttribute("MinimizeToTray")) {
							   	CreateTaskBarIcon();
									return 1;
								}
							}
							break;
						case SC_CLOSE:
							var items = external.Data["Addons"].getElementsByTagName("tasktray");
							if (items.length) {
								var item = items[0];
								if (item.getAttribute("CloseToTray")) {
							   	CreateTaskBarIcon();
									return 1;
								}
							}
							break;
					}
				}
			}
			else if (msg == WM_DESTROY) {
				DeleteTaskBarIcon();
			}
		}
		if (g_tasktray_SystemMessage) {
			return g_tasktray_SystemMessage(Ctrl, hwnd, msg, wParam, lParam);
		}
	}

	external.OnAppMessage = function (Ctrl, hwnd, msg, wParam, lParam)
	{
		switch (msg) {
			case TEM_TRAYICON:
				switch (lParam) {
					case WM_LBUTTONUP:
					case NIN_SELECT:
						api.SetForegroundWindow(external.hwnd);
						api.PostMessage(external.hwnd, WM_NULL, 0, 0);
						RestoreFromTray();
						break;
					case WM_RBUTTONUP:
					case WM_CONTEXTMENU:
						pt = api.Memory("POINT");
						api.GetCursorPos(pt);
						api.SetForegroundWindow(external.hwnd);
						api.PostMessage(external.hwnd, WM_NULL, 0, 0);
						ExecMenu(external, "TaskTray", pt, 0);
						break;
					case WM_QUERYENDSESSION:
						return 1;
					default:
						if (lParam == external.Data["TaskBarRecreate"]) {
							CreateTaskBarIcon(false);
						}
						break;
				}
				return S_OK;
		}
		if (g_tasktray_AppMessage) {
			return g_tasktray_AppMessage(Ctrl, hwnd, msg, wParam, lParam);
		}
		return S_FALSE;
	}
}

function CreateTaskBarIcon(f)
{
	if (f && external.Data["TrayIcon"]) {
		return;
	}
	external.Data["TrayIcon"] = true;
	if (!external.Data["TaskBarRecreate"]) {
		external.Data["TaskBarRecreate"] = api.RegisterWindowMessage("TaskbarCreated");
	}
	var NotifyData = api.Memory("NOTIFYICONDATA");
	NotifyData.cbSize = NotifyData.Size;
	NotifyData.hWnd = external.hwnd;
	NotifyData.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	NotifyData.uCallbackMessage = TEM_TRAYICON;
	NotifyData.hIcon = api.GetClassLongPtr(external.hwnd, GCLP_HICONSM);
	NotifyData.szTip = "Tablacus Explorer";
	var nDog = 5;
	while (!api.Shell_NotifyIcon(NIM_ADD, NotifyData) && nDog-- >= 0) {
		api.Sleep(100);
	}
	api.DestroyIcon(NotifyData.hIcon);
	api.ShowWindow(external.hwnd, SW_HIDE);
}

function DeleteTaskBarIcon()
{
	if (external.Data["TrayIcon"]) {
		external.Data["TrayIcon"] = false;

		var NotifyData = api.Memory("NOTIFYICONDATA");
		NotifyData.cbSize = NotifyData.Size;
		NotifyData.hWnd = external.hwnd;
		var nDog = 5;
		while (!api.Shell_NotifyIcon(NIM_DELETE, NotifyData) && nDog-- >= 0) {
			api.Sleep(100);
		}
	}
}
