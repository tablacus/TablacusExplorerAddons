﻿returnValue = false;

function InitOptions()
{
	var InstalledFolder = fso.GetParentFolderName(api.GetModuleFileName(null));
	LoadLang2(fso.BuildPath(fso.GetParentFolderName(api.GetModuleFileName(null)), "addons\\tasktray\\lang\\" + te.Data.Conf_Lang + ".xml"));

	ApplyLang(document);
	info = GetAddonInfo("tasktray");
	document.title = info.Name;
	var items = te.Data.Addons.getElementsByTagName("tasktray");
	if (items.length) {
		var item = items[0];
		document.F.MinimizeToTray.checked = item.getAttribute("MinimizeToTray");
		document.F.CloseToTray.checked = item.getAttribute("CloseToTray");
	}
}

function SetOptions()
{
	var items = te.Data.Addons.getElementsByTagName("tasktray");
	if (items.length) {
		var item = items[0];
		item.setAttribute("MinimizeToTray", document.F.MinimizeToTray.checked ? 1 : "");
		item.setAttribute("CloseToTray", document.F.CloseToTray.checked ? 1 : "");
		returnValue = true;
	}
	window.close();
}
