﻿var Addon_Id = "tabgroups";
var Default = "ToolBar5Center";

if (window.Addon == 1) {
	g_tabgroups =
	{
		Name: null,
		Index: 1,
		Click: 0,
		nDrag: 0,
		nDrop: 0,
		WheelButton: 0,
		tid: null,
		pt: api.Memory("POINT"),
		onload: window.onload,
		beforeunload: window.onbeforeunload,
		Finalize: window.Finalize,
		DragEnter: te.OnDragEnter,
		DragOver: te.OnDragOver,
		Drop: te.OnDrop,
		DragLeave: te.OnDragLeave,

		Init: function ()
		{
			var s = []
			s.push('<span id="tabgroups">tabgroups</span>');
			s.push('<input type="button" class="tab" value="+" onclick="return g_tabgroups.Add()" hidefocus="true">');
			SetAddon(Addon_Id, Default, s.join(""));
			this.Name = [''];
			xml = OpenXml("tabgroups.xml", true, true);
			var items = xml.getElementsByTagName('Item');
			for (i = 0; i < items.length; i++) {
				this.Name.push(items[i].getAttribute("Name"));
			}
			items = xml.getElementsByTagName('Index');
			if (items.length) {
				this.Click = items[0].text;
			}
			this.Arrange();
		},

		Save: function ()
		{
			var xmlfile = fso.BuildPath(external.Data.DataFolder, "config\\tabgroups.xml");
			var xml = CreateXml();
			var root = xml.createElement("TablacusExplorer");
			for (var i = 1; i < this.Name.length; i++) {
				var item = xml.createElement("Item");
				item.setAttribute("Name", this.Name[i]);
				root.appendChild(item);
			}
			var item = xml.createElement("Index");
			item.text = this.Index;
			root.appendChild(item);
			xml.appendChild(root);
			xml.save(xmlfile);
		},

		Arrange: function ()
		{
			this.Fix();
			var s = [];
			for (var i = 1; i < this.Name.length; i++) {
				this.Tab(s, i);
			}
			document.getElementById("tabgroups").innerHTML = s.join("");
			this.Change();
		},

		Tab: function (s, i)
		{
			s.push('<input type="button" style="border: 1px solid #898C95; ');
			s.push('font-family: ' + document.body.style.fontFamily + '; margin: 0px;" value="' + this.Name[i]);
			s.push('" id="tabgroups' + i);
			s.push('" onmousedown="return g_tabgroups.Down(this)" onmouseup="return g_tabgroups.Up(this)"');
			s.push(' onmousemove="g_tabgroups.Move(this)"');
			s.push(' oncontextmenu="return g_tabgroups.Popup(this)" onmousewheel="g_tabgroups.Wheel()"');
			s.push(' ondblclick="return g_tabgroups.Edit(this)"');
			s.push('class="');
			s.push(i == this.Index ? 'activetab' : 'tab');
			s.push('"  hidefocus="true">');
		},

		Add: function ()
		{
			var avail = this.Name.join("\0") + "\0";
			for (var i = 1; i <= this.Name.length + 1; i++) {
				var s = GetText("Group") + i;
				if (!avail.match(s + "\0")) {
					this.Name.push(s);
					break;
				}
			}
			var s = [];
			this.Tab(s, this.Name.length - 1);
			document.getElementById("tabgroups").insertAdjacentHTML("BeforeEnd", s.join(""));
			this.Fix();
		},

		Change: function (n)
		{
			if (n > 0) {
				this.Click = n;
			}
			if (this.Click != this.Index) {
				var o = document.getElementById("tabgroups" + this.Click);
				if (o) {
					var pre = document.getElementById("tabgroups" + this.Index);
					if (pre) {
						pre.className = "tab";
					}
					this.Fix();
					this.Index = this.Click;
					o.className = "activetab";
				}
			}
			var bDisp = false;
			var preTabs = [];
			var Tabs = te.Ctrls(CTRL_TC);
			for (var i = 0; i < Tabs.Count; i++) {
				var TC = Tabs.Item(i);
				if (TC.Visible) {
					preTabs.push(TC);
				}
				var b = TC.Data.Group == this.Index;
				TC.Visible = b;
				bDisp |= b;
			}
			if (!bDisp) {
				if (preTabs.length) {
					for (var i = 0; i < preTabs.length; i++) {
						var PT = preTabs[i];
						var TC = te.CreateCtrl(CTRL_TC, PT.Left, PT.Top, PT.Width, PT.Height, PT.Style, PT.Align, PT.TabWidth, PT.TabHeight);
						TC.Data.Group = this.Index;
						var FV = PT.Selected;
						if (FV) {
							var TV = FV.TreeView;
							TC.Selected.Navigate2(FV.FolderItem, SBSP_NEWBROWSER, FV.Type, FV.CurrentViewMode, FV.fFlags, FV.Options, FV.ViewFlags, FV.IconSize, TV.Align, TV.Width, TV.Style, TV.EnumFlags, TV.RootStyle, TV.Root);
						}
						else {
							TC.Selected.Navigate2(HOME_PATH, SBSP_NEWBROWSER, te.Data.View_Type, te.Data.View_ViewMode, te.Data.View_fFlags, te.Data.View_Options, te.Data.View_ViewFlags, te.Data.View_IconSize, te.Data.Tree_Align, te.Data.Tree_Width, te.Data.Tree_Style, te.Data.Tree_EnumFlags, te.Data.Tree_RootStyle, te.Data.Tree_Root);
						}
					}
				}
				else {
					var TC = te.CreateCtrl(CTRL_TC, 0, 0, "100%", "100%", te.Data.Tab_Style, te.Data.Tab_Align, te.Data.Tab_TabWidth, te.Data.Tab_TabHeight);
					TC.Data.Group = this.Index;
					TC.Selected.Navigate2(HOME_PATH, SBSP_NEWBROWSER, te.Data.View_Type, te.Data.View_ViewMode, te.Data.View_fFlags, te.Data.View_Options, te.Data.View_ViewFlags, te.Data.View_IconSize, te.Data.Tree_Align, te.Data.Tree_Width, te.Data.Tree_Style, te.Data.Tree_EnumFlags, te.Data.Tree_RootStyle, te.Data.Tree_Root);
				}
			}
		},

		Close: function (nPos)
		{
			var Tabs = te.Ctrls(CTRL_TC);
			var i = Tabs.Count - 1;
			if (i > 0) {
				for (; i >= 0; i--) {
					var TC = Tabs.Item(i);
					if (TC.Data.Group == nPos) {
						TC.Close();
					}
					else if (TC.Data.Group > nPos) {
						TC.Data.Group--;
					}
				}
			}
			this.Name.splice(nPos, 1);
			if (this.Index >= this.Name.length && this.Index > 1) {
				this.Index--;
			}
			this.Arrange();
		},

		CloseOther: function (nPos)
		{
			var Tabs = te.Ctrls(CTRL_TC);
			var i = Tabs.Count - 1;
			if (i > 0) {
				for (; i >= 0; i--) {
					var TC = Tabs.Item(i);
					if (TC.Data.Group != nPos) {
						TC.Close();
					}
					else {
						TC.Data.Group = 1;
					}
				}
			}
			this.Name = ["", this.Name[nPos]];
			this.Index = 1;
			this.Arrange();
		},

		Down: function (o)
		{
			this.Click = o.id.replace(/\D/g, '') - 0;
			this.WheelButton = api.GetKeyState(VK_MBUTTON);
			if (api.GetKeyState(VK_LBUTTON) < 0) {
				api.GetCursorPos(this.pt);
				this.Change();
				return false;
			}
			return true;
		},

		Up: function (o)
		{
			if (this.WheelButton < 0) {
				this.Close(o.id.replace(/\D/g, ''));
				return false;
			}
			if (this.nDrag && this.nDrag != this.nDrop) {
				var nDrop = o.id.replace(/\D/g, '');
				if (nDrop == this.nDrop) {
					this.nDrop = 0;
					var ar = new Array(this.Name.length);
					var j = 0;
					for (var i = 0; i < this.Name.length; i++) {
						if (j == nDrop) {
							j++;
						}
						ar[i] = (i == this.nDrag) ? nDrop : j++;
					}
					for (var i = 1; i < this.Name.length; i++) {
						this.Name[ar[i]] = document.getElementById("tabgroups" + i).value;
					}

					var Tabs = te.Ctrls(CTRL_TC);
					for (var i = Tabs.Count - 1; i >= 0; i--) {
						var TC = Tabs.Item(i);
						if (TC.Data.Group >= ar.length) {
							TC.Close();
						}
						else {
							TC.Data.Group = ar[TC.Data.Group];
						}
					}
					this.Click = nDrop;
					this.Arrange();
				}
			}
			return true;
		},

		Popup: function (o)
		{
			this.Click = o.id.replace(/\D/g, '') - 0;
			var hMenu = api.CreatePopupMenu();
			var sMenu = [1, "&Edit", 2, "&Close Tab", 3, "Cl&amp;ose Other Tabs", 4, "&New Tab"];
			for (var i = 0; i < sMenu.length; i += 2) {
				api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_STRING, sMenu[i], GetText(sMenu[i + 1]));
			}
			api.GetCursorPos(this.pt);
			var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, this.pt.x, this.pt.y, te.hwnd, null, null);
			api.DestroyMenu(hMenu);
			switch (nVerb) {
				case 1:
					this.Edit(o);
					break
				case 2:
					this.Close(this.Click);
					break
				case 3:
					this.CloseOther(this.Click);
					break
				case 4:
					this.Add();
					break
			}
			return false;
		},

		Edit: function (o)
		{
			var s = InputDialog(GetText("Name"), this.Name[this.Click]);
			if (s) {
				o.value = this.Name[this.Click] = s;
			}
		},

		Fix: function ()
		{
			var Tabs = te.Ctrls(CTRL_TC);
			for (var i = Tabs.Count - 1; i >= 0 ; i--) {
				var TC = Tabs.Item(i);
				if (TC.Data.Group == 0) {
					TC.Data.Group = this.Index;
				}
			}
		},

		Move: function (o)
		{
			if (api.GetKeyState(VK_LBUTTON) < 0) {
				this.nDrop = o.id.replace(/\D/g, '') - 0;
				if (!this.nDrag) {
					var pt = api.Memory("POINT");
					api.GetCursorPos(pt);
					if (IsDrag(pt, g_tabgroups.pt)) {
						this.nDrag = this.nDrop;
						this.Cursor("move");
					}
				}
			}
			else if (this.nDrag) {
				this.Cursor("auto");
				this.nDrag = 0;
			}
		},

		Cursor: function (s)
		{
			for (var i = this.Name.length - 1; i > 0; i--) {
				document.getElementById('tabgroups' + i).style.cursor = s;
			}
		},

		Over: function ()
		{
			clearTimeout(g_tabgroups.tid);
			g_tabgroups.tid = null;
			var pt = api.Memory("POINT");
			api.GetCursorPos(pt);
			if (!IsDrag(pt, g_tabgroups.pt)) {
				g_tabgroups.Change(g_tabgroups.FromPt(pt));
			}
		},

		Wheel: function ()
		{
			this.Click = this.Click - event.wheelDelta / 120
			if (this.Click < 1) {
				this.Click = this.Name.length - 1;
			}
			if (this.Click >= this.Name.length) {
				this.Click = 1;
			}
			this.Change();
		},

		FromPt: function (pt)
		{
			var n = this.Name.length;
			while (--n >= 0) {
				if (HitTest(document.getElementById("tabgroups" + n), pt)) {
					return n;
				}
			}
			return -1;
		}

	};

	g_tabgroups.Init();

	window.onload = function ()
	{
		g_tabgroups.onload();
		setTimeout("g_tabgroups.Change();", 500);
	}

	window.onbeforeunload = function ()
	{
		g_tabgroups.Save();
		return g_tabgroups.beforeunload ? g_tabgroups.beforeunload() : undefined;
	}

	window.Finalize = function ()
	{
		g_tabgroups.Save();
		return g_tabgroups.Finalize ? g_tabgroups.Finalize() : S_OK;
	}

	te.OnDragEnter = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = (g_tabgroups.DragEnter) ? g_tabgroups.DragEnter(Ctrl, dataObj, grfKeyState, pt, pdwEffect) : E_FAIL;
		if (Ctrl.Type == CTRL_WB) {
			hr = S_OK;
		}
		return hr;
	}

	te.OnDragOver = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		if (Ctrl.Type == CTRL_WB) {
			var i = g_tabgroups.FromPt(pt);
			if (i >= 0) { 
				if (i != g_tabgroups.Index) {
					if (IsDrag(pt, g_tabgroups.pt)) {
						clearTimeout(g_tabgroups.tid);
						g_tabgroups.pt = pt.Clone();
						g_tabgroups.tid = setTimeout(g_tabgroups.Over, 300);
					}
				}
				if (te.Data.DragTab) {
					pdwEffect.x = DROPEFFECT_LINK;
				}
				return S_OK;
			}
		}
		return g_tabgroups.DragOver ? g_tabgroups.DragOver(Ctrl, dataObj, grfKeyState, pt, pdwEffect) : E_FAIL;
	}

	te.OnDrop = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		if (Ctrl.Type == CTRL_WB) {
			if (te.Data.DragTab) {
				g_tabgroups.Over();
				var TC = te.Ctrl(CTRL_TC);
				te.Data.DragTab.Move(te.Data.DragIndex, TC.Count, TC);
				TC.SelectedIndex = TC.Count - 1;
				return S_OK;
			}
		}
		return g_tabgroups.Drop ? g_tabgroups.Drop(Ctrl, dataObj, grfKeyState, pt, pdwEffect) : E_FAIL;
	}

	te.OnDragleave = function (Ctrl)
	{
		clearTimeout(g_tabgroups.tid);
		g_tabgroups.tid = null;
		return g_tabgroups.DragLeave ? g_tabgroups.DragLeave(Ctrl) : S_OK;
	}

}
