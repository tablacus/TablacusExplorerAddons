if (window.Addon == 1) {
	const Addon_Id = "shiftkeyselect";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
