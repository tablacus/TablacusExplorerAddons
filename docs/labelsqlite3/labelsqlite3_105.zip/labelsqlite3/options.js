var s = [];
if (await MainWindow.Sync.LabelSQLite3) {
	s.push('<input type="button" value="Load" onclick="Addons.LabelSQLite3.Import()"><br><input type="button" value="Save" onclick="LabelSQLite3_Export()"><br><br>');
}
for (var i = 32; i <= 64; i += 32) {
	s.push('<label>Path</label> (sqlite3.dll) <label>', i, '-bit</label><br><input type="text" name="Path', i, '" placeholder="winsqlite3.dll" style="width: 100%" onchange="Sync.LabelSQLite3.Info()"><br>');
	s.push('<input type="button" value="Browse..." onclick="RefX(\'Path', i, '\', false, this, true, \'*.dll\')">');
	s.push('<input type="button" value="Portable" onclick="PortableX(\'Path', i, '\')"><br><br>');
}
s.push('<label>Information</label> (<label>', await api.sizeof("HANDLE") * 8, '-bit</label>)<div id="Info"></div><br>');
s.push('<br><input type="button" value="', await api.sprintf(999, await GetText("Get %s..."), "SQLite3.dll"), '" title="http://www.sqlite.org/" onclick="wsh.Run(this.title)">');

SetTabContents(0, "", s.join(""));

Addons.LabelSQLite3 = {
	Import: async function () {
		var commdlg = await api.CreateObject("CommonDialog");
		commdlg.InitDir = BuildPath(await te.Data.DataFolder, "config")
		commdlg.Filter = await MakeCommDlgFilter("*.tsv");
		commdlg.Flags = OFN_FILEMUSTEXIST;
		if (await commdlg.ShowOpen()) {
			LoadDBFromTSV(MainWindow.Sync.LabelSQLite3.DB, commdlg.FileName);
		}
	},

	Export: async function () {
		var commdlg = await api.CreateObject("CommonDialog");
		commdlg.InitDir = BuildPath(await te.Data.DataFolder, "config")
		commdlg.Filter = await MakeCommDlgFilter("*.tsv");
		commdlg.DefExt = "tsv";
		commdlg.Flags = OFN_OVERWRITEPROMPT;
		if (await commdlg.ShowSave()) {
			SaveDBtoTSV(MainWindow.Sync.LabelSQLite3.DB, commdlg.FileName);
		}
	}
}

var dllPath = await api.PathUnquoteSpaces(await ExtractMacro(te, document.F.elements["Path" + (await api.sizeof("HANDLE") * 8)].value) || 'winsqlite3.dll');
var hDll = await api.LoadLibraryEx(dllPath, 0, 0);
var arProp = ["sqlite3_open", "sqlite3_close", "sqlite3_exec"];
var arHtml = [];
for (var i = 0; i < arProp.length; ++i) {
	arHtml.push('<input type="checkbox" ');
	if (await api.GetProcAddress(hDll, arProp[i])) {
		arHtml.push("checked");
	}
	arHtml.push(' onclick="return false;">', arProp[i], '<br>');
}
api.FreeLibrary(hDll);
document.getElementById("Info").innerHTML = arHtml.join("");
