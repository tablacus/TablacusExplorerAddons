var s = [];
s.push('<label>Filter</label><br /><input type="text" name="Filter" style="width: 100%">');
s.push('<label>Disable</label><br /><input type="text" name="Disable" style="width: 100%">');
s.push('<label>Priority</label><br /><input type="text" name="Priority" style="width: 100%">');
SetTabContents(0, "General", s);
