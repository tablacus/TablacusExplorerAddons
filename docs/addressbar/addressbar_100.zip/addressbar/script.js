﻿var Addon_Id = "addressbar";
var Default = "ToolBar2Center";

if (Addon == 1) {
	g_addressbar_DeviceChanged = DeviceChanged;
	g_addressbar_ChangeView = ChangeView;
	g_addressbar_tidResize = null;

	var s = '<iframe id="forie6" scrolling="no" frameborder="0" style="position: absolute; width: 100%; height: 20px; z-index: 2"></iframe>';
	s += '<select id="combobox" style="position: absolute; width: 100%; z-index: 1" onchange="SelectComboBox(this);" />';
	s += '<input id="addressbar" type="text" size="60" onkeydown="return KeyDownAddressBar(this)" onfocus="this.select()" style="position: relative; top: -1px;width: 100%; z-index: 3">';
	s += '<span style="width: 12px"></span>';

	var Location = null;
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		Location = items[0].getAttribute("Location");
	}
	if (!Location) {
		Location = Default;
	}
	var o = document.getElementById(Location);
	o.innerHTML += s;
	o.style.display = "block";
	external.Data["Locations"].push(Location + "\t" + Addon_Id);

	g_addressbar = o;
	g_addressbar_resize = o.onresize;

	DeviceChanged = function ()
	{
		document.F.combobox.length = 0;
		AddComboBox(0, ssfDESKTOP);
		AddComboBox(1, ssfPERSONAL);
		AddComboBox(1, ssfDRIVES);

		e = new Enumerator(fso.Drives);
		for (; !e.atEnd(); e.moveNext()) {
			var letter = e.item().DriveLetter;
			var path = letter + ":\\";
			var vol = api.GetDisplayNameOf(path, SHGDN_INFOLDER);
			AddComboBox(2, path);
		}
		AddComboBox(1, ssfBITBUCKET);
		document.F.combobox.selectedIndex = -1
		if (g_addressbar_DeviceChanged) {
			return g_addressbar_DeviceChanged();
		}
	}

	g_addressbar.onresize = function()
	{
		if (!g_addressbar_tidResize) {
			g_addressbar_tidResize = setTimeout("ResizeAddressBar();", 100);
		}
		if (g_addressbar_resize) {
			g_addressbar_resize();
		}
	}

	ChangeView = function(FV)
	{
		if (FV.FolderItem) {
			document.F.addressbar.value = api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORADDRESSBAR | SHGDN_FORPARSING);
		}
		if (g_addressbar_ChangeView) {
			g_addressbar_ChangeView(FV);
		}
	}

	SetAddrss = function (s)
	{
		document.F.addressbar.value = s;
	}

	GetAddrss = function ()
	{
		return document.F.addressbar.value;
	}
}

function SelectComboBox(o)
{
	Navigate(o[o.selectedIndex].value);
	o.selectedIndex = -1;
}

function AddComboBox(level, path)
{
	var o = document.F.combobox;
	o.options[++o.length - 1].text = new Array(level * 4 + 1).join(" ") + api.GetDisplayNameOf(path, SHGDN_INFOLDER);
	o.options[o.length - 1].value = path;
}

function KeyDownAddressBar(o)
{
	if (event.keyCode == VK_RETURN) {
		NavigateAddressbar();
		return false;
	}
	return true;
}

function NavigateAddressbar()
{
	var o = document.F.addressbar;
	var p = GetPos(o);
	var pt = api.Memory("POINT");
	pt.x = screenLeft + p.x;
	pt.y = screenTop + p.y + o.offsetHeight;
	window.Input = o.value;
	if (ExecMenu(external.Ctrl(CTRL_WB), "Alias", pt, 2) != S_OK) {
		Navigate(o.value, external.Data["Conf_NewTab"]);
	}
}

function ResizeAddressBar()
{
	g_addressbar_tidResize = null;
	var w = document.F.combobox.offsetWidth - 17;
	w = (w > 150) ? w : 150;
	var w2 = document.F.addressbar.style.width.replace(/\D/g, "");
	if (w != w2) {
		w = (w > w2) ? w : 150;
		document.F.addressbar.style.width = w;
		document.getElementById("forie6").style.width = w;
	}
}
