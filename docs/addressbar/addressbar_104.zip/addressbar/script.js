﻿var Addon_Id = "addressbar";
var Default = "ToolBar2Center";

if (!window.dialogArguments) {
	g_addressbar =
	{
		DeviceChanged: window.DeviceChanged,
		ChangeView: window.ChangeView,
		SetAddrss: window.SetAddrss,

		tid: null,
		bDrag: false,

		Add: function (level, path)
		{
			var o = document.getElementById("combobox");
			o.options[++o.length - 1].text = new Array(level * 4 + 1).join(" ") + api.GetDisplayNameOf(path, SHGDN_INFOLDER);
			o.options[o.length - 1].value = path;
		},

		Arrange: function ()
		{
			if (this.tid) {
				clearTimeout(this.tid);
				this.tid = null;
			}
			var cbbx = document.getElementById("combobox");
			var addr = document.getElementById("addressbar");
			var ie6 = document.getElementById("forie6");
			var p = GetPos(cbbx, false);
			var w = cbbx.offsetWidth - 39;
			w = w > 0 ? w : 0;
			var w2 = addr.style.width.replace(/\D/g, "");
			w = w < w2 ? 0 : w;
			if (ie6) {
				ie6.style.left = p.x + 21;
				ie6.style.top = p.y + 2;
				ie6.style.width = w;
				ie6.style.height = cbbx.offsetHeight - 4;
			}
			addr.style.left = p.x + 21;
			addr.style.top = p.y + 2;
			addr.style.height = cbbx.offsetHeight - 4;
			addr.style.width = w;
		},

		Select: function (o)
		{
			Navigate(o[o.selectedIndex].value);
			o.selectedIndex = -1;
		},

		KeyDown: function (o)
		{
			if (event.keyCode == VK_RETURN) {
				this.Navigate();
				return false;
			}
			return true;
		},

		Click: function (o)
		{
			var pt = api.Memory("POINT");
			api.GetCursorPos(pt);
			p = GetPos(document.getElementById("addressbar"), true);
			if (pt.x < p.x) {
				this.Open(o);
				return false;
			}
			return true;
		},

		MouseDown: function (o)
		{
			var pt = api.Memory("POINT");
			api.GetCursorPos(pt);
			p = GetPos(document.getElementById("addressbar"), true);
			if (pt.x < p.x) {
				this.bDrag = true;
				o.disabled = true;
				setTimeout('document.getElementById("combobox").disabled = false;', 10);
				return false;
			}
			return true;
		},

		MouseUp: function (o)
		{
			this.bDrag = false;
		},

		Navigate: function ()
		{
			var o = document.F.addressbar;
			var p = GetPos(o, true);
			var pt = api.Memory("POINT");
			pt.y = p.y + o.offsetHeight;
			window.Input = o.value;
			if (ExecMenu(te.Ctrl(CTRL_WB), "Alias", pt, 2) != S_OK) {
				Navigate(o.value, OpenMode);
			}
		},

		Open: function (o)
		{
			var FV = te.Ctrl(CTRL_FV);
			if (FV) {
				pt = GetPos(o, true);
				var FolderItem = FolderMenu.Open(FV.FolderItem, pt.x, pt.y + o.offsetHeight);
				if (FolderItem) {
					switch (window.g_menu_button - 0) {
						case 2:
							PopupContextMenu(FolderItem);
							break;
						case 3:
							Navigate(FolderItem, SBSP_NEWBROWSER);
							break;
						default:
							Navigate(FolderItem, OpenMode);
							break;
					}
				}
			}
			return false;
		},

		Popup: function (o)
		{
			o.blur();
			var FV = te.Ctrl(CTRL_FV);
			if (FV) {
				var hMenu = api.CreatePopupMenu();
				FolderMenu.Clear();
				var pt = api.Memory("POINT");
				api.GetCursorPos(pt);
				p = GetPos(document.getElementById("addressbar"), true);
				var Log = (pt.x < p.x) ? FV.History : sha.NameSpace(ssfDRIVES).Items();
				for (var i = 0; i < Log.Count; i++) {
					FolderMenu.AddMenuItem(hMenu, Log.Item(i));
					if (pt.x < p.x && i == Log.Index) {
						var mii = api.Memory("MENUITEMINFO");
						mii.cbSize = mii.Size;
						mii.fMask  = MIIM_STATE;
						mii.fState = MF_DEFAULT;
						api.SetMenuItemInfo(hMenu, i, true, mii);
					}
				}
				window.g_menu_click = true;
				var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, te.hwnd, null, null);
				api.DestroyMenu(hMenu);
				if (nVerb) {
					var FolderItem = FolderMenu.Items[nVerb - 1];
					switch (window.g_menu_button - 0) {
						case 2:
							PopupContextMenu(FolderItem);
							break;
						case 3:
							Navigate(FolderItem, SBSP_NEWBROWSER);
							break;
						default:
							Navigate(FolderItem, OpenMode);
							break;
					}
				}
				FolderMenu.Clear();
			}
			return false;
		},

		Drag: function ()
		{
			if (this.bDrag) {
				this.bDrag = false;
				var TC = te.Ctrl(CTRL_TC);
				if (TC && TC.SelectedIndex >= 0) {
					var pdwEffect = api.Memory("DWORD");
					pdwEffect.Item(0) = DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK;
					te.Data.DragTab = TC;
					te.Data.DragIndex = TC.SelectedIndex;
					api.DoDragDrop(TC.Item(TC.SelectedIndex).FolderItem, pdwEffect.Item(0), pdwEffect);
					te.Data.DragTab = null;
				}
			}
		}
	};
	var s = [];
	s.push('<select id="combobox" onchange="g_addressbar.Select(this);" hidefocus="true"')
	s.push(' onmousedown="return g_addressbar.MouseDown(this);"');
	s.push(' onmouseup="return g_addressbar.MouseUp();"');
	s.push(' onclick="return g_addressbar.Click(this);"');
	s.push(' oncontextmenu="return g_addressbar.Popup(this);"');
	s.push(' onmouseout="g_addressbar.Drag(this);"');
	s.push(' style="width: 100%; background-repeat: no-repeat;');
	if (document.documentMode) {
		s.push('"></select>');
	}
	else {
		s.push(' background-image: url(../image/toolbar/s_3_4.png)"></select>');
		s.push('<iframe id="forie6" scrolling="no" frameborder="0" style="position: absolute; left 0; width: 0px; height: 1px; z-index: 2; display: inline"></iframe>');
	}
	s.push('<input id="addressbar" type="text" onkeydown="return g_addressbar.KeyDown(this)" onfocus="this.select()" style="position: absolute;left 0; width: 0px; height: 1px; z-index: 3; border: 0px">');
	var o = document.getElementById(SetAddon(Addon_Id, Default, s.join("")));
	if (o) {
		g_addressbar.resize = o.onresize;
		o.onresize = function()
		{
			if (!g_addressbar.tid) {
				g_addressbar.tid = setTimeout("g_addressbar.Arrange()", 100);
			}
			if (g_addressbar.resize) {
				g_addressbar.resize();
			}
		}
	}
	g_addressbar.tid = setTimeout("g_addressbar.Arrange()", 100);

	DeviceChanged = function ()
	{
		document.F.combobox.length = 0;
		g_addressbar.Add(0, ssfDESKTOP);
		g_addressbar.Add(1, ssfPERSONAL);
		g_addressbar.Add(1, ssfDRIVES);

		var Items = sha.NameSpace(ssfDRIVES).Items();
		for (var i = 0; i < Items.Count; i++) {
			var path = api.GetDisplayNameOf(Items.Item(i), SHGDN_FORPARSING);
			if (path.length <= 3) {
				g_addressbar.Add(2, path);
			}
		}
		g_addressbar.Add(1, ssfBITBUCKET);
		document.F.combobox.selectedIndex = -1

		return g_addressbar.DeviceChanged ? g_addressbar.DeviceChanged() : S_OK;
	}

	ChangeView = function (Ctrl)
	{
		if (Ctrl.FolderItem) {
			document.F.addressbar.value = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORADDRESSBAR | SHGDN_FORPARSING);
			if (document.documentMode) {
				var info = api.Memory("SHFILEINFO");
				api.ShGetFileInfo(Ctrl.FolderItem, 0, info, info.Size, SHGFI_ICON | SHGFI_SMALLICON | SHGFI_OPENICON | SHGFI_PIDL);
				var image = te.GdiplusBitmap;
				image.FromHICON(info.hIcon, api.GetSysColor(COLOR_BTNFACE));
				api.DestroyIcon(info.hIcon);
				document.getElementById("combobox").style.backgroundImage = "url(data:image/png;base64," + image.Base64("image/png") + ')';
			}
		}
		return g_addressbar.ChangeView ? g_addressbar.ChangeView(Ctrl) : S_OK;
	}

	SetAddrss = function (s)
	{
		document.F.addressbar.value = s;
		return  g_addressbar.SetAddress ? g_addressbar.SetAddress(s) : S_OK;
	}

	GetAddrss = function ()
	{
		return document.F.addressbar.value;
	}
}
