﻿var Addon_Id = "addressbar";
var Default = "ToolBar2Center";

if (!window.dialogArguments) {
	g_addressbar = 
	{
		DeviceChanged: window.DeviceChanged,
		ChangeView: window.ChangeView,
		SetAddrss: window.SetAddrss,

		tid: null,

		Add: function (level, path)
		{
			var o = document.F.combobox;
			o.options[++o.length - 1].text = new Array(level * 4 + 1).join(" ") + api.GetDisplayNameOf(path, SHGDN_INFOLDER);
			o.options[o.length - 1].value = path;
		},

		Arrange: function ()
		{
			if (this.tid) {
				clearTimeout(this.tid);
				this.tid = null;
			}
			var ie6 = document.getElementById("forie6");
			var addr = document.getElementById("addressbar");
			var cbbx = document.getElementById("combobox");
			var p = GetPos(addr, false);
			if (ie6) {
				cbbx.style.left = p.x;
				cbbx.style.top = p.y;
				cbbx.style.display = "inline";
				ie6.style.left = p.x;
				ie6.style.top = p.y;

				var w = cbbx.offsetWidth - 17;
				w = w > 0 ? w : 0;
				var w2 = addr.style.width.replace(/\D/g, "");
				if (w != w2) {
					w = w < w2 ? 0 : w;
					ie6.style.width = w;
					ie6.style.height = cbbx.offsetHeight;
					addr.style.width = w;
					addr.style.display = "inline";
				}
			}
		},

		Select: function (o)
		{
			Navigate(o[o.selectedIndex].value);
			o.selectedIndex = -1;
		},

		KeyDown: function (o)
		{
			if (event.keyCode == VK_RETURN) {
				this.Navigate();
				return false;
			}
			return true;
		},

		Navigate: function ()
		{
			var o = document.F.addressbar;
			var p = GetPos(o, true);
			var pt = api.Memory("POINT");
			pt.y = p.y + o.offsetHeight;
			window.Input = o.value;
			if (ExecMenu(te.Ctrl(CTRL_WB), "Alias", pt, 2) != S_OK) {
				Navigate(o.value, OpenMode);
			}
		}

	};
	var s = '<input id="addressbar" type="text" onkeydown="return g_addressbar.KeyDown(this)" onfocus="this.select()" style="position: relative; width: 100%; z-index: 3">';
	s += '<iframe id="forie6" scrolling="no" frameborder="0" style="position: absolute; left 0; width: 0px; height: 1px; z-index: 2; display: inline"></iframe>';
	s += '<select id="combobox" style="position: absolute; left: 0; width: 100%; z-index: 1; display: none;" onchange="g_addressbar.Select(this);" />';
	s += '<span style="width: 12px"></span>';
	var o = document.getElementById(SetAddon(Addon_Id, Default, s));
	if (o) {
		g_addressbar.resize = o.onresize;
		o.onresize = function()
		{
			if (!g_addressbar.tid) {
				g_addressbar.tid = setTimeout("g_addressbar.Arrange()", 100);
			}
			if (g_addressbar.resize) {
				g_addressbar.resize();
			}
		}
	}
	g_addressbar.Arrange();

	DeviceChanged = function ()
	{
		document.F.combobox.length = 0;
		g_addressbar.Add(0, ssfDESKTOP);
		g_addressbar.Add(1, ssfPERSONAL);
		g_addressbar.Add(1, ssfDRIVES);

		var Items = sha.NameSpace(ssfDRIVES).Items();
		for (var i = 0; i < Items.Count; i++) {
			var path = api.GetDisplayNameOf(Items.Item(i), SHGDN_FORPARSING);
			if (path.length <= 3) {
				g_addressbar.Add(2, path);
			}
		}
		g_addressbar.Add(1, ssfBITBUCKET);
		document.F.combobox.selectedIndex = -1

		return g_addressbar.DeviceChanged ? g_addressbar.DeviceChanged() : S_OK;
	}

	ChangeView = function (FV)
	{
		if (FV.FolderItem) {
			document.F.addressbar.value = api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORADDRESSBAR | SHGDN_FORPARSING);
		}
		return g_addressbar.ChangeView ? g_addressbar.ChangeView(FV) : S_OK;
	}

	SetAddrss = function (s)
	{
		document.F.addressbar.value = s;
		return  g_addressbar.SetAddress ? g_addressbar.SetAddress(s) : S_OK;
	}

	GetAddrss = function ()
	{
		return document.F.addressbar.value;
	}
	g_addressbar.Arrange(1000);
}
