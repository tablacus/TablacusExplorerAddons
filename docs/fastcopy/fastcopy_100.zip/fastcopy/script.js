﻿if (window.Addon == 1) {
	g_fastcopy =
	{
		Drop: te.OnDrop,
		Command: te.OnCommand,
		OnInvokeCommand: te.OnInvokeCommand,

		FO: function (Ctrl, Items, Dest, grfKeyState, pt, pdwEffect, bOver, bDelete)
		{
			if (!(grfKeyState & MK_LBUTTON) || Items.Count == 0) {
				return false;
			}
			var fastcopy = te.Data.Addons.getElementsByTagName("fastcopy");
			if (fastcopy.length == 0) {
				return false;
			}
			var item = fastcopy[0];
			var strCmd = api.PathUnquoteSpaces(item.getAttribute("Path"));
			if (!strCmd || !fso.FileExists(strCmd)) {
				return false;
			}
			if (bDelete || (Dest != "" && fso.FolderExists(Dest))) {
				var hDrop = Items.hDrop;
				if (Items.Count == api.DragQueryFile(hDrop, -1)) {
					var strFunc;
					var bStart;
					if (bDelete) {
						strFunc = item.getAttribute("Delete");
						bStart = item.getAttribute("DeleteStart");
					}
					else {
						if (bOver) {
							var DropTarget = api.DropTarget(Dest);
							DropTarget.DragOver(Items, grfKeyState, pt, pdwEffect);
						}
						if (pdwEffect.Item(0) & DROPEFFECT_COPY) {
							strFunc = item.getAttribute("Copy");
							bStart = item.getAttribute("CopyStart");
						}
						else if (pdwEffect.Item(0) & DROPEFFECT_MOVE) {
							strFunc = item.getAttribute("Move");
							bStart = item.getAttribute("MoveStart");
						}
					}
					if (strFunc) {
						var oExec = wsh.Exec(api.PathQuoteSpaces(strCmd) + " " + strFunc.replace(/%dest%/i, Dest));
						var hwnd = GethwndFromPid(oExec.ProcessID);
						api.PostMessage(hwnd, WM_DROPFILES, hDrop, 0);
						if (bStart) {
							api.PostMessage(hwnd, WM_KEYDOWN, VK_RETURN, 0);
							api.PostMessage(hwnd, WM_KEYUP, VK_RETURN, 0);
						}
						else {
							wsh.AppActivate(oExec.ProcessID);
						}
						if (!bDelete && api.ILIsParent(wsh.ExpandEnvironmentStrings("%TEMP%"), Items.Item(-1), false)) {
							while (oExec.Status == 0) {
								api.Sleep(api.DoEvents() ? 10 : 100);
							}
						}
						return true;
					}
				}
				api.DragFinish(hDrop);
			}
			return false;
		}
	};

	te.OnDrop = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		switch (Ctrl.Type) {
			case CTRL_SB:
			case CTRL_EB:
				var Items = Ctrl.Items();
				var Dest;
				var i = Ctrl.HitTest(pt, LVHT_ONITEM);
				if (i >= 0) {
					Dest = Items.Item(i);
					if (!fso.FolderExists(Dest.Path)) {
						if (api.DropTarget(Dest)) {
							return E_FAIL;
						}
						Dest = Ctrl.FolderItem;
					}
				}
				else {
					Dest = Ctrl.FolderItem;
				}
				if (g_fastcopy.FO(Ctrl, dataObj, Dest.Path, grfKeyState, pt, pdwEffect, true)) {
					return S_OK
				}
				break;
			case CTRL_DT:
				if (g_fastcopy.FO(null, dataObj, Ctrl.FolderItem.Path, grfKeyState, pt, pdwEffect, true)) {
					return S_OK
				}
				break;
		}
		return g_fastcopy.Drop ? g_fastcopy.Drop(Ctrl, dataObj, grfKeyState, pt, pdwEffect) : E_FAIL;
	}

	te.OnCommand = function (Ctrl, hwnd, msg, wParam, lParam)
	{
		if (Ctrl.Type == CTRL_SB || Ctrl.Type == CTRL_EB) {
			switch ((wParam & 0xfff) + 1) {
				case CommandID_PASTE:
					var Items = api.OleGetClipboard()
					if (g_fastcopy.FO(null, Items, Ctrl.FolderItem.Path, MK_LBUTTON, null, Items.pdwEffect, false)) {
						return S_OK;
					}
					break;
				case CommandID_DELETE:
					var Items = Ctrl.SelectedItems();
					if (g_fastcopy.FO(null, Items, "", MK_LBUTTON, null, Items.pdwEffect, false, true)) {
						return S_OK;
					}
					break;
			}
		}
		return g_fastcopy.Command ? g_fastcopy.Command(Ctrl, hwnd, msg, wParam, lParam) : S_FALSE;
	}

	te.OnInvokeCommand = function (ContextMenu, fMask, hwnd, Verb, Parameters, Directory, nShow, dwHotKey, hIcon)
	{
		switch (Verb + 1) {
			case CommandID_PASTE:
				var Target = ContextMenu.Items();
				if (Target.Count) {
					var Items = api.OleGetClipboard()
					if (g_fastcopy.FO(null, Items, Target.Item(0).Path, MK_LBUTTON, null, Items.pdwEffect, false)) {
						return S_OK;
					}
				}
				break;
			case CommandID_DELETE:
				var Items = ContextMenu.Items();
				if (g_fastcopy.FO(null, Items, "", MK_LBUTTON, null, Items.pdwEffect, false, true)) {
					return S_OK;
				}
				break;
		}
		return g_fastcopy.OnInvokeCommand ? g_fastcopy.OnInvokeCommand(ContextMenu, fMask, hwnd, Verb, Parameters, Directory, nShow, dwHotKey, hIcon) : S_FALSE;
	}

	if (!ExtraMenus.Context) {
		ExtraMenus.Context = function (Ctrl, hMenu, nPos) {}
	}

}

