﻿returnValue = false;

function InitOptions()
{
	var InstalledFolder = fso.GetParentFolderName(api.GetModuleFileName(null));
	LoadLang2(fso.BuildPath(fso.GetParentFolderName(api.GetModuleFileName(null)), "addons\\openinstead\\lang\\" + external.Data["Conf_Lang"] + ".xml"));

	ApplyLang(document);
	info = GetAddonInfo("openinstead");
	document.title = info.Name;
	var items = external.Data["Addons"].getElementsByTagName("openinstead");
	if (items.length) {
		var item = items[0];
		document.F.RealFolders.checked = item.getAttribute("RealFolders");
		document.F.SpecialFolders.checked = item.getAttribute("SpecialFolders");
	}
}

function SetOptions()
{
	var items = external.Data["Addons"].getElementsByTagName("openinstead");
	if (items.length) {
		var item = items[0];
		item.setAttribute("RealFolders", document.F.RealFolders.checked ? 1 : "");
		item.setAttribute("SpecialFolders", document.F.SpecialFolders.checked ? 1 : "");
		returnValue = true;
	}
	window.close();
}
