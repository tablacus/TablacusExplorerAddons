﻿if (Addon == 1) {
	g_openinstead_OnWindowRegistered = external.OnWindowRegistered;

	external.OnWindowRegistered = function (Ctrl)
	{
		if (g_openinstead_OnWindowRegistered) {
			g_openinstead_OnWindowRegistered(Ctrl);
		}

		var items = external.Data["Addons"].getElementsByTagName("openinstead");
		if (items.length) {
			var item = items[0];
			var ws = sha.Windows();
			for (var i = ws.Count - 1; i >= 0; i--) {
				var exp = ws.item(i);
				if (exp) {
					var doc = exp.Document;
					if (doc) {
						var path = api.GetDisplayNameOf(doc, SHGDN_FORPARSING);
						if (path && !path.match("::{26EE0668-A00A-44D7-9371-BEB064C98683}")) {
							if (path.match(/^.?:\\|^\\\\/)) {
								if (item.getAttribute("RealFolders")) {
									Navigate(doc, SBSP_NEWBROWSER);
									exp.Quit();
									api.SetForegroundWindow(external.hwnd);
								}
							}
							else {
								if (item.getAttribute("SpecialFolders")) {
									Navigate(doc, SBSP_NEWBROWSER);
									exp.Quit();
									api.SetForegroundWindow(external.hwnd);
								}
							}
						}
					}
				}
			}
		}
	}
}
