﻿var Addon_Id = "mouse";
var Default = "ToolBar1Center";

g_Types["Mouse"] = new Array("All", "List", "Tree", "Tabs", "Browser");

if (Addon == 1) {
	g_ptDrag = api.Memory("POINT");
	g_strMouse = "";
	g_CancelButton = false;
	g_ptGesture = api.Memory("POINT");
	g_hwndGesture = null;
	g_tidGesture = null;
	g_bCapture = false;
	g_RButton = -1;
	g_bTrail = false;
	g_tidDblClk = null;
	g_bDblClk = false;

	g_mouse_MouseMessage = external.OnMouseMessage;
	g_mouse_DragEnter = external.OnDragEnter;

	var Location = null;
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		Location = items[0].getAttribute("Location");
	}
	if (!Location) {
		Location = Default;
	}
	var o = document.getElementById(Location);
	o.innerHTML += '<span id="mouse" style="color: gray">&nbsp;</span>';
	o.style.display = "block";
	external.Data["Locations"].push(Location + "\t" + Addon_Id);

	var g_mouseGestures, g_mouseTrailColor, g_mouseTrailSize, g_mouseTimeout;
	var items = external.Data["Addons"].getElementsByTagName("mouse");
	if (items.length) {
		var item = items[0];
		g_mouseGestures = api.LowPart(item.getAttribute("Gestures"));
		g_mouseTrailColor = api.LowPart(item.getAttribute("TrailColor"));
		g_mouseTrailSize = api.LowPart(item.getAttribute("TrailSize"));
		g_mouseTimeout = api.LowPart(item.getAttribute("Timeout"));
	}
	if (!g_mouseGestures) {
		g_mouseGestures = 2;
	}
	if (!g_mouseTrailColor) {
		g_mouseTrailColor = 0xff00;
	}
	if (!g_mouseTrailSize) {
		g_mouseTrailSize = 2;
	}
	if (!g_mouseTimeout) {
		g_mouseTimeout = 3000;
	}
	var path = fso.GetParentFolderName(api.GetModuleFileName(null));
	var xml = external.CreateObject("Msxml2.DOMDocument");
	xml.async = false;

	xml.load(fso.BuildPath(path, "config\\mouse.xml"));
	for (t in g_Types["Mouse"]) {
		external.Data["Mouse" + g_Types["Mouse"][t]] = new Array();
		var items = xml.getElementsByTagName(g_Types["Mouse"][t]);
		if (items.length == 0 && g_Types["Mouse"][t] == "List") {
			items = xml.getElementsByTagName("Folder");
		}
		for (i = 0; i < items.length; i++) {
			var item = items[i];
			var strMouse = item.getAttribute("Mouse");
			SetKeyData(g_Types["Mouse"][t], strMouse, item.text, item.getAttribute("Type"), "Mouse")
		}
	}

	external.OnMouseMessage = function (Ctrl, hwnd, msg, mouseData, pt, wHitTestCode, dwExtraInfo)
	{
		if (msg == WM_MOUSEWHEEL) {
			if (api.GetKeyState(VK_RBUTTON) < 0) {
				var TC = external.Ctrl(CTRL_TC);
				if (TC) {
					ChangeTab(TC, -mouseData / (120 * 65536))
					g_CancelButton = true;
					return S_OK;
				}
			}
			var Ctrl2 = external.CtrlFromPoint(pt);
			if (Ctrl2) {
				if (Ctrl2.Type == CTRL_TC) {
					ChangeTab(Ctrl2, -mouseData / (120 * 65536))
					return S_OK;
				}
				var hwnd2 = api.WindowFromPoint(pt);
				if (hwnd2 && hwnd != hwnd2) {
					api.SendMessage(hwnd2, msg, mouseData, pt.x + (pt.y << 16));
					return S_OK;
				}
			}
		}
		if (msg == WM_LBUTTONUP || msg == WM_RBUTTONUP || msg == WM_MBUTTONUP || msg == WM_XBUTTONUP) {
			if (GetMouseButton(msg, mouseData) == g_strMouse.charAt(0)) {
				var hr = S_FALSE;
				var bButton = false;
				if (g_RButton >= 0 && msg == WM_RBUTTONUP) {
					RButtonDown(true);
					bButton = (g_strMouse == "2");
				}
				if (g_strMouse.length >= 2 || !IsDrag(pt, external.Data['pt'])) {
					hr = ExecGesture(external.CtrlFromWindow(g_hwndGesture), g_hwndGesture);
				}
				var s = g_strMouse;
				EndGesture(false);
				if (g_bCapture) {
					api.ReleaseCapture();
					g_bCapture = false;
				}
				if (g_CancelButton || hr == S_OK) {
					g_CancelButton = false;
					return S_OK;
				}
				if (bButton) {
					api.PostMessage(g_hwndGesture, WM_CONTEXTMENU, g_hwndGesture, pt.x + (pt.y << 16));
					return S_OK;
				}
			}
		}
		if (msg == WM_LBUTTONDOWN || msg == WM_RBUTTONDOWN || msg == WM_MBUTTONDOWN || msg == WM_XBUTTONDOWN) {
			clearTimeout(g_tidDblClk);
			if (g_tidDblClk && msg == WM_LBUTTONDOWN && Ctrl.Type == CTRL_EB) {
				g_tidDblClk = false;
				msg = WM_LBUTTONDBLCLK;
			}
			if (g_strMouse == "") {
				external.Data['pt'] = pt;
				g_ptGesture.x = pt.x;
				g_ptGesture.y = pt.y;
				g_hwndGesture = hwnd;
				if (msg == WM_LBUTTONDOWN && Ctrl.Type == CTRL_EB) {
					g_tidDblClk = true;
					g_tidDblClk = setTimeout("g_tidDblClk = false", api.GetDoubleClickTime());
				}
			}
			g_strMouse += GetMouseButton(msg, mouseData);
			if (g_strMouse.length > 1) {
				StartGestureTimer();
			}
			document.getElementById("mouse").innerHTML = GetGestureKey() + g_strMouse;
			if (msg == WM_RBUTTONDOWN) {
				if (g_mouseGestures >= 2) {
					var iItem = -1;
					if (Ctrl.Type == CTRL_SB || Ctrl.Type == CTRL_EB) {
						iItem = Ctrl.HitTest(pt, LVHT_ONITEM);
						if (iItem < 0) {
							return S_OK;
						}
					}
					if (g_mouseGestures == 3) {
						g_RButton = iItem;
						StartGestureTimer();
						return S_OK;
					}
				}
			}
		}
		if (msg == WM_LBUTTONDBLCLK || msg == WM_RBUTTONDBLCLK || msg == WM_MBUTTONDBLCLK || msg == WM_XBUTTONDBLCLK) {
			var strClass = api.GetClassName(hwnd);
			if (strClass != WC_HEADER) {
				external.Data['pt'] = pt;
				g_strMouse = GetMouseButton(msg, mouseData);
				g_strMouse += g_strMouse;
				var hr = ExecGesture(Ctrl, hwnd);
				EndGesture(false);
				if (hr == S_OK) {
					return hr;
				}
			}
		}

		if (msg == WM_MOUSEMOVE) {
			if (g_strMouse != "" && (g_mouseGestures > 1 && api.GetKeyState(VK_RBUTTON) < 0) || (g_mouseGestures && (api.GetKeyState(VK_MBUTTON) < 0 || api.GetKeyState(VK_XBUTTON1) < 0 || api.GetKeyState(VK_XBUTTON2) < 0))) {
				var x = (pt.x - g_ptGesture.x);
				var y = (pt.y - g_ptGesture.y);
				if (Math.abs(x) + Math.abs(y) >= 20) {
					if (g_mouseTrailSize) {
						var hdc = api.GetWindowDC(external.hwnd);
						if (hdc) {
							var rc = api.Memory("RECT");
							api.GetWindowRect(external.hwnd, rc);
							api.MoveToEx(hdc, g_ptGesture.x - rc.left, g_ptGesture.y - rc.top, null);
							var pen1 = api.CreatePen(PS_SOLID, g_mouseTrailSize, g_mouseTrailColor);
							var hOld = api.SelectObject(hdc, pen1);
							api.LineTo(hdc, pt.x - rc.left, pt.y - rc.top);
							api.SelectObject(hdc, hOld);
							api.DeleteObject(pen1);
							g_bTrail = true;
							api.ReleaseDC(external.hwnd);
						}
					}
					g_ptGesture.x = pt.x;
					g_ptGesture.y = pt.y;
					var s;
					if (Math.abs(x) >= Math.abs(y)) {
						if (x < 0) {
							s = "L";
						}
						else {
							s = "R";
						}
					}
					else if (y < 0) {
						s = "U";
					}
					else {
						s = "D";
					}
					if (s != g_strMouse.charAt(g_strMouse.length - 1)) {
						g_strMouse += s;
						document.getElementById("mouse").innerHTML = GetGestureKey() + g_strMouse;
					}
					if (!g_bCapture) {
						api.SetCapture(g_hwndGesture);
						g_bCapture = true;
					}
					StartGestureTimer();
				}
			}
			if (Ctrl.Type == CTRL_TC) {
				if (!external.Data['DragTab']) {
					if (api.GetKeyState(VK_LBUTTON) < 0) {
						if (IsDrag(pt, external.Data['pt'])) {
							g_strMouse = "";
							document.getElementById("mouse").innerHTML = "";
							external.Data['pt'] = null;
							var i = Ctrl.HitTest(pt, TCHT_ONITEM);
							if (i >= 0) {
								var pdwEffect = api.Memory("DWORD");
								pdwEffect.X = DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK;
								external.Data['DragTab'] = Ctrl;
								external.Data['DragIndex'] = i;
								api.DoDragDrop(Ctrl.Item(i).FolderItem, pdwEffect.X, pdwEffect);
								external.Data['DragTab'] = null;
							}
						}
					}
				}
			}
		}
		if (g_strMouse.length >= 2) {
			return S_OK;
		}
		if (g_mouse_MouseMessage) {
			return g_mouse_MouseMessage(Ctrl, hwnd, msg, mouseData, pt, wHitTestCode, dwExtraInfo);
		}
		return S_FALSE;
	}

	external.OnDragEnter = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = E_NOTIMPL;
		if (g_mouse_DragEnter) {
			hr = g_mouse_DragEnter(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		g_strMouse = "";
		return hr;
	}
}

function StartGestureTimer()
{
	var i = g_mouseTimeout;
	if (i) {
		clearTimeout(g_tidGesture);
		g_tidGesture = setTimeout("EndGesture(true)", i);
	}
}

function EndGesture(button)
{
	clearTimeout(g_tidGesture);
	if (g_bCapture) {
		api.ReleaseCapture();
		g_bCapture = false;
	}
	if (g_RButton >= 0) {
		RButtonDown(false)
	}
	g_strMouse = "";
	g_bRButton = false;
	document.getElementById("mouse").innerHTML = "";
	if (g_bTrail) {
		api.RedrawWindow(external.hwnd, null, 0, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN);
		g_bTrail =false;
	}
}

function RButtonDown(mode)
{
	if (g_strMouse == "2") {
		var item = api.Memory("LVITEM");
		item.iItem = g_RButton;
		item.mask = LVIF_STATE;
		item.stateMask = LVIS_SELECTED;
		api.SendMessage(g_hwndGesture, LVM_GETITEM, 0, item.p);
		if (!(item.state & LVIS_SELECTED)) {
			if (mode) {
				var Ctrl = external.CtrlFromWindow(g_hwndGesture);
				Ctrl.SelectItem(Ctrl.Items.Item(g_RButton), SVSI_SELECT | SVSI_DESELECTOTHERS);
			}
			else {
				var ptc = api.Memory("POINT");
				ptc = external.Data["pt"].clone();
				api.ScreenToClient(g_hwndGesture, ptc);
				api.SendMessage(g_hwndGesture, WM_RBUTTONDOWN, 0, ptc.x + (ptc.y << 16));
			}
		}
	}
	g_RButton = -1;
}

function GetMouseButton(msg, wParam)
{
	if (msg >= WM_LBUTTONDOWN && msg <= WM_LBUTTONDBLCLK) {
		return "1";
	}
	if (msg >= WM_RBUTTONDOWN && msg <= WM_RBUTTONDBLCLK) {
		return "2";
	}
	if (msg >= WM_MBUTTONDOWN && msg <= WM_MBUTTONDBLCLK) {
		return "3";
	}
	if (msg >= WM_XBUTTONDOWN && msg <= WM_XBUTTONDBLCLK) {
		switch (wParam >> 16) {
			case XBUTTON1:
				return "4";
			case XBUTTON2:
				return "5";
		}
	}
	return "";
}

function GetGestureKey()
{
	var s = "";
	if (api.GetKeyState(VK_SHIFT) < 0) {
		s += "S";
	}
	if (api.GetKeyState(VK_CONTROL) < 0) {
		s += "C";
	}
	if (api.GetKeyState(VK_MENU) < 0) {
		s += "A";
	}
	return s;
}

function ExecGesture(Ctrl, hwnd)
{
	g_strMouse = GetGestureKey() + g_strMouse;

	external.Data["cmdMouse"] = g_strMouse;
	var cmd = external.Data["MouseAll"][g_strMouse];
	if (cmd) {
		var a = cmd.split(g_sep);
		return Exec(Ctrl, a[0], a[1], hwnd, null);
	}
	if (!Ctrl) {
		return S_FALSE;
	}
	var s = null;
	switch (Ctrl.Type) {
		case CTRL_SB:
		case CTRL_EB:
			s = "MouseList";
			break;
		case CTRL_TV:
			s = "MouseTree";
			break;
		case CTRL_TC:
			s = "MouseTabs";
			break;
		case CTRL_WB:
			s = "MouseBrowser";
			break;
	}
	if (s) {
		var cmd = external.Data[s][g_strMouse];
		if (cmd) {
			var a = cmd.split(g_sep);
			return Exec(Ctrl, a[0], a[1], hwnd, null);
		}
	}
	return S_FALSE;
}

