var nTabIndex = 0;
var nTabMax = 0;

var g_x = {Mouse: null};
var g_Chg = {Mouse: false, Data: null};
g_Types = {Mouse: ["All", "List", "Tree", "Tabs", "Browser"]};

function InitOptions()
{
	LoadLang2(fso.BuildPath(fso.GetParentFolderName(api.GetModuleFileName(null)), "addons\\mouse\\lang\\" + te.Data.Conf_Lang + ".xml"));
	ApplyLang(document);
	document.title = GetText("Mouse");
	LoadX("Mouse");
}

function SetOptions()
{
	ConfirmX();
	SaveX("Mouse");
	window.close();
}

function LoadX(mode)
{
	if (!g_x[mode]) {
		g_x[mode] = document.F.elements[mode + "All"];
		var oa = document.F.elements[mode];
		oa.length = 0;
		var xml = OpenXml(mode + ".xml", false, true);
		for (var j in g_Types[mode]) {
			oa[++oa.length - 1].text = GetText(g_Types[mode][j]);
			oa[oa.length - 1].value = g_Types[mode][j];
			var o = document.F.elements[mode + g_Types[mode][j]];
			var items = xml.getElementsByTagName(g_Types[mode][j]);
			var i = items.length;
			if (i == 0 && g_Types[mode][j] == "List") {
				items = xml.getElementsByTagName("Folder");
				i = items.length;
			}
			o.length = i;
			while (--i >= 0) {
				var item = items[i];
				SetData(o[i], new Array(item.getAttribute(mode), item.text, item.getAttribute("Type")));
			}
		}
		xml = null;
	}
}

function SetData(sel, a)
{
	if (!a[0]) {
		return;
	}
	sel.value = PackData(a);
	sel.text = a[0];
}

function PackData(a)
{
	var i = a.length;
	while (--i >= 0) {
		a[i] = a[i].replace(g_sep, "`  ~");
	}
	return a.join(g_sep);
}

function ClearX(mode)
{
	g_Chg.Data = null;
}

function ChangeX(mode)
{
	g_Chg.Data = mode;
}

function ConfirmX()
{
	if (g_Chg.Data && g_x[g_Chg.Data].selectedIndex >= 0) {
		if (confirm(GetText("Do you want to replace?"))) {
			ReplaceX(g_Chg.Data);
		}
		ClearX(g_Chg.Data);
	}
}

function EditX(mode)
{
	if (g_x[mode].selectedIndex < 0) {
		return;
	}
	ClearX(mode);
	var a = g_x[mode][g_x[mode].selectedIndex].value.split(g_sep);
	document.F.elements[mode + mode].value = a[0];
	document.F.elements[mode + "Path"].value = a[1];
	o = document.F.elements[mode + "Type"];
	i = o.length;
	while (--i >= 0) {
		if (o(i).value == a[2]) {
			o.selectedIndex = i;
			break;
		}
	}
}

function SwitchX(mode, o)
{
	g_x[mode].style.display = "none";
	g_x[mode] = document.F.elements[mode + o.value];
	g_x[mode].style.display = "inline";
}

function AddX(mode)
{
	g_x[mode].selectedIndex = ++g_x[mode].length - 1;
	ReplaceX(mode);
}

function ReplaceX(mode)
{
	ClearX(mode);
	if (g_x[mode].selectedIndex < 0) {
		return;
	}
	var sel = g_x[mode][g_x[mode].selectedIndex];
	o = document.F.elements[mode + "Type"];
	SetData(sel, new Array(document.F.elements[mode + mode].value, document.F.elements[mode + "Path"].value, o[o.selectedIndex].value));
	g_Chg[mode] = true;
}

function RemoveX(mode)
{
	ConfirmX(mode);
	if (g_x[mode].selectedIndex < 0 || !confirm(GetText("Are you sure?"))) {
		return;
	}
	g_x[mode][g_x[mode].selectedIndex] = null;
	g_Chg[mode] = true;
}

function MoveX(mode, n)
{
	if (g_x[mode].selectedIndex < 0 || g_x[mode].selectedIndex + n < 0 || g_x[mode].selectedIndex + n >= g_x[mode].length) {
		return;
	}
	var src = g_x[mode][g_x[mode].selectedIndex];
	var dist = g_x[mode][g_x[mode].selectedIndex + n];
	var text = dist.text;
	var value = dist.value;
	dist.text = src.text;
	dist.value = src.value;
	src.text = text;
	src.value = value;
	g_x[mode].selectedIndex += n;
	g_Chg[mode] = true;
}

function SaveX(mode)
{
	if (g_Chg[mode]) {
		var xml = CreateXml();
		var root = xml.createElement("TablacusExplorer");
		for (var j in g_Types[mode]) {
			var o = document.F.elements[mode + g_Types[mode][j]];
			for (var i = 0; i < o.length; i++) {
				var item = xml.createElement(g_Types[mode][j]);
				var a = o[i].value.split(g_sep);
				item.setAttribute(mode, a[0]);
				item.text = a[1];
				item.setAttribute("Type", a[2]);
				root.appendChild(item);
			}
		}
		xml.appendChild(root);
		SaveXmlEx(mode.toLowerCase() + ".xml", xml);
	}
}

function AddMouse(o)
{
	document.F.elements["MouseMouse"].value += o.title;
	ChangeX("Mouse");
}

function SetRadio(o)
{
	var ar = o.id.split("=");
	document.F.elements[ar[0]].value = ar[1];
}

function ShowLocation()
{
	showModelessDialog("../../script/location.html?id=mouse&show=6&index=6", dialogArguments, 'dialogWidth: 640px; dialogHeight: 480px; resizable: yes; status: 0;');
}
