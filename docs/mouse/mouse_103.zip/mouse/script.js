﻿var Addon_Id = "mouse";
var Default = "ToolBar1Center";

g_Types.Mouse = ["All", "List", "Tree", "Tabs", "Browser"];

if (!window.dialogArguments) {
	g_ptDrag = api.Memory("POINT");
	g_mouse = 
	{
		str: "",
		CancelButton: false,
		ptGesture: api.Memory("POINT"),
		hwndGesture: null,
		tidGesture: null,
		bCapture: false,
		RButton: -1,
		bTrail: false,
		tidDblClk: null,
		bDblClk: false,

		MouseMessage: te.OnMouseMessage,
		DragEnter: te.OnDragEnter,

		Init: function ()
		{
			SetAddon(Addon_Id, Default, '<span id="mouse" style="color: gray">&nbsp;</span>');
			var items = te.Data.Addons.getElementsByTagName("mouse");
			if (items.length) {
				var item = items[0];
				this.Gestures = api.LowPart(item.getAttribute("Gestures"));
				this.TrailColor = api.LowPart(item.getAttribute("TrailColor"));
				this.TrailSize = api.LowPart(item.getAttribute("TrailSize"));
				this.Timeout = api.LowPart(item.getAttribute("Timeout"));
			}
			if (!this.Gestures) {
				this.Gestures = 2;
			}
			if (!this.TrailColor) {
				this.TrailColor = 0xff00;
			}
			if (!this.TrailSize) {
				this.TrailSize = 2;
			}
			if (!this.Timeout) {
				this.Timeout = 3000;
			}
			var xml = OpenXml("mouse.xml", false, true);
			for (t in g_Types.Mouse) {
				var mode = g_Types.Mouse[t];
				if (!g_mouse[mode]) {
					g_mouse[mode] = {};
				}
				var items = xml.getElementsByTagName(mode);
				if (items.length == 0 && api.strcmpi(mode, "List") == 0) {
					items = xml.getElementsByTagName("Folder");
				}
				for (i = 0; i < items.length; i++) {
					var item = items[i];
					var strMouse = item.getAttribute("Mouse");
					SetKeyData(mode, strMouse, item.text, item.getAttribute("Type"), "Mouse", g_mouse)
				}
			}
		},

		StartGestureTimer: function ()
		{
			var i = this.Timeout;
			if (i) {
				clearTimeout(this.tidGesture);
				this.tidGesture = setTimeout("g_mouse.EndGesture(true)", i);
			}
		},

		EndGesture: function (button)
		{
			clearTimeout(this.tidGesture);
			if (this.bCapture) {
				api.ReleaseCapture();
				this.bCapture = false;
			}
			if (this.RButton >= 0) {
				this.RButtonDown(false)
			}
			this.str = "";
			g_bRButton = false;
			document.getElementById("mouse").innerHTML = "";
			if (this.bTrail) {
				api.RedrawWindow(te.hwnd, null, 0, RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN);
				this.bTrail = false;
			}
		},

		RButtonDown: function (mode)
		{
			if (api.strcmpi(this.str, "2") == 0) {
				var item = api.Memory("LVITEM");
				item.iItem = this.RButton;
				item.mask = LVIF_STATE;
				item.stateMask = LVIS_SELECTED;
				api.SendMessage(this.hwndGesture, LVM_GETITEM, 0, item.p);
				if (!(item.state & LVIS_SELECTED)) {
					if (mode) {
						var Ctrl = te.CtrlFromWindow(this.hwndGesture);
						Ctrl.SelectItem(Ctrl.Items.Item(this.RButton), SVSI_SELECT | SVSI_DESELECTOTHERS);
					}
					else {
						var ptc = api.Memory("POINT");
						ptc = te.Data.pt.clone();
						api.ScreenToClient(this.hwndGesture, ptc);
						api.SendMessage(this.hwndGesture, WM_RBUTTONDOWN, 0, ptc.x + (ptc.y << 16));
					}
				}
			}
			this.RButton = -1;
		},

		GetButton: function (msg, wParam)
		{
			if (msg >= WM_LBUTTONDOWN && msg <= WM_LBUTTONDBLCLK) {
				return "1";
			}
			if (msg >= WM_RBUTTONDOWN && msg <= WM_RBUTTONDBLCLK) {
				return "2";
			}
			if (msg >= WM_MBUTTONDOWN && msg <= WM_MBUTTONDBLCLK) {
				return "3";
			}
			if (msg >= WM_XBUTTONDOWN && msg <= WM_XBUTTONDBLCLK) {
				switch (wParam >> 16) {
					case XBUTTON1:
						return "4";
					case XBUTTON2:
						return "5";
				}
			}
			return "";
		},

		GetGestureKey: function ()
		{
			var s = "";
			if (api.GetKeyState(VK_SHIFT) < 0) {
				s += "S";
			}
			if (api.GetKeyState(VK_CONTROL) < 0) {
				s += "C";
			}
			if (api.GetKeyState(VK_MENU) < 0) {
				s += "A";
			}
			return s;
		},

		Exec: function (Ctrl, hwnd)
		{
			this.str = this.GetGestureKey() + this.str;

			te.Data.cmdMouse = this.str;
			var cmd = this.All[this.str];
			if (cmd) {
				var a = cmd.split(g_sep);
				return Exec(Ctrl, a[0], a[1], hwnd, null);
			}
			if (!Ctrl) {
				return S_FALSE;
			}
			var s = null;
			switch (Ctrl.Type) {
				case CTRL_SB:
				case CTRL_EB:
					s = "List";
					break;
				case CTRL_TV:
					s = "Tree";
					break;
				case CTRL_TC:
					s = "Tabs";
					break;
				case CTRL_WB:
					s = "Browser";
					break;
			}
			if (s) {
				var cmd = this[s][this.str];
				if (cmd) {
					var a = cmd.split(g_sep);
					return Exec(Ctrl, a[0], a[1], hwnd, null);
				}
			}
			return S_FALSE;
		}
	};
	g_mouse.Init();

	te.OnMouseMessage = function (Ctrl, hwnd, msg, mouseData, pt, wHitTestCode, dwExtraInfo)
	{
		if (msg == WM_MOUSEWHEEL) {
			if (api.GetKeyState(VK_RBUTTON) < 0) {
				var TC = te.Ctrl(CTRL_TC);
				if (TC) {
					ChangeTab(TC, -mouseData / (120 * 65536))
					g_mouse.CancelButton = true;
					return S_OK;
				}
			}
			var Ctrl2 = te.CtrlFromPoint(pt);
			if (Ctrl2) {
				if (Ctrl2.Type == CTRL_TC) {
					ChangeTab(Ctrl2, -mouseData / (120 * 65536))
					return S_OK;
				}
				var hwnd2 = api.WindowFromPoint(pt);
				if (hwnd2 && hwnd != hwnd2) {
					api.SendMessage(hwnd2, msg, mouseData, pt.x + (pt.y << 16));
					return S_OK;
				}
			}
		}
		if (msg == WM_LBUTTONUP || msg == WM_RBUTTONUP || msg == WM_MBUTTONUP || msg == WM_XBUTTONUP) {
			if (g_mouse.GetButton(msg, mouseData) == g_mouse.str.charAt(0)) {
				var hr = S_FALSE;
				var bButton = false;
				if (g_mouse.RButton >= 0 && msg == WM_RBUTTONUP) {
					g_mouse.RButtonDown(true);
					bButton = api.strcmpi(g_mouse.str, "2") == 0;
				}
				if (g_mouse.str.length >= 2 || !IsDrag(pt, te.Data.pt)) {
					hr = g_mouse.Exec(te.CtrlFromWindow(g_mouse.hwndGesture), g_mouse.hwndGesture);
				}
				var s = g_mouse.str;
				g_mouse.EndGesture(false);
				if (g_mouse.bCapture) {
					api.ReleaseCapture();
					g_mouse.bCapture = false;
				}
				if (g_mouse.CancelButton || hr == S_OK) {
					g_mouse.CancelButton = false;
					return S_OK;
				}
				if (bButton) {
					api.PostMessage(g_mouse.hwndGesture, WM_CONTEXTMENU, g_mouse.hwndGesture, pt.x + (pt.y << 16));
					return S_OK;
				}
			}
		}
		if (msg == WM_LBUTTONDOWN || msg == WM_RBUTTONDOWN || msg == WM_MBUTTONDOWN || msg == WM_XBUTTONDOWN) {
			clearTimeout(g_mouse.tidDblClk);
			if (g_mouse.tidDblClk && msg == WM_LBUTTONDOWN && Ctrl.Type == CTRL_EB) {
				g_mouse.tidDblClk = false;
				msg = WM_LBUTTONDBLCLK;
			}
			if (g_mouse.str.length == 0) {
				te.Data.pt = pt;
				g_mouse.ptGesture.x = pt.x;
				g_mouse.ptGesture.y = pt.y;
				g_mouse.hwndGesture = hwnd;
				if (msg == WM_LBUTTONDOWN && Ctrl.Type == CTRL_EB) {
					g_mouse.tidDblClk = true;
					g_mouse.tidDblClk = setTimeout("g_mouse.tidDblClk = false", api.GetDoubleClickTime());
				}
			}
			g_mouse.str += g_mouse.GetButton(msg, mouseData);
			if (g_mouse.str.length > 1) {
				g_mouse.StartGestureTimer();
			}
			document.getElementById("mouse").innerHTML = g_mouse.GetGestureKey() + g_mouse.str;
			if (msg == WM_RBUTTONDOWN) {
				if (g_mouse.Gestures >= 2) {
					var iItem = -1;
					if (Ctrl.Type == CTRL_SB || Ctrl.Type == CTRL_EB) {
						iItem = Ctrl.HitTest(pt, LVHT_ONITEM);
						if (iItem < 0) {
							return S_OK;
						}
					}
					if (g_mouse.Gestures == 3) {
						g_mouse.RButton = iItem;
						g_mouse.StartGestureTimer();
						return S_OK;
					}
				}
			}
		}
		if (msg == WM_LBUTTONDBLCLK || msg == WM_RBUTTONDBLCLK || msg == WM_MBUTTONDBLCLK || msg == WM_XBUTTONDBLCLK) {
			var strClass = api.GetClassName(hwnd);
			if (api.strcmpi(strClass, WC_HEADER)) {
				te.Data.pt = pt;
				g_mouse.str = g_mouse.GetButton(msg, mouseData);
				g_mouse.str += g_mouse.str;
				var hr = g_mouse.Exec(Ctrl, hwnd);
				g_mouse.EndGesture(false);
				if (hr == S_OK) {
					return hr;
				}
			}
		}

		if (msg == WM_MOUSEMOVE) {
			if (g_mouse.str.length && (g_mouse.Gestures > 1 && api.GetKeyState(VK_RBUTTON) < 0) || (g_mouse.Gestures && (api.GetKeyState(VK_MBUTTON) < 0 || api.GetKeyState(VK_XBUTTON1) < 0 || api.GetKeyState(VK_XBUTTON2) < 0))) {
				var x = (pt.x - g_mouse.ptGesture.x);
				var y = (pt.y - g_mouse.ptGesture.y);
				if (Math.abs(x) + Math.abs(y) >= 20) {
					if (g_mouse.TrailSize) {
						var hdc = api.GetWindowDC(te.hwnd);
						if (hdc) {
							var rc = api.Memory("RECT");
							api.GetWindowRect(te.hwnd, rc);
							api.MoveToEx(hdc, g_mouse.ptGesture.x - rc.left, g_mouse.ptGesture.y - rc.top, null);
							var pen1 = api.CreatePen(PS_SOLID, g_mouse.TrailSize, g_mouse.TrailColor);
							var hOld = api.SelectObject(hdc, pen1);
							api.LineTo(hdc, pt.x - rc.left, pt.y - rc.top);
							api.SelectObject(hdc, hOld);
							api.DeleteObject(pen1);
							g_mouse.bTrail = true;
							api.ReleaseDC(te.hwnd);
						}
					}
					g_mouse.ptGesture.x = pt.x;
					g_mouse.ptGesture.y = pt.y;
					var s;
					if (Math.abs(x) >= Math.abs(y)) {
						if (x < 0) {
							s = "L";
						}
						else {
							s = "R";
						}
					}
					else if (y < 0) {
						s = "U";
					}
					else {
						s = "D";
					}
					if (s != g_mouse.str.charAt(g_mouse.str.length - 1)) {
						g_mouse.str += s;
						document.getElementById("mouse").innerHTML = g_mouse.GetGestureKey() + g_mouse.str;
					}
					if (!g_mouse.bCapture) {
						api.SetCapture(g_mouse.hwndGesture);
						g_mouse.bCapture = true;
					}
					g_mouse.StartGestureTimer();
				}
			}
			if (Ctrl.Type == CTRL_TC) {
				if (!te.Data.DragTab) {
					if (api.GetKeyState(VK_LBUTTON) < 0) {
						if (IsDrag(pt, te.Data.pt)) {
							g_mouse.str = "";
							document.getElementById("mouse").innerHTML = "";
							te.Data.pt = null;
							var i = Ctrl.HitTest(pt, TCHT_ONITEM);
							if (i >= 0) {
								var pdwEffect = api.Memory("DWORD");
								pdwEffect.X = DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK;
								te.Data.DragTab = Ctrl;
								te.Data.DragIndex = i;
								api.DoDragDrop(Ctrl.Item(i).FolderItem, pdwEffect.X, pdwEffect);
								te.Data.DragTab = null;
							}
						}
					}
				}
			}
		}
		if (g_mouse.str.length >= 2) {
			return S_OK;
		}
		if (g_mouse.MouseMessage) {
			return g_mouse.MouseMessage(Ctrl, hwnd, msg, mouseData, pt, wHitTestCode, dwExtraInfo);
		}
		return S_FALSE;
	}

	te.OnDragEnter = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = E_NOTIMPL;
		if (g_mouse.DragEnter) {
			hr = g_mouse.DragEnter(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		g_mouse.str = "";
		return hr;
	}
}

