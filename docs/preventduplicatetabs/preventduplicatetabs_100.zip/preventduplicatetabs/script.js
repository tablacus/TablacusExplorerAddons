﻿if (Addon == 1) {
	g_prevantduplicatetabs_OnBeforeNavigate = external.OnBeforeNavigate;

	external.OnBeforeNavigate = function (Ctrl, fs, wFlags)
	{
		var hr = S_OK;
		if (g_prevantduplicatetabs_OnBeforeNavigate) {
			hr = g_prevantduplicatetabs_OnBeforeNavigate(Ctrl, fs, wFlags);
		}
		if (hr == S_OK) {
			var Tabs = Ctrl.Parent;
			var i = Tabs.Count;
			while (--i >= 0) {
				var Item = Tabs.Item(i);
				if (Ctrl.hwnd != Item.hwnd && api.ILIsEqual(Ctrl.FolderItem, Item.FolderItem)) {
					if (!(wFlags & SBSP_ACTIVATE_NOFOCUS) || Tabs.Selected.hwnd == Ctrl.hwnd) {
						Tabs.SelectedIndex = i;
					}
					hr = E_FAIL;
					break;
				}
			}
		}
		return hr;
	}
}

function CreateTab()
{
	Navigate(0, SBSP_NEWBROWSER);
}
