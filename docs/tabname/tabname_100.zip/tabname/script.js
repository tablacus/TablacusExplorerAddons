if (window.Addon == 1) {
	g_tabname = {
		db: {}
	};

	var xml = OpenXml("tabname.xml", true, false);
	if (xml) {
		var items = xml.getElementsByTagName('Item');
		for (i = items.length - 1; i >= 0; i--) {
			g_tabname.db[items[i].getAttribute("Path")] = items[i].text;
		}
	}

	ChangeTabName = function (Ctrl)
	{
		if (Ctrl.FolderItem) {
			var s = g_tabname.db[api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSING | SHGDN_FORPARSINGEX)];
			Ctrl.Title = s ? s : Ctrl.FolderItem.Name.replace(/&/g, "&&");
		}
	}

	AddEvent("Tabs", function (Ctrl, hMenu, nPos)
	{
		api.InsertMenu(hMenu, nPos, MF_BYPOSITION | MF_STRING, ++nPos, GetText('Name the Tab...'));
		ExtraMenuCommand[nPos] = function (Ctrl, pt)
		{
			var i = Ctrl.HitTest(pt, TCHT_ONITEM);
			var FV = Ctrl.Item(i);
			if (!FV) {
				FV = Ctrl.Selected;
			}
			if (FV) {
				var path = api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
				var s = FV.Title.replace(/&&/g, "&");
				s = InputDialog(s, s);
				if (s !== null) {
					if (s.length) {
						g_tabname.db[path] = s;
					}
					else {
						delete g_tabname.db[path];
						s = FV.FolderItem.Name;
					}
					FV.Title = s.replace(/&/g, "&&");
					g_tabname.db[true] = true;
				}
			}
		}
		return nPos;
	});

	AddEvent("Finalize", function ()
	{
		if (g_tabname.db[true]) {
			delete g_tabname.db[true];
			var xml = CreateXml();
			var root = xml.createElement("TablacusExplorer");

			for (var path in g_tabname.db) {
				var name = g_tabname.db[path];
				if (path && name) {
					var item = xml.createElement("Item");
					item.setAttribute("Path", path);
					item.text = name;
					root.appendChild(item);
				}
			}
			xml.appendChild(root);
			SaveXmlEx("tabname.xml", xml, true);
		}
	});
}
