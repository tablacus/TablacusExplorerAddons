﻿var Addon_Id = "retouch";
var Default = "ToolBar2Left";

if (window.Addon == 1) {
	g_retouch =
	{
		Click: function ()
		{
			var FV = te.Ctrl(CTRL_FV);
			if (FV) {
				var Selected = FV.SelectedItems();
				if (Selected.Count) {
					showModelessDialog("../addons/retouch/preview.html", window, "dialogWidth: 800px; dialogHeight: 600px; resizable: yes; status: 0");
				}
			}
		}
	};

	var s = (window.IconSize == 16) ? 'src="../image/toolbar/s_1_14.png" bitmap="ieframe.dll,216,16,14"' : 'src="../image/toolbar/m_1_14.png" bitmap="ieframe.dll,214,24,14"';
	s = '<span class="button" id="RetouchButton" onclick="g_retouch.Click()" onmouseover="MouseOver(this)" onmouseout="MouseOut()"><img title="Retouch" ' + s + '></span><span style="width: 1px"> </span>';
	SetAddon(Addon_Id, Default, s);
}
else {
	g_retouch =
	{
		Load: function ()
		{
			tid: null,

			ApplyLang(document);
			var FV = te.Ctrl(CTRL_FV);
			if (FV) {
				var Selected = FV.SelectedItems();
				if (Selected.Count) {
					g_retouch.File = Selected.Item(0).Path;
					document.title = g_retouch.File;
					g_retouch.Image = te.GdiplusBitmap();
					g_retouch.Image.FromFile(g_retouch.File);
					if (g_retouch.File.match(/\.jpe?g/i)) {
						var hBM = g_retouch.Image.GetHBITMAP(0);
						if (hBM) {
							g_retouch.Image.FromHBITMAP(hBM, 0);
							api.DeleteObject(hBM);
						}
					}
					g_retouch.Width = g_retouch.Image.GetWidth();
					g_retouch.Height = g_retouch.Image.GetHeight();
					document.F.percent.value = 100;
					document.F.rotation.value = 0;
					g_retouch.Change(document.F.percent);
				}
			}
		},

		Change: function (x)
		{
			clearTimeout(g_retouch.tid);
			switch (x.name) {
				case 'width':
					if (document.F.width.value == 0) {
						return;
					}
					document.F.height.value = Math.round(document.F.width.value * g_retouch.Height / g_retouch.Width);
					document.F.percent.value = document.F.width.value / g_retouch.Width * 100;
					break;
				case 'height':
					if (document.F.height.value == 0) {
						return;
					}
					document.F.width.value = Math.round(document.F.height.value * g_retouch.Width / g_retouch.Height);
					document.F.percent.value = document.F.width.value / g_retouch.Width * 100;
					break;
				case 'percent':
					if (document.F.percent.value == 0) {
						return;
					}
					document.F.width.value = Math.round(g_retouch.Width * document.F.percent.value / 100);
					document.F.height.value = Math.round(g_retouch.Height * document.F.percent.value / 100);
					break;
			}
			var img1 = document.getElementById("img1");
			img1.src = g_retouch.File;
			img1.style.width = document.F.width.value + "px";
			img1.style.height = document.F.height.value + "px";
			img1.style.filter = "progid:DXImageTransform.Microsoft.BasicImage(rotation=" + document.F.rotation.value + ");";
		},

		KeyDown: function (x)
		{
			clearTimeout(g_retouch.tid);
			(function (x) { g_retouch.tid = setTimeout(function () {
				g_retouch.Change(x)
			}, 500);}) (x);
		},

		Rotate: function (x)
		{
			document.F.rotation.value = (api.LowPart(document.F.rotation.value) + (api.StrCmpI(x.name, "left") == 0 ? 3 : 1)) % 4;
			g_retouch.Change(document.F.percent);
		},

		Save: function ()
		{
			(function () { setTimeout(function () {
				var commdlg = te.CommonDialog;
				commdlg.InitDir = fso.GetParentFolderName(g_retouch.File);
				commdlg.Filter = "All Files|*.*";
				commdlg.Flags = OFN_FILEMUSTEXIST | OFN_OVERWRITEPROMPT;
				if (commdlg.ShowSave()) {
					var path = commdlg.FileName;
					if (fso.GetExtensionName(path) == "") {
						path = fso.BuildPath(fso.GetParentFolderName(path), fso.GetBaseName(path) + "." + fso.GetExtensionName(g_retouch.File));
					}
					var thum = g_retouch.Image;
					if (document.F.width.value != thum.GetWidth() || document.F.height.value != thum.GetHeight()) {
						thum = thum.GetThumbnailImage(document.F.width.value, document.F.height.value);
					}
					thum.RotateFlip(document.F.rotation.value);

					var eps = api.Memory("EncoderParameters", 1);
					eps.Count = 1;
					ep = eps.Parameter(0);
					ep.Guid = EncoderQuality;
					ep.NumberOfValues = 1;
					ep.Type = EncoderParameterValueTypeLong;
					var pTrans = api.Memory("DWORD");
					pTrans.X = document.F.quality.value;
					ep.Value = pTrans.P;
					if (thum.Save(path, eps) == 0) {
						wsh.Popup(GetText("Completed.") + "\n" + path, 0, "Tablacus Explorer", MB_ICONINFORMATION);
						window.close();
					}
				}
			}, 100);}) ();
		}

	};
}
