﻿if (Addon == 1) {
	g_tabs_ToolTip = external.OnToolTip;
	g_tabs_DragEnter = external.OnDragEnter;
	g_tabs_DragOver = external.OnDragOver;
	g_tabs_Drop = external.OnDrop;

	g_tabs_TabViewCreated = TabViewCreated;
	g_tabs_ChangeView = ChangeView;

	g_tidTabDragOver = null;

	var items = external.Data["Addons"].getElementsByTagName("tabs");
	if (items.length) {
		var item = items[0];
		window.OpenMode = item.getAttribute("NewTab");
	}

	external.OnToolTip = function (Ctrl, Index)
	{
		if (Ctrl.Type == CTRL_TC) {
			var FV = Ctrl.Item(Index);
			if (FV) {
				return api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORADDRESSBAR | SHGDN_FORPARSING);
			}
		}
		if (g_tabs_ToolTip) {
			return g_tabs_ToolTip(Ctrl, Index);
		}
	}

	external.OnDragEnter = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = E_NOTIMPL;
		if (g_tabs_DragEnter) {
			hr = g_tabs_DragEnter(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		if (Ctrl.Type == CTRL_TC) {
			if (external.Data['DragTab']) {
				pdwEffect.X = DROPEFFECT_LINK;
			}
			hr = S_OK;
		}
		return hr;
	}

	external.OnDragOver = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = S_OK;
		if (g_tabs_DragOver) {
			hr = g_tabs_DragOver(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		external.Data['grfKeyState'] = grfKeyState;
		var nIndex = -1;
		if (Ctrl.Type == CTRL_TC) {
			nIndex = Ctrl.HitTest(pt, TCHT_ONITEM);
			if (nIndex >= 0) {
				if (IsDrag(pt, g_ptDrag)) {
					clearTimeout(g_tidTabDragOver);
					g_ptDrag.x = pt.x;
					g_ptDrag.y = pt.y;
					g_tidTabDragOver = setTimeout("OverTab()", 300);
				}
			}
			var nDragTab = external.Data['DragIndex'];
			if (external.Data['DragTab'] && nDragTab >= 0) {
				if (nDragTab != nIndex) {
					pdwEffect.X = DROPEFFECT_LINK;
				}
				else {
					pdwEffect.X = DROPEFFECT_NONE;
				}
				return S_OK;
			}
			else if (nIndex >= 0) {
				if (dataObj.Count) {
					var Target = Ctrl.Item(nIndex).FolderItem;
					if (!api.ILIsEqual(dataObj.Item(-1), Target)) {
						var DropTarget = api.DropTarget(Target);
						if (DropTarget) {
							if (DropTarget.DragEnter(dataObj, grfKeyState, pt, pdwEffect) == S_OK) {
								hr = DropTarget.DragOver(grfKeyState, pt, pdwEffect);
								DropTarget.DragLeave();
								return hr;
							}
						}
					}
				}
				pdwEffect.X = DROPEFFECT_NONE;
			}
			else if (dataObj.Item(0) && dataObj.Item(0).IsFolder) {
				pdwEffect.X = DROPEFFECT_LINK;
				return S_OK;
			}
		}
		pdwEffect.X = DROPEFFECT_NONE;
		return hr;
	}

	external.OnDrop = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var nIndex = -1;

		if (Ctrl.Type == CTRL_TC) {
			var nIndex = Ctrl.HitTest(pt, TCHT_ONITEM);
			if (external.Data['DragTab']) {
				pdwEffect.X = DROPEFFECT_LINK;
				if (nIndex < 0) {
					nIndex = Ctrl.Count;
				}
				external.Data['DragTab'].Move(external.Data['DragIndex'], nIndex, Ctrl);
				Ctrl.SelectedIndex = nIndex;
			}
			else if (nIndex >= 0) {
				Ctrl.SelectedIndex = nIndex;
//				var DropTarget = api.DropTarget(Ctrl.Item(nIndex).FolderItem);
				var DropTarget = Ctrl.Item(nIndex).DropTarget;
				if (DropTarget) {
					grfKeyState = external.Data['grfKeyState'];
					if (DropTarget.DragEnter(dataObj, grfKeyState, pt, pdwEffect) == S_OK) {
						if (DropTarget.DragOver(grfKeyState, pt, pdwEffect) == S_OK) {
							hr = DropTarget.Drop(dataObj, grfKeyState, pt, pdwEffect);
						}
						DropTarget.DragLeave();
						return hr;
					}
				}
			}
			else if (dataObj.Count) {
				for (var i = 0; i < dataObj.Count; i++) {
					var FV = Ctrl.Selected.Navigate(dataObj.Item(i), SBSP_NEWBROWSER | SBSP_ACTIVATE_NOFOCUS);
					Ctrl.Move(FV.Index, Ctrl.Count - 1);
				}
			}
		}
		if (g_tabs_Drop) {
			return g_tabs_Drop(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		return S_OK;
	}

	TabViewCreated = function (Ctrl)
	{
		var LogFont = api.Memory("LOGFONT");
		api.SystemParametersInfo(SPI_GETICONTITLELOGFONT, LogFont.Size, LogFont, 0);
		var hFont = api.CreateFontIndirect(LogFont);
		api.SendMessage(Ctrl.hwnd, WM_SETFONT, hFont, 1);
		api.SendMessage(Ctrl.hwnd, TCM_SETIMAGELIST, 0, external.Data["himlTC"]);
		if (g_tabs_TabViewCreated) {
			return g_tabs_TabViewCreated(Ctrl);
		}
	}

	ChangeView = function (Ctrl)
	{
		if (window.ChangeTabName) {
			window.ChangeTabName(Ctrl);
		}
		else {
			Ctrl.Title = Ctrl.FolderItem.Name.replace(/&/g, "&&");
		}
		if (g_tabs_ChangeView) {
			return g_tabs_ChangeView(Ctrl);
		}
	}
}

function OverTab()
{
	pt = api.Memory("POINT");
	api.GetCursorPos(pt);
	if (!IsDrag(pt, g_ptDrag)) {
		Ctrl = external.CtrlFromPoint(pt);
		if (Ctrl.Type == CTRL_TC) {
			var nIndex = Ctrl.HitTest(pt, TCHT_ONITEM);
			if (nIndex >= 0) {
				Ctrl.SelectedIndex = nIndex;
			}
		}
	}
}

