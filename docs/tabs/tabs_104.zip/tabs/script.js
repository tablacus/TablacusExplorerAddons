﻿if (Addon == 1) {
	window.g_tabs = new Object();
	g_tabs.ToolTip = external.OnToolTip;
	g_tabs.DragEnter = external.OnDragEnter;
	g_tabs.DragOver = external.OnDragOver;
	g_tabs.Drop = external.OnDrop;
	g_tabs.DragLeave = external.OnDragleave;

	g_tabs.TabViewCreated = TabViewCreated;
	g_tabs.ChangeView = ChangeView;

	g_tabs.tid = null;

	var items = external.Data["Addons"].getElementsByTagName("tabs");
	if (items.length) {
		var item = items[0];
		window.OpenMode = item.getAttribute("NewTab");
	}

	external.OnToolTip = function (Ctrl, Index)
	{
		if (Ctrl.Type == CTRL_TC) {
			var FV = Ctrl.Item(Index);
			if (FV) {
				return api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORADDRESSBAR | SHGDN_FORPARSING);
			}
		}
		if (g_tabs.ToolTip) {
			return g_tabs.ToolTip(Ctrl, Index);
		}
	}

	external.OnDragEnter = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = E_NOTIMPL;
		if (g_tabs.DragEnter) {
			hr = g_tabs.DragEnter(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		if (Ctrl.Type == CTRL_TC) {
			if (external.Data['DragTab']) {
				pdwEffect.X = DROPEFFECT_LINK;
			}
			hr = S_OK;
		}
		return hr;
	}

	external.OnDragOver = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = S_OK;
		if (g_tabs.DragOver) {
			hr = g_tabs.DragOver(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		external.Data['grfKeyState'] = grfKeyState;
		var nIndex = -1;
		if (Ctrl.Type == CTRL_TC) {
			nIndex = Ctrl.HitTest(pt, TCHT_ONITEM);
			if (nIndex >= 0) {
				if (IsDrag(pt, g_ptDrag)) {
					clearTimeout(g_tabs.tid);
					g_ptDrag.x = pt.x;
					g_ptDrag.y = pt.y;
					g_tabs.tid = setTimeout("OverTab()", 300);
				}
			}
			var nDragTab = external.Data['DragIndex'];
			if (external.Data['DragTab'] && nDragTab >= 0) {
				if (nDragTab != nIndex) {
					pdwEffect.X = DROPEFFECT_LINK;
				}
				else {
					pdwEffect.X = DROPEFFECT_NONE;
				}
				return S_OK;
			}
			else if (nIndex >= 0) {
				if (dataObj.Count) {
					var Target = Ctrl.Item(nIndex).FolderItem;
					if (!api.ILIsEqual(dataObj.Item(-1), Target)) {
						var DropTarget = api.DropTarget(Target);
						if (DropTarget) {
							if (DropTarget.DragEnter(dataObj, grfKeyState, pt, pdwEffect) == S_OK) {
								hr = DropTarget.DragOver(grfKeyState, pt, pdwEffect);
								DropTarget.DragLeave();
								return hr;
							}
						}
					}
				}
				pdwEffect.X = DROPEFFECT_NONE;
			}
			else if (dataObj.Item(0) && dataObj.Item(0).IsFolder) {
				pdwEffect.X = DROPEFFECT_LINK;
				return S_OK;
			}
		}
		return hr;
	}

	external.OnDrop = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var nIndex = -1;

		if (Ctrl.Type == CTRL_TC) {
			var nIndex = Ctrl.HitTest(pt, TCHT_ONITEM);
			if (external.Data['DragTab']) {
				pdwEffect.X = DROPEFFECT_LINK;
				if (nIndex < 0) {
					nIndex = Ctrl.Count;
				}
				external.Data['DragTab'].Move(external.Data['DragIndex'], nIndex, Ctrl);
				Ctrl.SelectedIndex = nIndex;
			}
			else if (nIndex >= 0) {
				Ctrl.SelectedIndex = nIndex;
//				var DropTarget = api.DropTarget(Ctrl.Item(nIndex).FolderItem);
				var DropTarget = Ctrl.Item(nIndex).DropTarget;
				if (DropTarget) {
					grfKeyState = external.Data['grfKeyState'];
					if (DropTarget.DragEnter(dataObj, grfKeyState, pt, pdwEffect) == S_OK) {
						if (DropTarget.DragOver(grfKeyState, pt, pdwEffect) == S_OK) {
							pdwEffect.X = DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK;
							hr = DropTarget.Drop(dataObj, grfKeyState, pt, pdwEffect);
						}
						DropTarget.DragLeave();
						return hr;
					}
				}
			}
			else if (dataObj.Count) {
				for (var i = 0; i < dataObj.Count; i++) {
					var FV = Ctrl.Selected.Navigate(dataObj.Item(i), SBSP_NEWBROWSER | SBSP_ACTIVATE_NOFOCUS);
					Ctrl.Move(FV.Index, Ctrl.Count - 1);
				}
			}
		}
		if (g_tabs.Drop) {
			return g_tabs.Drop(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		return S_OK;
	}

	external.OnDragleave = function (Ctrl)
	{
		var hr = S_OK;
		if (g_tabs.DragLeave) {
			hr = g_tabs.DragLeave(Ctrl);
		}
		clearTimeout(g_tabs.tid);
		g_tabs.tid = null;
		return hr;
	}

	TabViewCreated = function (Ctrl)
	{
		var LogFont = api.Memory("LOGFONT");
		api.SystemParametersInfo(SPI_GETICONTITLELOGFONT, LogFont.Size, LogFont, 0);
		var hFont = api.CreateFontIndirect(LogFont);
		api.SendMessage(Ctrl.hwnd, WM_SETFONT, hFont, 1);
		api.SendMessage(Ctrl.hwnd, TCM_SETIMAGELIST, 0, external.Data["himlTC"]);
		if (g_tabs.TabViewCreated) {
			return g_tabs.TabViewCreated(Ctrl);
		}
	}

	ChangeView = function (Ctrl)
	{
		if (window.ChangeTabName) {
			window.ChangeTabName(Ctrl);
		}
		else if (Ctrl.FolderItem) {
			Ctrl.Title = Ctrl.FolderItem.Name.replace(/&/g, "&&");
		}
		if (g_tabs.ChangeView) {
			return g_tabs.ChangeView(Ctrl);
		}
	}
}

function OverTab()
{
	pt = api.Memory("POINT");
	api.GetCursorPos(pt);
	if (!IsDrag(pt, g_ptDrag)) {
		Ctrl = external.CtrlFromPoint(pt);
		if (Ctrl && Ctrl.Type == CTRL_TC) {
			var nIndex = Ctrl.HitTest(pt, TCHT_ONITEM);
			if (nIndex >= 0) {
				Ctrl.SelectedIndex = nIndex;
			}
		}
	}
}

