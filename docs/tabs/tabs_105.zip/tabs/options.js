﻿returnValue = false;

function InitOptions()
{
	var InstalledFolder = fso.GetParentFolderName(api.GetModuleFileName(null));

	ApplyLang(document);
	info = GetAddonInfo("tabs");
	document.title = info.Name;
	var items = te.Data.Addons.getElementsByTagName("tabs");
	if (items.length) {
		var item = items[0];
		document.F.NewTab.checked = item.getAttribute("NewTab") == 2;
	}
}

function SetOptions()
{
	var items = te.Data.Addons.getElementsByTagName("tabs");
	if (items.length) {
		var item = items[0];
		item.setAttribute("NewTab", (document.F.NewTab.checked) ? 2 : 1);
		returnValue = true;
	}
	window.close();
}
