if (window.Addon == 1) {
	const Addon_Id = "sendto";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
