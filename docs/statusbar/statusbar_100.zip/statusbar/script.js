﻿var Addon_Id = "statusbar";
var Default = "BottomBar3Left";

if (Addon == 1) {
	var Location = null;
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		Location = items[0].getAttribute("Location");
	}
	if (!Location) {
		Location = Default;
	}
	var o = document.getElementById(Location);
	o.innerHTML += '<span id="statusbar">&nbsp;</span>';
	o.style.display = "block";
	external.Data["Locations"].push(Location + "\t" + Addon_Id);

	g_statusbar_StatusText = external.OnStatusText;

	external.OnStatusText = function (Ctrl, StatusText, iPart)
	{
		if (Ctrl.Type == CTRL_SB && StatusText.match(/^\d/)) {
			var Items = Ctrl.SelectedItems();
			if (Items.Count == 1) {
				var Item = Items.Item(0);
				var Folder = Ctrl.Folder;
				StatusText = Folder.GetDetailsOf(Item, 3);
				var Size = Item.Size;
				if (Size || !Item.IsFolder) {
					Size += "";
					while (Size != (Size = Size.replace(/^(-?\d+)(\d{3})/, "$1,$2")));				
					StatusText += "&nbsp;" + GetText("Size") + ": " + Folder.GetDetailsOf(Item, 1) + "&nbsp;(" + Size + ')';
				}
			}
		}
		document.getElementById("statusbar").innerHTML = "&nbsp" + StatusText;
		if (g_statusbar_StatusText) {
			return g_statusbar_StatusText(Ctrl, StatusText, iPart);
		}
		return S_OK;
	}
}
