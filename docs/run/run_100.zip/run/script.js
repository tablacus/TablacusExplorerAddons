﻿var Addon_Id = "run";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var s;
	if (window.IconSize == 16) {
		s = '<a href="#" onclick="this.blur(); return RunDialog();" class="button"><img  alt="Run" src="../image/toolbar/s_3_76.png" icon="shell32.dll,24,16"></a> ';
	}
	else {
		s = '<a href="#" onclick="this.blur(); return RunDialog();" class="button"><img  alt="Run" src="../image/toolbar/l_3_76.png" width="24px" height="24px" icon="shell32.dll,24,32"></a> ';
	}
	var Location = null;
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		Location = items[0].getAttribute("Location");
	}
	if (!Location) {
		Location = Default;
	}
	var o = document.getElementById(Location);
	o.innerHTML += s;
	o.style.display = "block";
	external.Data["Locations"].push(Location + "\t" + Addon_Id);
}

function RunDialog()
{
	var path = "";
	var FV = external.Ctrl(CTRL_FV);
	if (FV && FV.FolderItem) {
		path = api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORPARSING);
	}
	api.ShRunDialog(external.hwnd, 0, path, null, null, 0);
	wsh.CurrentDirectory = "C:\\";
	return false;
}
