﻿if (window.Addon == 1) {
	g_innerforward =
	{
		Click: function (Id)
		{
			var FV = GetInnerFV(Id);
			if (FV) {
				FV.Navigate(null, SBSP_NAVIGATEFORWARD | SBSP_SAMEBROWSER);
			}
			return false;
		},

		Popup: function (o, Id)
		{
			var FV = GetInnerFV(Id);
			if (FV) {
				var Log = FV.History;
				var hMenu = api.CreatePopupMenu();
				FolderMenu.Clear();
				for (var i = Log.Index - 1; i >= 0; i--) {
					FolderMenu.AddMenuItem(hMenu, Log.Item(i));
				}
				var pt = api.Memory("POINT");
				api.GetCursorPos(pt);
				var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, external.hwnd, null, null);
				api.DestroyMenu(hMenu);
				if (nVerb) {
					var FolderItem = FolderMenu.Items[nVerb - 1];
					switch (window.g_menu_button - 0) {
						case 2:
							PopupContextMenu(FolderItem);
							break;
						case 3:
							Navigate(FolderItem, SBSP_NEWBROWSER);
							break;
						default:
							Navigate(FolderItem, OpenMode);
							break;
					}
				}
				FolderMenu.Clear();
			}
		}
	};

	AddEvent("PanelCreated", function (Ctrl)
	{
		var s = '<span class="button" onclick="return g_innerforward.Click($)" oncontextmenu="g_innerforward.Popup(this, $); return false;" onmouseover="MouseOver(this)" onmouseout="MouseOut()"><img id="ImgForward_$" alt="Forward" src="../image/toolbar/s_1_1.png" bitmap="ieframe.dll,216,16,1"></span><span style="width: 0px"> </span>';
		SetAddon(null, "Inner1Left_" + Ctrl.Id, s.replace(/\$/g, Ctrl.Id));
	});

	AddEvent("ChangeView", function (Ctrl)
	{
		var Log = Ctrl.History;
		var TC = Ctrl.Parent;
		if (TC) {
			var o = document.getElementById("ImgForward_" + TC.Id);
			if (o) {
				o.style.filter = (Log && Log.Index == 0) ? "progid:DXImageTransform.Microsoft.BasicImage(GrayScale=1, Opacity=.48);" : "";
			}
		}
		return g_innerforward.ChangeView ? g_innerforward.ChangeView(Ctrl) : S_OK;
	});
}
