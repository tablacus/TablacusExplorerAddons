if (window.Addon == 1) {
	const Addon_Id = "segmdl2";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
