﻿if (window.Addon == 1) {
	g_innerback =
	{
		Click: function (Id)
		{
			var FV = GetInnerFV(Id);
			if (FV) {
				FV.Navigate(null, SBSP_NAVIGATEBACK | SBSP_SAMEBROWSER);
			}
			return false;
		},

		Popup: function (o, id)
		{
			var FV = GetInnerFV(id);
			if (FV) {
				var Log = FV.History;
				var hMenu = api.CreatePopupMenu();
				FolderMenu.Clear();
				for (var i = Log.Index + 1; i < Log.Count; i++) {
					FolderMenu.AddMenuItem(hMenu, Log.Item(i));
				}
				var pt = api.Memory("POINT");
				api.GetCursorPos(pt);
				window.g_menu_click = true;
				var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, te.hwnd, null, null);
				api.DestroyMenu(hMenu);
				if (nVerb) {
					var FolderItem = FolderMenu.Items[nVerb - 1];
					switch (window.g_menu_button - 0) {
						case 2:
							PopupContextMenu(FolderItem);
							break;
						case 3:
							Navigate(FolderItem, SBSP_NEWBROWSER);
							break;
						default:
							Navigate(FolderItem, OpenMode);
							break;
					}
				}
				FolderMenu.Clear();
			}
			return false;
		}
	};

	AddEvent("PanelCreated", function (Ctrl)
	{
		var s = '<span class="button" onclick="return g_innerback.Click($)" oncontextmenu="g_innerback.Popup(this, $); return false;" onmouseover="MouseOver(this)" onmouseout="MouseOut()"><img id="ImgBack_$" alt="Back" src="../image/toolbar/s_1_0.png" bitmap="ieframe.dll,216,16,0"></span><span style="width: 0px"> </span>';
		SetAddon(null, "Inner1Left_" + Ctrl.Id, s.replace(/\$/g, Ctrl.Id));
	});

	AddEvent("ChangeView", function (Ctrl)
	{
		var Log = Ctrl.History;
		var TC = Ctrl.Parent;
		if (TC) {
			var o = document.getElementById("ImgBack_" + TC.Id);
			if (o) {
				o.style.filter = (Log && Log.Index >= Log.Count - 1) ? "progid:DXImageTransform.Microsoft.BasicImage(GrayScale=1, Opacity=.48);" : "";
			}
		}
	});
}

