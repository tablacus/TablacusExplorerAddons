if (window.Addon == 1) {
	te.AddEvent("GetImage", te.ThumbnailProvider);
}
