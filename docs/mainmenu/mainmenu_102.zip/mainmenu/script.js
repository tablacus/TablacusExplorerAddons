﻿var Addon_Id = "mainmenu";
var Default = "ToolBar1Left";

if (Addon == 1) {
	var strMenus = ["&File", "&Edit", "&View", "F&avorites", "&Tools", "&Help"];
	var s = '';
	for (var i = 0; i < strMenus.length; i++) {
		var s1 = strMenus[i].replace("&", "");
		s += '<label class="menu" id="Menu' + s1 + '" onmousedown="MainMenu(\'' + s1 + '\', this)" onmouseover="MouseOver(this)" onmouseout="MouseOut()">' + strMenus[i] + '</label>';
	}
	SetAddon(Addon_Id, Default, s);
}

function MainMenu(Name, o)
{
	(function (Name, o) { setTimeout(function () {
		var p = GetPos(o, true);
		MouseOver(o);
		window.Ctrl = external;
		ExecMenu2(Name, p.x, p.y + o.offsetHeight);
		MouseOut();
	}, 100);}) (Name, o);
}
