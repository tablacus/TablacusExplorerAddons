﻿var Addon_Id = "mainmenu";
var Default = "ToolBar1Left";

if (Addon == 1) {
	var s = '<a href="#" onclick="blur(); return false" onmousedown="MainMenu(\'File\', this)" class="menu" id="MenuFile">&File</a>';
	s += '<a href="#" onclick="blur(); return false" onmousedown="MainMenu(\'Edit\', this)" class="menu" id="MenuEdit">&Edit</a>';
	s += '<a href="#" onclick="blur(); return false" onmousedown="MainMenu(\'View\', this)" class="menu" id="MenuView">&View</a>';
	s += '<a href="#" onclick="blur(); return false" onmousedown="MainMenu(\'Favorites\', this)" class="menu" id="MenuFavorites">F&avorites</a>';
	s += '<a href="#" onclick="blur(); return false" onmousedown="MainMenu(\'Tools\', this)" class="menu" id="MenuTools">&Tools</a>';
	s += '<a href="#" onclick="blur(); return false" onmousedown="MainMenu(\'Help\', this)" class="menu" id="MenuHelp">&Help</a>';

	var Location = null;
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		Location = items[0].getAttribute("Location");
	}
	if (!Location) {
		Location = Default;
	}
	var o = document.getElementById(Location);
	o.innerHTML += s;
	o.style.display = "block";
	external.Data["Locations"].push(Location + "\t" + Addon_Id);
}

function MainMenu(Name, o)
{
	var p = GetPos(o);
	window.Ctrl = external;
	setTimeout('ExecMenu2("' + Name + '", ' + (screenLeft + p.x) + ', ' + (screenTop + p.y + o.offsetHeight) + ')', 10);
	setTimeout('BlurId("' + o.id + '")', 100);
}
