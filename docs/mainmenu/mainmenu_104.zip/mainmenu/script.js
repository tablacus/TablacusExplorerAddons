var Addon_Id = "mainmenu";
var Default = "ToolBar1Left";

if (window.Addon == 1) {
	g_mainmenu =
	{
		Menu: [],
		Item: null,
		tid: null,
		bLoop: false,
		tid2: null,
		bClose: false,

		Init: function ()
		{
			var strMenus = ["&File", "&Edit", "&View", "F&avorites", "&Tools", "&Help"];
			var s = '';
			for (var i = 0; i < strMenus.length; i++) {
				var s1 = strMenus[i].replace("&", "");
				s += '<label class="menu" id="Menu' + s1 + '" onmousedown="g_mainmenu.Popup(this)" onmouseover="MouseOver(this)" onmouseout="MouseOut()">' + strMenus[i] + '</label>';
			}
			SetAddon(Addon_Id, Default, s);
			for (var i = 0; i < strMenus.length; i++) {
				var s1 = strMenus[i].replace("&", "");
				this.Menu[i] = document.getElementById('Menu' + s1);
			}
		},

		Popup: function (o)
		{
			if (!g_mainmenu.bClose) {
				this.Item = o;
				clearTimeout(g_mainmenu.tid);
				g_mainmenu.tid = setTimeout(function () {
					g_mainmenu.tid = null;
					var o = g_mainmenu.Item;
					var p = GetPos(o, true);
					MouseOver(o);
					window.Ctrl = te;
					g_mainmenu.bLoop = true;
					AddEvent("ExitMenuLoop", function () {
						g_mainmenu.bLoop = false;
						g_mainmenu.bClose = true;
						clearTimeout(g_mainmenu.tid2);
						g_mainmenu.tid2 = setTimeout("g_mainmenu.bClose = false;", 500);
					})
					ExecMenu2(o.id.replace(/^Menu/, ""), p.x, p.y + o.offsetHeight);
					MouseOut();
				}, 100);
			}
		}
	}

	AddEvent("MouseMessage", function (Ctrl, hwnd, msg, mouseData, pt, wHitTestCode, dwExtraInfo)
	{
		if (g_mainmenu.bLoop && Ctrl.Type == CTRL_TE) {
			if (msg == WM_MOUSEMOVE) {
				var Ctrl2 = te.CtrlFromPoint(pt);
				if (Ctrl2 && Ctrl2.Type == CTRL_WB && !HitTest(g_mainmenu.Item, pt)) {
					for (var i = 0; i < g_mainmenu.Menu.length; i++) {
						if (HitTest(g_mainmenu.Menu[i], pt)) {
							g_mainmenu.bClose = false;
							wsh.SendKeys("{Esc}");
							g_mainmenu.Popup(g_mainmenu.Menu[i]);
							break;
						}
					}
				}
			}
		}
	});

	g_mainmenu.Init();
}

