if (window.Addon != 1) {
	const Addon_Id = "shellexecutehook";
	importScript("addons\\" + Addon_Id + "\\options.js");
}
