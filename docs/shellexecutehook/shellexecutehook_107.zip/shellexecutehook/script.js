﻿var Addon_Id = "shellexecutehook";
if (window.Addon != 1) {
	importScript("addons\\" + Addon_Id + "\\options.js");
}