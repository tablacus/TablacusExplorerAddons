﻿var Addon_Id = "up";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var s;
	if (window.IconSize == 16) {
		s = '<img alt="Up" src="../image/toolbar/s_1_28.png" bitmap="ieframe.dll,216,16,28">';
	}
	else {
		s = '<img alt="Up" src="../image/toolbar/m_1_28.png" bitmap="ieframe.dll,214,24,28">';
	}
	s = '<span class="button" onclick="Navigate(null, SBSP_PARENT | SBSP_SAMEBROWSER);"  onmouseover="MouseOver(this)" onmouseout="MouseOut()">' + s + '</span> ';

	SetAddon(Addon_Id, Default, s);
}
