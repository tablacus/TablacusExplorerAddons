﻿var Addon_Id = "up";
var Default = "ToolBar2Left";

if (window.Addon == 1) {
	g_up =
	{
		Popup: function ()
		{
			var o = document.getElementById("UpButton");
			var FV = external.Ctrl(CTRL_FV);
			if (FV) {
				FolderMenu.Clear();
				var hMenu = api.CreatePopupMenu();
				var FolderItem = FV.FolderItem;
				while (!api.ILIsEmpty(FolderItem)) {
					FolderItem = api.ILRemoveLastID(FolderItem);
					FolderMenu.AddMenuItem(hMenu, FolderItem);
				}
				var pt = api.Memory("POINT");
				api.GetCursorPos(pt);
				window.g_menu_click = true;
				var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, external.hwnd, null, null);
				api.DestroyMenu(hMenu);
				var FolderItem;
				if (nVerb) {
					FolderItem = FolderMenu.Items[nVerb - 1];
				}
				FolderMenu.Clear();
				if (nVerb) {
					switch (window.g_menu_button - 0) {
						case 2:
							PopupContextMenu(FolderItem);
							break;
						case 3:
							Navigate(FolderItem, SBSP_NEWBROWSER);
							break;
						default:
							Navigate(FolderItem, OpenMode);
							break;
					}
				}
			}
		}
	};

	var s = (window.IconSize == 16) ? 'src="../image/toolbar/s_1_28.png" bitmap="ieframe.dll,216,16,28"' : 'src="../image/toolbar/m_1_28.png" bitmap="ieframe.dll,214,24,28"';
	s = '<span class="button" id="UpButton" onclick="Navigate(null, SBSP_PARENT | SBSP_SAMEBROWSER)" oncontextmenu="g_up.Popup(); return false" onmouseover="MouseOver(this)" onmouseout="MouseOut()"><img alt="Up" ' + s + '></span><span style="width: 1px"> </span>';
	SetAddon(Addon_Id, Default, s);
}
