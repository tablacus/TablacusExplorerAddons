﻿var Addon_Id = "up";
var Default = "ToolBar2Left";

if (!window.dialogArguments) {
	g_up =
	{
		Popup: function ()
		{
			var o = document.getElementById("UpButton");
			var FV = external.Ctrl(CTRL_FV);
			if (FV) {
				var hMenu = api.CreatePopupMenu();
				var mii = api.Memory("MENUITEMINFO");
				mii.cbSize = mii.Size;
				mii.fMask  = MIIM_ID | MIIM_STRING | MIIM_BITMAP;
				var arBM = new Array();
				var FolderItem = FV.FolderItem;
				while (!api.ILIsEmpty(FolderItem)) {
					FolderItem = api.ILRemoveLastID(FolderItem);
					var s = ' ' + api.GetDisplayNameOf(FolderItem, SHGDN_INFOLDER);
					var sz = api.Memory(s.length * 2 + 2);
					sz.Write(0, VT_LPWSTR, s);
					mii.dwTypeData = sz.p;
					var image = external.GdiplusBitmap;
					var info = api.Memory("SHFILEINFO");
					api.ShGetFileInfo(FolderItem, 0, info, info.Size, SHGFI_ICON | SHGFI_SMALLICON | SHGFI_PIDL);
					var hIcon = info.hIcon;
					var cl = api.GetSysColor(COLOR_BTNFACE);
					image.FromHICON(hIcon, cl);
					api.DestroyIcon(hIcon);
					arBM[mii.wID] = image.GetHBITMAP(cl);
					mii.hbmpItem = arBM[mii.wID++];
					api.InsertMenuItem(hMenu, MAXINT, false, mii);
				}
				var pt = api.Memory("POINT");
				api.GetCursorPos(pt);
				var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, external.hwnd, null, null);
				api.DestroyMenu(hMenu);
				while (arBM.length) {
					api.DeleteObject(arBM.splice(0, 1));
				}
				if (nVerb) {
					FolderItem = FV.FolderItem;
					while (nVerb--) {
						FolderItem = api.ILRemoveLastID(FolderItem);
					}
					FV.Navigate(FolderItem, SBSP_SAMEBROWSER);
				}
			}
		}
	};

	var s = (window.IconSize == 16) ? 'src="../image/toolbar/s_1_28.png" bitmap="ieframe.dll,216,16,28"' : 'src="../image/toolbar/m_1_28.png" bitmap="ieframe.dll,214,24,28"';
	s = '<span class="button" id="UpButton" onclick="Navigate(null, SBSP_PARENT | SBSP_SAMEBROWSER)" oncontextmenu="g_up.Popup(); return false" onmouseover="MouseOver(this)" onmouseout="MouseOut()"><img alt="Up" ' + s + '></span><span style="width: 1px"> </span>';
	SetAddon(Addon_Id, Default, s);
}
