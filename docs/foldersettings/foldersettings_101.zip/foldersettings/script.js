﻿if (Addon == 1) {
	g_FolderSettings_BeforeNavigate = external.OnBeforeNavigate;
	g_FolderSettings_ListViewCreated = window.ListViewCreated;
	g_FolderSetting_ExtraMenus = ExtraMenus["View"];
	external.Data.xmlFolderSettings = OpenXml("foldersettings.xml", false, true);

	external.OnBeforeNavigate = function (Ctrl, fs, wFlags, PrevPath)
	{
		var hr = S_OK;
		if (g_FolderSettings_BeforeNavigate) {
			hr = g_FolderSettings_BeforeNavigate(Ctrl, fs, wFlags, PrevPath);
		}
		if (hr == S_OK) {
			item = GetFolderSettings(Ctrl);
			if (item) {
				if (item.text.match(/CurrentViewMode\s*=\s*(\d+)/i)) {
					fs.ViewMode = RegExp.$1;
				}
				if (item.text.match(/IconSize\s*=\s*(\d+)/i)) {
					fs.ImageSize = RegExp.$1;
				}
			}
		}
		return hr;
	}

	window.ListViewCreated = function (Ctrl)
	{
		item = GetFolderSettings(Ctrl);
		if (item) {
			Exec(Ctrl, item.text, item.getAttribute("Type"), null);
		}
		if (g_FolderSettings_ListViewCreated) {
			return g_FolderSettings_ListViewCreated(Ctrl);
		}
		return S_OK;
	}

	ExtraMenus["View"] = function (Ctrl, hMenu, nPos)
	{
		ExtraMenuCommand[28722] = function (Ctrl)
		{
			showModelessDialog("../addons/foldersettings/options.html", window, "dialogWidth: 640px; dialogHeight: 480px; resizable: yes; status=0");
		}
		if (g_FolderSetting_ExtraMenus) {
			return g_FolderSetting_ExtraMenus(Ctrl, hMenu, nPos);
		}
		return nPos;
	}
}

function GetFolderSettings(Ctrl)
{
	var items = external.Data.xmlFolderSettings.getElementsByTagName("Item");
	var path = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
	var i = items.length;
	while (--i >= 0) {
		var item = items[i];
		if (api.PathMatchSpec(path, item.getAttribute("Filter"))) {
			return(item);
		}
	}
	return null;
}
