﻿var Addon_Id = "preview";
var Default = "LeftBar3";

if (window.Addon == 1) {
	g_preview = new Object();
	g_preview.tid = null;

	if (!te.Data.Conf_LeftBarWidth) {
		te.Data.Conf_LeftBarWidth = 150;
	}
	var px = (te.Data.Conf_LeftBarWidth - 2) + "px";
	var s = '<div id="PreviewBar" style="width: ' + px + '; height: 100%; background-color: window; border: 1px solid WindowFrame; overflow-x: hidden; overflow-y: hidden;"></div>';
	SetAddon(Addon_Id, Default, s);
	ArrangePreview();

	g_preview.OnSelectionChanged = te.OnSelectionChanged;
	te.OnSelectionChanged = function (Ctrl)
	{
		if ((Ctrl.Type >> 16) == (CTRL_FV >> 16)) {
			clearTimeout(g_preview.tid);
			if (te.offsetLeft && !document.getElementById('PreviewBar').style.display.match(/none/i)) {
				var Selected = Ctrl.SelectedItems();
				if (Selected.Count == 1) {
					(function (Item) { g_preview.tid = setTimeout(function () {
						ArrangePreview(Item);
					}, 500);}) (Selected.Item(0));
				}
			}
		}
		if (g_preview.OnSelectionChanged) {
			g_preview.OnSelectionChanged(Ctrl);
		}
	}

	g_preview.ShowContextMenu = window.ShowContextMenu;
	window.ShowContextMenu = function (Ctrl, hwnd, msg, wParam, pt)
	{
		if (HitTest(document.getElementById("PreviewBar"), pt)) {
			if (g_preview.Item) {
				var hMenu = api.CreatePopupMenu();
				var ContextMenu = api.ContextMenu(g_preview.Item);
				if (ContextMenu) {
					ContextMenu.QueryContextMenu(hMenu, 0, 1, 0x7FFF, CMF_NORMAL);
					var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, te.hwnd, null, ContextMenu);
					if (nVerb) {
						ContextMenu.InvokeCommand(0, te.hwnd, nVerb - 1, null, null, SW_SHOWNORMAL, 0, 0);
					}
				}
				api.DestroyMenu(hMenu);
			}
			return S_OK;
		}
		if (g_preview.ShowContextMenu) {
			return g_preview.ShowContextMenu(Ctrl, hwnd, msg, wParam, pt);
		}
		return S_FALSE;
	}
}

function ArrangePreview(Item)
{
	g_preview.Item = Item;
	var o = document.getElementById('PreviewBar');
	var s = "";
	if (Item) {
		var Folder = sha.NameSpace(Item.Parent);
		var info = Folder.GetDetailsOf(Item, 0) + "\n" + Folder.GetDetailsOf(Item, 1);
		if (Item.IsLink) {
			Item = api.ILCreateFromPath(Item.GetLink.Path);
		}
		var nWidth = 0, nHeight = 0;
		var s1 = Item.ExtendedProperty("{6444048f-4c8b-11d1-8b70-080036b11a03} 13");
		if (s1) {
			info += ' (' + s1 + ')';
			nWidth = Item.ExtendedProperty("{6444048f-4c8b-11d1-8b70-080036b11a03} 3");
			nHeight = Item.ExtendedProperty("{6444048f-4c8b-11d1-8b70-080036b11a03} 4");
		}
		var style = "width: 100%";
		if (nWidth  < nHeight) {
			style = "height: " + te.offsetLeft + "px";
		}
		var info2 = '';
		for (var i = 2; i < 4; i++) {
			info2 += "\n" + Folder.GetDetailsOf(null, i) + ": " + Folder.GetDetailsOf(Item, i);
		}
		s += '<img src="' + Item.Path + '" alt="' + info + info2 + '" style="display: block;' + style + '" onerror="this.style.display=\'none\'" ondrag="PreviewDrag(); return false">';
		s += '<div style="font-size: 10px; margin: 0px 4px">' + info.replace(/\n/g,"<br>") + '</div>';
	}
	else {
		s = '<div style="font-size: 10px; margin-left: 4px">Preview</div>';
	}
	o.innerHTML = s;
	Resize2();
}

function PreviewDrag()
{
	var pdwEffect = api.Memory("DWORD");
	pdwEffect.X = DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK;
	api.DoDragDrop(g_preview.Item, pdwEffect.X, pdwEffect);
}

