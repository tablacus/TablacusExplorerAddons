﻿var Addon_Id = "forward";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var s;
	if (window.IconSize == 16) {
		s = '<img alt="Forward" src="../image/toolbar/s_1_1.png" bitmap="ieframe.dll,216,16,1">';
	}
	else {
		s = '<img alt="Forward" src="../image/toolbar/m_1_1.png" bitmap="ieframe.dll,214,24,1">';
	}
	s = '<span class="button" onclick="Navigate(null, SBSP_NAVIGATEFORWARD | SBSP_SAMEBROWSER)" onmouseover="MouseOver(this)" onmouseout="MouseOut()">' + s + '</span> ';
	SetAddon(Addon_Id, Default, s);
}
