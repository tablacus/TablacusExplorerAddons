﻿var Addon_Id = "forward";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var s;
	if (external.Data["Conf_IconSize"] == 16) {
		s = '<img id="ImgForward" alt="Forward" src="../image/toolbar/s_1_1.png" bitmap="ieframe.dll,216,16,1">';
	}
	else {
		s = '<img id="ImgForward" alt="Forward" src="../image/toolbar/m_1_1.png" bitmap="ieframe.dll,214,24,1">';
	}
	s = '<span class="button" onclick="Navigate(null, SBSP_NAVIGATEFORWARD | SBSP_SAMEBROWSER)" onmouseover="MouseOver(this)" onmouseout="MouseOut()">' + s + '</span> ';
	SetAddon(Addon_Id, Default, s);

	g_forward_ShowContextMenu = window.ShowContextMenu;
	window.ShowContextMenu = function (Ctrl, hwnd, msg, wParam, pt)
	{
		var o = document.getElementById("ImgForward");
		if (HitTest(o, pt)) {
			var FV = external.Ctrl(CTRL_FV);
			if (FV) {
				var Log = FV.History;

				hMenu = api.CreatePopupMenu();
				var mii = api.Memory("MENUITEMINFO");
				mii.cbSize = mii.Size;
				mii.fMask  = MIIM_ID | MIIM_STRING | MIIM_BITMAP;
				var arBM = new Array();
				for (var i = Log.Index - 1; i >= 0; i--) {
					FolderItem = Log.Item(i);
					var s = ' ' + api.GetDisplayNameOf(FolderItem, SHGDN_INFOLDER);
					var sz = api.Memory(s.length * 2 + 2);
					sz.Write(0, VT_LPWSTR, s);
					mii.dwTypeData = sz.p;
					var image = external.GdiplusBitmap;
					var info = api.Memory("SHFILEINFO");
					api.ShGetFileInfo(FolderItem, 0, info, info.Size, SHGFI_ICON | SHGFI_SMALLICON | SHGFI_PIDL);
					var hIcon = info.hIcon;
					var cl = api.GetSysColor(COLOR_BTNFACE);
					image.FromHICON(hIcon, cl);
					api.DestroyIcon(hIcon);
					mii.hbmpItem = image.GetHBITMAP(cl);
					arBM.push(mii.hbmpItem);
					mii.wID = i + 1;
					api.InsertMenuItem(hMenu, MAXINT, false, mii);
				}
				var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, external.hwnd, null, null);
				api.DestroyMenu(hMenu);
				while (arBM.length) {
					api.DeleteObject(arBM.splice(0, 1));
				}
				if (nVerb) {
					FV.Navigate(Log.Item(nVerb - 1), SBSP_SAMEBROWSER);
				}
			}
			return S_OK;
		}
		if (g_forward_ShowContextMenu) {
			return g_forward_ShowContextMenu(Ctrl, hwnd, msg, wParam, pt);
		}
		return S_FALSE;
	}

	g_forward_ChangeView = window.ChangeView;
	window.ChangeView = function (Ctrl)
	{
		var o = document.getElementById("ImgForward");
		var Log = Ctrl.History;
		o.style.filter = (Log && Log.Index == 0) ? "alpha(style=0, opacity=48); gray();" : "";
		if (g_forward_ChangeView) {
			return g_forward_ChangeView(Ctrl);
		}
		return S_OK;
	}
}
