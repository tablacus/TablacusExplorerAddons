var Addon_Id = "touchex";

if (window.Addon == 1) {
	importJScript("addons\\" + Addon_Id + "\\sync.js");	
}
