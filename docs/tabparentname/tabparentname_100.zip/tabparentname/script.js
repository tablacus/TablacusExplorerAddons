﻿if (Addon == 1) {
	window.ChangeTabName = function (Ctrl)
	{
		var s = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSING | SHGDN_FORPARSINGEX);
		if (typeof(s) == "number") {
			s = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_NORMAL);
		}
		else {
			if (s.charAt(0) == ":") {
				s = Ctrl.FolderItem.Name;
			}
			else {
				var a = s.split("\\");
				while(a.length > 2) {
					a.shift();
				}
				s = a.join("\\");
			}
		}
		Ctrl.Title = s.replace(/&/g, "&&");
	}
}
