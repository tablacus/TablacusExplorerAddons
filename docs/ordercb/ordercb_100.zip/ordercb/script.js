if (window.Addon == 1) {
	const Addon_Id = "ordercb";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
