﻿if (window.Addon == 1) {
	g_disabletreedrop =
	{
		DragEnter: te.OnDragEnter,
		DragOver: te.OnDragOver
	};

	te.OnDragEnter = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		if (Ctrl.Type == CTRL_TV) {
			pdwEffect.X = DROPEFFECT_NONE;
			return S_OK;
		}
		return g_disabletreedrop.DragEnter ? g_disabletreedrop.DragEnter(Ctrl, dataObj, grfKeyState, pt, pdwEffect) : E_FAIL;
	},

	te.OnDragOver = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		if (Ctrl.Type == CTRL_TV) {
			pdwEffect.X = DROPEFFECT_NONE;
			return S_OK;
		}
		return g_disabletreedrop.DragOver ? g_disabletreedrop.DragOver(Ctrl, dataObj, grfKeyState, pt, pdwEffect) : E_FAIL;
	}
}

