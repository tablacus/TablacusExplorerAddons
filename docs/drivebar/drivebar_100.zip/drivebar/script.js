﻿var Addon_Id = "drivebar";
var Default = "ToolBar1Right";

if (Addon == 1) {
	g_drivebar_DeviceChanged = DeviceChanged;

	var Location = null;
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		Location = items[0].getAttribute("Location");
	}
	if (!Location) {
		Location = Default;
	}
	var o = document.getElementById(Location);
	o.innerHTML += '<span id="drivebar"></span>';
	o.style.display = "block";
	external.Data["Locations"].push(Location + "\t" + Addon_Id);

	DeviceChanged = function ()
	{
		var icon = new Array(53, 7, 8, 9, 11, 12);

		e = new Enumerator(fso.Drives);

		var image = external.GdiplusBitmap;
		var dllpath = fso.BuildPath(api.GetDisplayNameOf(ssfSYSTEM, SHGDN_FORPARSING), "shell32.dll");
		var strDrive = "";
		for (; !e.atEnd(); e.moveNext()) {
			var letter = e.item().DriveLetter;
			var path = letter + ":\\";
			var vol = api.GetDisplayNameOf(path, SHGDN_INFOLDER);
			var nIcon = icon[e.item().DriveType];
			var src = fso.BuildPath(fso.GetParentFolderName(api.GetModuleFileName(null)), 'image\\toolbar\\s_3_' + nIcon + '.png');
			if (!fso.FileExists(src)) {
				var phIcon = api.Memory("HANDLE");
				api.ExtractIconEx(dllpath, nIcon, null, phIcon, 1);
				hIcon = phIcon.x;
				image.FromHICON(hIcon, api.GetSysColor(COLOR_BTNFACE));
				src = "data:image/png;base64," + image.Base64("image/png" , hIcon);
				api.DestroyIcon(hIcon);
			}
			strDrive += ' <a href="#" class="button" title="' + vol + '" onclick="OpenDrive(\'' + letter + '\'); this.blur(); return false"><img width=16 height=16 border=0 src="' + src + '"> ' + letter + '</a> ';
		}
		document.getElementById("drivebar").innerHTML = strDrive;
		if (g_drivebar_DeviceChanged) {
			return g_drivebar_DeviceChanged();
		}
	}
}

function OpenDrive(drive)
{
	setTimeout('Navigate("' + drive + ':\\\\", ' + SBSP_NEWBROWSER + ');', 10);
	return false;
}
