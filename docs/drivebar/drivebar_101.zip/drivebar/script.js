﻿var Addon_Id = "drivebar";
var Default = "ToolBar1Right";
var g_drivebar_nDrives = 0;

if (Addon == 1) {
	g_drivebar_DeviceChanged = DeviceChanged;
	g_drivebar_ShowContextMenu = window.ShowContextMenu;
	SetAddon(Addon_Id, Default, '<span id="' + Addon_Id + '"></span>');

	DeviceChanged = function ()
	{
		var icon = new Array(53, 7, 8, 9, 11, 12);

		var image = external.GdiplusBitmap;
		var strDrive = "";
		for (var e = new Enumerator(fso.Drives); !e.atEnd(); e.moveNext()) {
			var letter = e.item().DriveLetter;
			var path = letter + ":\\";
			var vol = api.GetDisplayNameOf(path, SHGDN_INFOLDER);
			var src;
			if (document.documentMode) { //IE8-
				var info = api.Memory("SHFILEINFO");
				api.ShGetFileInfo(path, 0, info, info.Size, SHGFI_ICON | SHGFI_SMALLICON);
				var hIcon = info.hIcon;

				image.FromHICON(hIcon, api.GetSysColor(COLOR_BTNFACE));
				src = "data:image/png;base64," + image.Base64("image/png" , hIcon);
				api.DestroyIcon(hIcon);
			}
			else {
				var nIcon = icon[e.item().DriveType];
				src = fso.BuildPath(fso.GetParentFolderName(api.GetModuleFileName(null)), 'image\\toolbar\\s_3_' + nIcon + '.png');
			}

			strDrive += ' <span class="button" id="Drive' + g_drivebar_nDrives + '" title="' + vol + '" onclick="OpenDrive(\'' + letter + '\')" path="' + letter + '" onmouseover="MouseOver(this)" onmouseout="MouseOut()"><img width=16 height=16 border=0 src="' + src + '"> ' + letter + '</span> ';
			g_drivebar_nDrives++;
		}
		document.getElementById("drivebar").innerHTML = strDrive;
		if (g_drivebar_DeviceChanged) {
			return g_drivebar_DeviceChanged();
		}
	}

	window.ShowContextMenu = function (Ctrl, hwnd, msg, wParam, pt)
	{
		var o = GetDriveFromPt(pt);
		if (o) {
			hMenu = api.CreatePopupMenu();
			var ContextMenu = api.ContextMenu(o.path + ":\\");
			if (ContextMenu) {
				ContextMenu.QueryContextMenu(hMenu, 0, 1, 0x7FFF, CMF_NORMAL);
				var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, external.hwnd, null, ContextMenu);
				if (nVerb) {
					ContextMenu.InvokeCommand(0, external.hwnd, nVerb - 1, null, null, SW_SHOWNORMAL, 0, 0);
				}
			}
			api.DestroyMenu(hMenu);
			return S_OK;
		}
		if (g_drivebar_ShowContextMenu) {
			return g_drivebar_ShowContextMenu(Ctrl, hwnd, msg, wParam, pt);
		}
		return S_FALSE;
	}
}

function OpenDrive(drive)
{
	Navigate(drive + ":\\", SBSP_NEWBROWSER);
}

function GetDriveFromPt(pt)
{
	var n = g_drivebar_nDrives;
	while (--n >= 0) {
		var o = document.getElementById("Drive" + n);
		if (HitTest(o, pt)) {
			return o;
		}
	}
	return null;
}
