﻿var Addon_Id = "drivebar";
var Default = "ToolBar1Right";

if (window.Addon == 1) {
	g_drivebar =
	{
		Init: function ()
		{
			SetAddon(Addon_Id, Default, '<span id="drivebar"></span>');
		},

		Open: function (o)
		{
			if (o.title.match(/(\w:)/)) {
				Navigate(RegExp.$1 + "\\", SBSP_NEWBROWSER);
			}
		},

		Popup: function (o)
		{
			if (o.title.match(/(\w:)/)) {
				var ContextMenu = api.ContextMenu(RegExp.$1 + "\\");
				var hMenu = api.CreatePopupMenu();
				if (ContextMenu) {
					ContextMenu.QueryContextMenu(hMenu, 0, 1, 0x7FFF, CMF_NORMAL);
					var pt = api.Memory("POINT");
					api.GetCursorPos(pt);
					var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, te.hwnd, null, ContextMenu);
					if (nVerb) {
						ContextMenu.InvokeCommand(0, te.hwnd, nVerb - 1, null, null, SW_SHOWNORMAL, 0, 0);
					}
				}
				api.DestroyMenu(hMenu);
			}
		}

	};

	AddEvent("DeviceChanged", function ()
	{
		var icon = new Array(53, 7, 8, 9, 11, 12);

		var image = te.GdiplusBitmap;
		var strDrive = "";
		for (var e = new Enumerator(fso.Drives); !e.atEnd(); e.moveNext()) {
			var letter = e.item().DriveLetter;
			var path = letter + ":\\";
			var vol = api.GetDisplayNameOf(path, SHGDN_INFOLDER);
			var src;
			if (document.documentMode) { //IE8-
				var info = api.Memory("SHFILEINFO");
				api.ShGetFileInfo(path, 0, info, info.Size, SHGFI_ICON | SHGFI_SMALLICON);
				var hIcon = info.hIcon;

				image.FromHICON(hIcon, api.GetSysColor(COLOR_BTNFACE));
				src = image.DataURI("image/png" , hIcon);
				api.DestroyIcon(hIcon);
			}
			else {
				var nIcon = icon[e.item().DriveType];
				src = MakeImgSrc('icon:shell32.dll,' + nIcon + ',16', 0, false, 16);
			}
			strDrive += '<span class="button" title="' + vol + '" onclick="g_drivebar.Open(this)" oncontextmenu="g_drivebar.Popup(this); return false" onmouseover="MouseOver(this)" onmouseout="MouseOut()"><span style="position: absolute; font-weight: bold; font-size: 9px; text-shadow: 1px 1px 0px buttonface, -1px 1px 0px buttonface, 1px -1px 0px buttonface, -1px -1px 0px buttonface; filter: glow(color=white,strength=1);">' + letter + '</span><img width=16 height=16 src="' + src + '"></span>';
			g_drivebar.nDrives++;
		}
		document.getElementById("drivebar").innerHTML = strDrive;
	});

	g_drivebar.Init();
}

