var Addon_Id = "touch";

if (window.Addon == 1) {
	AddEvent("Context", function (Ctrl, hMenu, nPos)
	{
		var Selected = Ctrl.SelectedItems();
		if (Selected && Selected.Count) {
			var item = Selected.Item(0);
			if (item.IsFileSystem) {
				api.InsertMenu(hMenu, 0, MF_BYPOSITION | MF_STRING, ++nPos, GetText('Change the Date modified...'));
				ExtraMenuCommand[nPos] = function (Ctrl)
				{
					try {
						var Selected = Ctrl.SelectedItems();
						var item = Selected.Item(0);
						var ModifyDate = new Date(item.ModifyDate).toLocaleString();
						var s = InputDialog(item.Path + "\n" + ModifyDate, ModifyDate);
						if (s) {
							ModifyDate = new Date(s);
							if(isNaN(ModifyDate)) {
								ModifyDate = s;
							}
							else {
								ModifyDate = ModifyDate.getVarDate();
							}
							for (var i = Selected.Count - 1; i >= 0; i--) {
								Selected.Item(i).ModifyDate = ModifyDate;
							}
						}
					}
					catch (e) {
						wsh.Popup(e.description + "\n" + s, 0, TITLE, MB_ICONEXCLAMATION);
					}
				}
			}
		}
		return nPos;
	});
}
