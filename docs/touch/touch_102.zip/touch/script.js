var Addon_Id = "touch";

if (window.Addon == 1) {
	AddEvent("Context", function (Ctrl, hMenu, nPos)
	{
		var Selected = Ctrl.SelectedItems();
		if (Selected && Selected.Count) {
			var item = Selected.Item(0);
			if (item.IsFileSystem) {
				api.InsertMenu(hMenu, 0, MF_BYPOSITION | MF_STRING, ++nPos, GetText('Change the Date modified...'));
				ExtraMenuCommand[nPos] = function (Ctrl)
				{
					var Selected = Ctrl.SelectedItems();
					var item = Selected.Item(0);
					var ModifyDate = new Date(item.ModifyDate).toLocaleString();
					ModifyDate = InputDialog(item.Path + "\n" + ModifyDate, ModifyDate);
					if (ModifyDate) {
						for (var i = Selected.Count - 1; i >= 0; i--) {
							Selected.Item(i).ModifyDate = ModifyDate;
						}
					}
				}
			}
		}
		return nPos;
	});
}
