﻿var Addon_Id = "touch";
var g_touch_ExtraMenus;

if (Addon == 1) {
	g_touch_ExtraMenus = ExtraMenus["Context"];
	ExtraMenus["Context"] = function (Ctrl, hMenu, nPos)
	{
		var Selected = Ctrl.SelectedItems();
		if (Selected && Selected.Count) {
			var item = Selected.Item(0);
			if (item.IsFileSystem) {
				api.InsertMenu(hMenu, 0, MF_BYPOSITION | MF_STRING, ++nPos, GetText('Change the Date modified...'));
				ExtraMenuCommand[nPos] = function (Ctrl)
				{
					var Selected = Ctrl.SelectedItems();
					var item = Selected.Item(0);
					var ModifyDate = new Date(item.ModifyDate).toLocaleString();
					ModifyDate = prompt(item.Path + "\n" + ModifyDate, ModifyDate);
					if (ModifyDate) {
						for (var i = Selected.Count - 1; i >= 0; i--) {
							Selected.Item(i).ModifyDate = ModifyDate;
						}
					}
				}
			}
		}
		if (g_touch_ExtraMenus) {
			nPos = g_touch_ExtraMenus(Ctrl, hMenu, nPos);
		}
		return nPos;
	}
}
