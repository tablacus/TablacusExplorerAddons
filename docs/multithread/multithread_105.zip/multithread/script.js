﻿if (window.Addon == 1) {
	g_multithread =
	{
		Drop: te.OnDrop,
		Command: te.OnCommand,
		OnInvokeCommand: te.OnInvokeCommand,

		FO: function (Ctrl, Items, Dest, grfKeyState, pt, pdwEffect, bOver, bDelete)
		{
			if (!(grfKeyState & MK_LBUTTON) || Items.Count == 0) {
				return false;
			}
			if (bDelete || (Dest != "" && fso.FolderExists(Dest))) {
				var arFrom = [];
				for (i = 0; i < Items.Count; i++) {
					var Path = Items.Item(i).Path;
					if (IsExists(Path)) {
						arFrom.push(Path);
					}
					else {
						pdwEffect.X = 0;
					}
				}
				if (pdwEffect.X) {
					var wFunc = 0;
					if (bDelete) {
						wFunc = FO_DELETE;
					}
					else {
						if (bOver) {
							var DropTarget = api.DropTarget(Dest);
							DropTarget.DragOver(Items, grfKeyState, pt, pdwEffect);
						}
						if (pdwEffect.X & DROPEFFECT_COPY) {
							wFunc = FO_COPY;
						}
						else if (pdwEffect.X & DROPEFFECT_MOVE) {
							wFunc = FO_MOVE;
						}
					}
					if (wFunc) {
						var fFlags = FOF_ALLOWUNDO;
						var Parent = Items.Item(-1);
						if (!bDelete && api.ILIsEqual(Dest, Parent)) {
							fFlags |= FOF_RENAMEONCOLLISION;
						}
						if (Ctrl) {
							var DropTarget = Ctrl.DropTarget;
							DropTarget.DragLeave();
						}
						api.SHFileOperation(wFunc, arFrom.join("\0"), Dest, fFlags, bDelete || !api.ILIsParent(wsh.ExpandEnvironmentStrings("%TEMP%"), Parent, false));
						return true;
					}
				}
			}
			return false;
		}
	};

	te.OnDrop = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		switch (Ctrl.Type) {
			case CTRL_SB:
			case CTRL_EB:
				var Items = Ctrl.Items();
				var Dest = Items.Item(Ctrl.HitTest(pt, LVHT_ONITEM));
				if (!Dest || !fso.FolderExists(Dest.Path)) {
					Dest = Ctrl.FolderItem;
				}
				if (g_multithread.FO(Ctrl, dataObj, Dest.Path, grfKeyState, pt, pdwEffect, true)) {
					return S_OK
				}
				break;
			case CTRL_DT:
				if (g_multithread.FO(null, dataObj, Ctrl.FolderItem.Path, grfKeyState, pt, pdwEffect, true)) {
					return S_OK
				}
				break;
		}
		return g_multithread.Drop ? g_multithread.Drop(Ctrl, dataObj, grfKeyState, pt, pdwEffect) : E_FAIL;
	}

	te.OnCommand = function (Ctrl, hwnd, msg, wParam, lParam)
	{
		if (Ctrl.Type == CTRL_SB || Ctrl.Type == CTRL_EB) {
			switch ((wParam & 0xfff) + 1) {
				case CommandID_PASTE:
					var Items = api.OleGetClipboard()
					if (g_multithread.FO(null, Items, Ctrl.FolderItem.Path, MK_LBUTTON, null, Items.pdwEffect, false)) {
						return S_OK;
					}
					break;
				case CommandID_DELETE:
					var Items = Ctrl.SelectedItems();
					if (g_multithread.FO(null, Items, "", MK_LBUTTON, null, Items.pdwEffect, false, true)) {
						return S_OK;
					}
					break;
			}
		}
		return g_multithread.Command ? g_multithread.Command(Ctrl, hwnd, msg, wParam, lParam) : S_FALSE;
	}

	te.OnInvokeCommand = function (ContextMenu, fMask, hwnd, Verb, Parameters, Directory, nShow, dwHotKey, hIcon)
	{
		switch (Verb + 1) {
			case CommandID_PASTE:
				var Target = ContextMenu.Items();
				if (Target.Count) {
					var Items = api.OleGetClipboard()
					if (g_multithread.FO(null, Items, Target.Item(0).Path, MK_LBUTTON, null, Items.pdwEffect, false)) {
						return S_OK;
					}
				}
				break;
			case CommandID_DELETE:
				var Items = ContextMenu.Items();
				if (g_multithread.FO(null, Items, "", MK_LBUTTON, null, Items.pdwEffect, false, true)) {
					return S_OK;
				}
				break;
		}
		return g_multithread.OnInvokeCommand ? g_multithread.OnInvokeCommand(ContextMenu, fMask, hwnd, Verb, Parameters, Directory, nShow, dwHotKey, hIcon) : S_FALSE;
	}

	if (!ExtraMenus.Context) {
		ExtraMenus.Context = function (Ctrl, hMenu, nPos) {}
	}

}

