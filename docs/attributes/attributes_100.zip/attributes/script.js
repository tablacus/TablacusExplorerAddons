var Addon_Id = "attributes";

g_attributes =
{
	showDialog: function (Ctrl)
	{
		if (!Ctrl) {
			Ctrl = te.Ctrl(CTRL_FV);
		}
		var Selected = Ctrl.SelectedItems();
		if (Selected && Selected.Count) {
			var h = 100 + 26 * Selected.Count;
			if (h > 480) {
				h = 480;
			}
			showModelessDialog("../addons/attributes/dialog.html", window, "dialogWidth: 640px; dialogHeight: " + h + "px; resizable: yes; status: 0");
		}
	}
}

if (window.Addon == 1) {
	AddEvent("Context", function (Ctrl, hMenu, nPos)
	{
		var Selected = Ctrl.SelectedItems();
		if (Selected && Selected.Count) {
			var item = Selected.Item(0);
			if (item.IsFileSystem) {
				api.InsertMenu(hMenu, 0, MF_BYPOSITION | MF_STRING, ++nPos, GetText('Attributes...'));
				ExtraMenuCommand[nPos] = g_attributes.showDialog;
			}
		}
		return nPos;
	});
}
else {
	arAttrib = [FILE_ATTRIBUTE_READONLY, FILE_ATTRIBUTE_HIDDEN, FILE_ATTRIBUTE_SYSTEM, FILE_ATTRIBUTE_ARCHIVE];
	arStr = ["R", "H", "S", "A"];
	arHelp = ["Read Only", "Hidden", "System", "Archive"];
	cItems = [];

	Resize = function ()
	{
		var h = document.documentElement.clientHeight || document.body.clientHeight;
		var o = document.getElementById("P");
		h -= 36;
		if (h > 0) {
			o.style.height = h + 'px';
		}
	}

	CheckAll = function (e)
	{
		var o = e ? e.currentTarget : window.event.srcElement;
		for (var i in arCheckbox) {
			arCheckbox[i][o.value].checked = o.checked;
		}
	}

	SetAttributes = function ()
	{
		var filter = 0;
		for (var j in arAttrib) {
			filter |= arAttrib[j];
		}
		for (var i in arCheckbox) {
			var attr = 0;
			for (var j in arAttrib) {
				attr |= arCheckbox[i][j].checked ? arAttrib[j] : 0;
			}
			if ((cItems[i].Attributes ^ attr) & filter) {
				attr |= cItems[i].Attributes & (~filter);
				try {
					cItems[i].Attributes = attr;
				}
				catch (e) {
					wsh.Popup(e.description + "\n" + cItems[i].Path, 0, TITLE, MB_ICONEXCLAMATION);
				}
			}
		}
		window.close();
	}

	AddEventEx(window, "load", function ()
	{
		ApplyLang(document);
		var FV = te.Ctrl(CTRL_FV);
		if (FV) {
			Selected = FV.SelectedItems();
			if (Selected) {
				var table = document.getElementById("T");
				var nSelected = Selected.Count;
				arCheckbox = [];

				var tr = document.createElement('tr');
				var td = document.createElement('th');
				td.innerText = GetText("Name");
				td.style.width = "100%";
				td.style.verticalAlign = "middle";
				tr.appendChild(td);
				for (var i in arStr) {
					var td = document.createElement('th');
					td.innerText = arStr[i];
					td.title = GetText(arHelp[i]);
					if (nSelected > 1) {
						var input = document.createElement('input');
						input.type = "checkbox";
						input.value = i;
						input.onclick = CheckAll;
						td.appendChild(input);
					}
					tr.appendChild(td);
				}
				table.appendChild(tr);
				for (i = 0; i < nSelected; i++) {
					tr = document.createElement('tr');
					td = document.createElement('td');
					var Item;
					try {
						Item = fso.GetFile(Selected.Item(i).Path);
					}
					catch (e) {
						try {
							Item = fso.GetFolder(Selected.Item(i).Path);
						}
						catch (e) {
							Item = null;
						}
					}
					if (Item) {
						cItems[i] = Item;
					}
					var attr = Item.Attributes;
					td.innerText = Selected.Item(i).Name;
					td.style.paddingLeft = "8px";
					tr.appendChild(td);

					arCheckbox[i] = [];
					for (var j = 0; j < 4; j++) {
						td = document.createElement('td');
						var input = document.createElement('input');
						input.type="checkbox";
						input.checked= (attr & arAttrib[j]);
						arCheckbox[i][j] = input;
						td.appendChild(input);
						td.title = GetText(arHelp[j]);
						tr.appendChild(td);
					}
					table.appendChild(tr);
				}
			}
		}
		Resize();
	});

	AddEventEx(window, "resize", Resize);
}
