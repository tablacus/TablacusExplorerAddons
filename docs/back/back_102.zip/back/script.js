﻿var Addon_Id = "back";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var s;
	if (external.Data["Conf_IconSize"] == 16) {
		s = '<img alt="Back" src="../image/toolbar/s_1_0.png" bitmap="ieframe.dll,216,16,0">';
	}
	else {
		s = '<img alt="Back" src="../image/toolbar/m_1_0.png" bitmap="ieframe.dll,214,24,0">';
	}
	s = '<span class="button" onclick="Navigate(null, SBSP_NAVIGATEBACK | SBSP_SAMEBROWSER); return false;" onmouseover="MouseOver(this)" onmouseout="MouseOut()">' + s + '</span> ';
	SetAddon(Addon_Id, Default, s);
}
