﻿var Addon_Id = "back";
var Default = "ToolBar2Left";

if (window.Addon == 1) {
	g_back =
	{
		Init: function ()
		{
			var s = (IconSize == 16) ? 'src="../image/toolbar/s_1_0.png" bitmap="ieframe.dll,216,16,0"' : 'src="../image/toolbar/m_1_0.png" bitmap="ieframe.dll,214,24,0"';
			s = '<span class="button" onclick="Navigate(null, SBSP_NAVIGATEBACK | SBSP_SAMEBROWSER); return false;" oncontextmenu="g_back.Popup(this); return false;" onmouseover="MouseOver(this)" onmouseout="MouseOut()"><img id="ImgBack" alt="Back" ' + s + '></span><span style="width: 1px"> </span>';
			SetAddon(Addon_Id, Default, s);
		},

		Popup: function (o)
		{
			var FV = te.Ctrl(CTRL_FV);
			if (FV) {
				var Log = FV.History;
				var hMenu = api.CreatePopupMenu();
				var mii = api.Memory("MENUITEMINFO");
				mii.cbSize = mii.Size;
				mii.fMask  = MIIM_ID | MIIM_STRING | MIIM_BITMAP;
				var arBM = [];
				for (var i = Log.Index + 1; i < Log.Count; i++) {
					FolderItem = Log.Item(i);
					var s = ' ' + api.GetDisplayNameOf(FolderItem, SHGDN_INFOLDER);
					var sz = api.Memory(s.length * 2 + 2);
					sz.Write(0, VT_LPWSTR, s);
					mii.dwTypeData = sz.p;
					var image = te.GdiplusBitmap;
					var info = api.Memory("SHFILEINFO");
					api.ShGetFileInfo(FolderItem, 0, info, info.Size, SHGFI_ICON | SHGFI_SMALLICON | SHGFI_PIDL);
					var hIcon = info.hIcon;
					var cl = api.GetSysColor(COLOR_MENU);
					image.FromHICON(hIcon, cl);
					api.DestroyIcon(hIcon);
					mii.hbmpItem = image.GetHBITMAP(cl);
					arBM.push(mii.hbmpItem);
					mii.wID = i;
					api.InsertMenuItem(hMenu, MAXINT, false, mii);
				}
				var pt = api.Memory("POINT");
				api.GetCursorPos(pt);
				var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, te.hwnd, null, null);
				api.DestroyMenu(hMenu);
				while (arBM.length) {
					api.DeleteObject(arBM.pop());
				}
				if (nVerb) {
					Log.Index = nVerb;
					FV.History = Log;
				}
			}
			return false;
		}
	};

	AddEvent("ChangeView", function (Ctrl)
	{
		var Log = Ctrl.History;
		document.getElementById("ImgBack").style.filter = (Log && Log.Index >= Log.Count - 1) ? "alpha(style=0, opacity=48); gray();" : "";
		return S_OK;
	});

	g_back.Init();
}
