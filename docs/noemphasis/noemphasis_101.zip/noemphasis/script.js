if (window.Addon == 1) {
	te.ColumnEmphasis = 0;
	te.Data.Conf_ColumnEmphasis = 0;
}
