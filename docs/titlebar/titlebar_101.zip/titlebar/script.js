﻿if (Addon == 1) {
	g_titlebar_ChangeView = ChangeView;

	ChangeView = function(Ctrl)
	{
		if (Ctrl.FolderItem) {
			api.SetWindowText(external.hwnd, api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORADDRESSBAR) + ' - Tablacus Explorer');
		}
		if (g_titlebar_ChangeView) {
			return g_titlebar_ChangeView(Ctrl);
		}
	}
}
