﻿var Addon_Id = "simpletoolbar";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var s;
	if (window.IconSize == 16) {
		s = '<a href="#" onclick="this.blur(); Navigate(null, SBSP_NAVIGATEBACK | SBSP_SAMEBROWSER); return false;" class="button"><img  alt="Back" src="../image/toolbar/s_1_0.png" bitmap="ieframe.dll,216,16,0"></a> ';
		s += '<a href="#" onclick="this.blur(); Navigate(null, SBSP_NAVIGATEFORWARD | SBSP_SAMEBROWSER); return false;" class="button"><img alt="Forward" src="../image/toolbar/s_1_1.png" bitmap="ieframe.dll,216,16,1"></a> ';
		s += '<a href="#" onclick="this.blur(); Navigate(null, SBSP_PARENT | SBSP_SAMEBROWSER);" class="button"><img alt="Up" src="../image/toolbar/s_1_28.png" bitmap="ieframe.dll,216,16,28"></a> ';
		s += '<a href="#" onclick="this.blur(); CreateTab(); return false;" class="button"><input type="image" alt="New Tab" src="../image/toolbar/s_1_12.png" bitmap="ieframe.dll,216,16,12"></a> ';
		s += '<a href="#" onclick="Refresh(); this.blur(); return false;" class="button"><img alt="Refresh" src="../image/toolbar/s_2_3.png" bitmap="ieframe.dll,206,16,3"></a> ';
	}
	else {
		s = '<a href="#" onclick="this.blur(); Navigate(null, SBSP_NAVIGATEBACK | SBSP_SAMEBROWSER); return false;" class="button"><img  alt="Back" src="../image/toolbar/m_1_0.png" bitmap="ieframe.dll,214,24,0"></a> ';
		s += '<a href="#" onclick="this.blur(); Navigate(null, SBSP_NAVIGATEFORWARD | SBSP_SAMEBROWSER); return false;" class="button"><img alt="Forward" src="../image/toolbar/m_1_1.png" bitmap="ieframe.dll,214,24,1"></a> ';
		s += '<a href="#" onclick="this.blur(); Navigate(null, SBSP_PARENT | SBSP_SAMEBROWSER);" class="button"><img alt="Up" src="../image/toolbar/m_1_28.png" bitmap="ieframe.dll,214,24,28"></a> ';
		s += '<a href="#" onclick="this.blur(); CreateTab(); return false;" class="button"><input type="image" alt="New Tab" src="../image/toolbar/m_1_12.png" bitmap="ieframe.dll,214,24,12"></a> ';
		s += '<a href="#" onclick="Refresh(); this.blur(); return false;" class="button"><img alt="Refresh" src="../image/toolbar/m_2_3.png" bitmap="ieframe.dll,204,24,3"></a> ';
	}
	var Location = null;
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		Location = items[0].getAttribute("Location");
	}
	if (!Location) {
		Location = Default;
	}
	var o = document.getElementById(Location);
	o.innerHTML += s;
	o.style.display = "block";
	external.Data["Locations"].push(Location + "\t" + Addon_Id);
}
