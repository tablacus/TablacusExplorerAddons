if (window.Addon == 1) {
	AddEvent("ReplaceMacro", [/%Selected%/ig, function(Ctrl)
	{
		var ar = [];
		var FV = GetFolderView(Ctrl);
		if (FV && FV.hwndList) {
			var Items = FV.Items();
			if (Items) {
				var nPos = api.SendMessage(FV.hwndList, LVM_GETNEXTITEM, -1, LVNI_SELECTED);
				while (nPos >= 0) {
					ar.push(api.PathQuoteSpaces(api.GetDisplayNameOf(Items.Item(nPos), SHGDN_FORPARSING)));
					nPos = api.SendMessage(FV.hwndList, LVM_GETNEXTITEM, nPos, LVNI_SELECTED);
				}
			}
			return ar.join(" ");
		}
	}], true);
}
