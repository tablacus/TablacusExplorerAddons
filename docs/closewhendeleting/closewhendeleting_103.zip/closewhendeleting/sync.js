AddEvent("Error", function (FV) {
	FV.Close();
	return S_OK;
});
