﻿var Addon_Id = "filterbar";
var Default = "ToolBar2Right";

if (Addon == 1) {
	g_filterbar_ChangeView = ChangeView;
	g_tidFilter = null;
	g_filter = null;
	g_iCaret = -1;

	var Location = null;
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		Location = items[0].getAttribute("Location");
	}
	if (!Location) {
		Location = Default;
	}
	var o = document.getElementById(Location);
	o.innerHTML += '<input type="text" name="filter" onkeydown="FilterKeyDown(this)" onfocus="FilterFocus(this)" style="position: relative; top: -1px; width: 160px;"><a href="#" onclick="FilterClear(); this.blur(); return false;" class="button"><img src="../image/toolbar/s_1_14.png" bitmap="ieframe.dll,216,16,14" id="ButtonFilter"><img src="../image/toolbar/s_2_2.png" id="ButtonFilterClear" bitmap="ieframe.dll,206,16,2" style="display: none"></a>';
	o.style.display = "block";
	external.Data["Locations"].push(Location + "\t" + Addon_Id);

	ChangeView = function(FV)
	{
		clearTimeout(g_tidFilter);
		document.F.filter.value = "";
		if (g_filterbar_ChangeView) {
			return g_filterbar_ChangeView(FV);
		}
	}
}

function FilterKeyDown(o)
{
	g_filter = o.value;
	clearTimeout(g_tidFilter);
	g_tidFilter = setTimeout("ChangeFilter()", 500);
}

function ChangeFilter()
{
	var s = document.F.filter.value;
	if (g_filter != s) {
		if (s == "") {
			document.getElementById("ButtonFilter").style.display = "inline";
			document.getElementById("ButtonFilterClear").style.display = "none";
		}
		else {
			document.getElementById("ButtonFilter").style.display = "none";
			document.getElementById("ButtonFilterClear").style.display = "inline";
		}
		var FV = external.Ctrl(CTRL_FV);
		if (FV.Type == CTRL_EB) {
			var docRange = document.selection.createRange();
			var range = document.F.filter.createTextRange();
			range.setEndPoint('EndToEnd', docRange);
			g_iCaret = range.text.length;
		}
		Navigate("*" + document.F.filter.value + "*", SBSP_SAMEBROWSER);
		if (FV.Type == CTRL_EB) {
			g_bLast = true;
			document.F.filter.focus();
		}
	}
}

function FilterFocus(o)
{
	o.select();
	if (g_iCaret >= 0) {
		var range = o.createTextRange();
		range.move("character", g_iCaret);
		range.select(); 
		g_iCaret = -1;
	}
}

function FilterClear()
{
	document.getElementById("ButtonFilter").style.display = "inline";
	document.getElementById("ButtonFilterClear").style.display = "none";
	document.F.filter.value = "";
	Navigate("*", SBSP_SAMEBROWSER);
}
