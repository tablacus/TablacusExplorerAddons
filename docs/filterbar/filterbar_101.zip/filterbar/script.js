﻿var Addon_Id = "filterbar";
var Default = "ToolBar2Right";

if (!window.dialogArguments) {
	g_filterbar =
	{
		ChangeView: window.ChangeView,
		tid: null,
		filter: null,
		iCaret: -1,

		Init: function ()
		{
			var s = '<input type="text" name="filter" onkeydown="g_filterbar.KeyDown(this)" onfocus="g_filterbar.Focus(this)" style="width: 160px;"><span onclick="g_filterbar.Clear(true)" onmouseover="MouseOver(this)" onmouseout="MouseOut()" class="button" style="vertical-align: middle"><input type="image" src="../image/toolbar/s_1_14.png" bitmap="ieframe.dll,216,16,14" id="ButtonFilter" hidefocus="true"><input type="image" src="../image/toolbar/s_2_2.png" id="ButtonFilterClear" bitmap="ieframe.dll,206,16,2" style="display: none" hidefocus="true"></span>';
			SetAddon(Addon_Id, Default, s);
		},

		KeyDown: function (o)
		{
			this.filter = o.value;
			clearTimeout(this.tid);
			this.tid = setTimeout(this.Change, 500);
		},

		Change: function ()
		{
			g_filterbar.ShowButton();
			var FV = external.Ctrl(CTRL_FV);
			if (FV.Type == CTRL_EB) {
				var docRange = document.selection.createRange();
				var range = document.F.filter.createTextRange();
				range.setEndPoint('EndToEnd', docRange);
				g_filterbar.iCaret = range.text.length;
			}
			s = document.F.filter.value;
			if (!s.match(/\*/)) {
				s = "*" + s + "*";
			}
			Navigate(s, SBSP_SAMEBROWSER);
			if (FV.Type == CTRL_EB) {
				document.F.filter.focus();
			}
		},

		Focus: function (o)
		{
			o.select();
			if (this.iCaret >= 0) {
				var range = o.createTextRange();
				range.move("character", this.iCaret);
				range.select(); 
				this.iCaret = -1;
			}
		},

		Clear: function (flag)
		{
			document.F.filter.value = "";
			this.ShowButton();
			if (flag) {
				Navigate("*", SBSP_SAMEBROWSER);
			}
		},

		ShowButton: function ()
		{
			if (document.F.filter.value.length) {
				document.getElementById("ButtonFilter").style.display = "none";
				document.getElementById("ButtonFilterClear").style.display = "inline";
			}
			else {
				document.getElementById("ButtonFilter").style.display = "inline";
				document.getElementById("ButtonFilterClear").style.display = "none";
			}
		}
	};

	ChangeView = function(FV)
	{
		clearTimeout(g_filterbar.tid);
		var s = FV.FilterView;
		if (s.match(/^\*(.*)\*$/)) {
			s = RegExp.$1;
		}
		else if (api.strcmpi(s, "*") == 0) {
			s = "";
		}
		document.F.filter.value = s;
		g_filterbar.ShowButton();
		if (g_filterbar.ChangeView) {
			return g_filterbar.ChangeView(FV);
		}
	}
	g_filterbar.Init();
}
