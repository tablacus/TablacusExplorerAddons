﻿var Addon_Id = "drivebutton";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var sml = 'l';
	var size = 24;
	if (IconSize && IconSize <= 16) {
		sml = 's';
		size = 16;
	}
	else if (IconSize >= 32) {
		size = 32;
	}
	var alt = 'Drive';
	var png = '_3_8';
	var icon = 'icon="shell32.dll,8,';
	var cmd = 'onmousedown="OpenDriveButton(this)"';
	SetAddon(Addon_Id, Default, '<span class="button" id="' + Addon_Id + '" ' + cmd + ' onmouseover="MouseOver(this)" onmouseout="MouseOut()"><img alt="' + alt + '" width=' + size + ' src="../image/toolbar/' + sml + png + '.png" ' + icon + size + '"></span> ');
}

function OpenDriveButton(o)
{
	(function (o) { setTimeout(function () {
		MouseOver(o);
		var hMenu = api.CreatePopupMenu();
		var Items = sha.NameSpace(ssfDRIVES).Items();
		var mii = api.Memory("MENUITEMINFO");
		mii.cbSize = mii.Size;
		mii.fMask  = MIIM_ID | MIIM_STRING | MIIM_BITMAP;
		var arBM = new Array();
		for (var i = 0; i < Items.Count; i++) {
			var path = api.GetDisplayNameOf(Items.Item(i), SHGDN_FORPARSING);
			if (path.length <= 3) {
				mii.wID = i + 1;
				var s = ' ' + api.GetDisplayNameOf(Items.Item(i), SHGDN_INFOLDER);
				var sz = api.Memory(s.length * 2 + 2);
				sz.Write(0, VT_LPWSTR, s);
				mii.dwTypeData = sz.p;
				var image = external.GdiplusBitmap;
				var info = api.Memory("SHFILEINFO");
				api.ShGetFileInfo(Items.Item(i), 0, info, info.Size, SHGFI_ICON | SHGFI_SMALLICON | SHGFI_PIDL);
				var hIcon = info.hIcon;
				var cl = api.GetSysColor(COLOR_BTNFACE);
				image.FromHICON(hIcon, cl);
				api.DestroyIcon(hIcon);
				arBM[i] = image.GetHBITMAP(cl);
				mii.hbmpItem = arBM[i];
				api.InsertMenuItem(hMenu, MAXINT, false, mii);
			}
		}
		var pt = GetPos(o);
		var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, screenLeft + pt.x, screenTop + pt.y + o.offsetHeight, external.hwnd, null);
		for (var i = 0; i < arBM.length; i++) {
			api.DeleteObject(arBM[i]);
		}
		api.DestroyMenu(hMenu);
		MouseOut();
		if (nVerb) {
			Navigate(api.GetDisplayNameOf(Items.Item(nVerb - 1), SHGDN_FORPARSING), SBSP_NEWBROWSER);
		}
	}, 100);}) (o);
}
