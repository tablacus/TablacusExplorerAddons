﻿var Addon_Id = "linkbar";
var Default = "ToolBar4Center";

if (Addon == 1) {
	g_LinkBar_ShowContextMenu = window.ShowContextMenu;
	g_LinkBar_DragEnter = external.OnDragEnter;
	g_LinkBar_DragOver = external.OnDragOver;
	g_LinkBar_Drop = external.OnDrop;
	g_LinkBar_DragLeave = external.OnDragleave;

	var path = fso.GetParentFolderName(api.GetModuleFileName(null));
	var xml = external.CreateObject("Msxml2.DOMDocument");
	xml.async = false;

	xml.load(fso.BuildPath(path, "config\\linkbar.xml"));
	external.Data["xmlLinkBar"] = xml;

	SetAddon(Addon_Id, Default, '<span id="' + Addon_Id + '"></span>');
	WriteLink();

	window.ShowContextMenu = function (Ctrl, hwnd, msg, wParam, pt)
	{
		var items = external.Data["xmlLinkBar"].getElementsByTagName("Item");
		var i = GetLinkFromPt(items.length, pt);
		if (i >= 0) {
			hMenu = api.CreatePopupMenu();
			var ContextMenu = api.ContextMenu(GetLinkPath(items, i));
			if (ContextMenu) {
				ContextMenu.QueryContextMenu(hMenu, 0, 1, 0x7FFF, CMF_NORMAL);
				var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, external.hwnd, null, ContextMenu);
				if (nVerb) {
					ContextMenu.InvokeCommand(0, external.hwnd, nVerb - 1, null, null, SW_SHOWNORMAL, 0, 0);
				}
			}
			api.DestroyMenu(hMenu);
			return S_OK;
		}
		if (g_LinkBar_ShowContextMenu) {
			return g_LinkBar_ShowContextMenu(Ctrl, hwnd, msg, wParam, pt);
		}
		return S_FALSE;
	}

	external.OnDragEnter = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = E_NOTIMPL;
		if (g_LinkBar_DragEnter) {
			hr = g_LinkBar_DragEnter(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		if (Ctrl.Type == CTRL_WB) {
			hr = S_OK;
		}
		return hr;
	}

	external.OnDragOver = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = S_OK;
		if (g_LinkBar_DragOver) {
			hr = g_LinkBar_DragOver(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		external.Data['grfKeyState'] = grfKeyState;
		var items = external.Data["xmlLinkBar"].getElementsByTagName("Item");
		var i = GetLinkFromPt(items.length + 1, pt);
		if (i >= 0) {
			if (i == items.length) {
				pdwEffect.x = DROPEFFECT_LINK;
				MouseOver(document.getElementById("Link" + i));
				return S_OK;
			}
			var Target = GetLinkPath(items, i);
			if (!api.ILIsEqual(dataObj.Item(-1), Target)) {
				var DropTarget = api.DropTarget(Target);
				if (DropTarget) {
					pdwEffect.x = DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK;
					if (DropTarget.DragEnter(dataObj, grfKeyState, pt, pdwEffect) == S_OK) {
						hr = DropTarget.DragOver(grfKeyState, pt, pdwEffect);
						DropTarget.DragLeave();
						MouseOver(document.getElementById("Link" + i));
						return S_OK;
					}
				}
			}
			pdwEffect.X = DROPEFFECT_NONE;
		}
		MouseOut();
		return hr;
	}

	external.OnDrop = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = S_OK;
		if (g_LinkBar_Drop) {
			hr = g_LinkBar_Drop(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		MouseOut();
		var items = external.Data["xmlLinkBar"].getElementsByTagName("Item");
		var i = GetLinkFromPt(items.length + 1, pt);
		if (i >= 0) {
			if (i == items.length) {
				var xml = external.Data["xmlLinkBar"];
				var root = xml.documentElement;
				if (!root) {
					xml.appendChild(xml.createProcessingInstruction("xml", 'version="1.0" encoding="UTF-8"'));
					root = xml.createElement("TablacusExplorer");
					xml.appendChild(root);
				}
				if (root) {
					for (i = 0; i < dataObj.Count; i++) {
						var FolderItem = dataObj.Item(i);
						var item = xml.createElement("Item");
						item.setAttribute("Name", api.GetDisplayNameOf(FolderItem, SHGDN_INFOLDER));
						item.text = api.GetDisplayNameOf(FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
						item.setAttribute("Type", "Open");
						root.appendChild(item);
					}
					SaveXmlEx("linkbar.xml", xml);
					WriteLink();
					ApplyLang(document);
				}
				return S_OK;
			}
			var DropTarget = api.DropTarget(GetLinkPath(items, i));
			if (DropTarget) {
				grfKeyState = external.Data['grfKeyState'];
				if (DropTarget.DragEnter(dataObj, grfKeyState, pt, pdwEffect) == S_OK) {
					if (DropTarget.DragOver(grfKeyState, pt, pdwEffect) == S_OK) {
						pdwEffect.X = DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK;
						hr = DropTarget.Drop(dataObj, grfKeyState, pt, pdwEffect);
					}
					DropTarget.DragLeave();
				}
			}
		}
		return hr;
	}
	external.OnDragleave = function (Ctrl)
	{
		var hr = S_OK;
		if (g_LinkBar_DragLeave) {
			hr = g_LinkBar_DragLeave(Ctrl);
		}
		MouseOut();
		return hr;
	}
}
function WriteLink()
{
	var s = "";
	var items = external.Data["xmlLinkBar"].getElementsByTagName("Item");
	var image = external.GdiplusBitmap;
	for (var i = 0; i < items.length; i++) {
		var src = '../image/toolbar/s_3_3.png';
		if (document.documentMode) { //IE8-
			var info = api.Memory("SHFILEINFO");
			api.ShGetFileInfo(api.ILCreateFromPath(GetLinkPath(items, i)), 0, info, info.Size, SHGFI_PIDL | SHGFI_ICON | SHGFI_SMALLICON);
			image.FromHICON(info.hIcon, api.GetSysColor(COLOR_BTNFACE));
			src = "data:image/png;base64," + image.Base64("image/png" , info.hIcon);
			api.DestroyIcon(info.hIcon);
		}
		s += '<span id="Link' + i + '" onclick="OpenLink(' + i + ')" onmouseover="MouseOver(this)" onmouseout="MouseOut()" class="button" title="' + items[i].text.replace(/"/g, "&quot;") + '"><img width=16 height=16 border=0 src="' + src + '"> ' + items[i].getAttribute("Name") + '</span> ';
	}
	s += '<label id="Link' + items.length + '" title="Edit" onclick="OpenLinkOption()"  onmouseover="MouseOver(this)" onmouseout="MouseOut()" class="button">+</label>';

	document.getElementById('linkbar').innerHTML = s;
}

function OpenLink(i)
{
	var items = external.Data["xmlLinkBar"].getElementsByTagName("Item");
	Exec(external, items[i].text, items[i].getAttribute("Type"), external.hwnd, null);
}

function OpenLinkOption()
{
	var Location = GetAddonLocation('linkbar');
	if (showModalDialog("../addons/linkbar/options.html", window, "dialogWidth: 640px; dialogHeight: 480px; resizable: yes; status=0")) {
		if (Location == GetAddonLocation('linkbar')) {
			WriteLink();
			ApplyLang(document);
		}
		else {
			SaveXmlEx("addons.xml", external.Data["Addons"]);
			location.reload();
		}
	}
}

function GetLinkFromPt(n, pt)
{
	while (--n >= 0) {
		if (HitTest(document.getElementById("Link" + n), pt)) {
			return n;
		}
	}
	return -1;
}

function GetLinkPath(items, i)
{
	var line = items[i].text.split("\n");
	return api.PathUnquoteSpaces(ExtractMacro(null, line[0]));
}

