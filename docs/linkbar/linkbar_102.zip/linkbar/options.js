﻿returnValue = false;

var AddonName = "LinkBar";
var nTabIndex = 0;
var nTabMax = 0;
var g_List = null;
var g_Chg = false;
var g_ChgData = false;

function GetCurrentSetting()
{
	var FV = external.Ctrl(CTRL_FV);

	if (confirm(GetText("Are you sure?"))) {
		AddPath("Path", api.PathQuoteSpaces(api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING)));
	}
}

function AddPath(Id, strValue)
{
	var s = document.getElementById(Id).value;
	if (s.match(/\n$/) || s == "") {
		s += strValue;
	}
	else {
		s += "\n" + strValue;
	}
	document.getElementById(Id).value = s;
}

function InitOptions()
{
	ApplyLang(document);
	document.title = GetText(AddonName);
	LoadX();
	ClickTab();
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		var Location = items[0].getAttribute("Location");
		if (!Location) {
			Location = Default;
		}
		for (var i = document.F2.elements.length - 1; i >= 0; i--) {
			if (Location == document.F2.elements[i].value) {
				document.F2.elements[i].checked = true;
			}
		}
	}
	var locs = new Array();
	items = external.Data["Locations"];
	for (var i in items) {
		var a = items[i].split("\t");
		info = GetAddonInfo(a[1]);
		var s = info.Name;
		if (locs[a[0]]) {
			locs[a[0]] += ', ' + s;
		}
		else {
			locs[a[0]] = s;
		}
	}
	for (var i in locs) {
		document.getElementById('_' + i).innerHTML = '<input type="text" value="' + locs[i].replace('"', "") + '" style="width: 85%">';
	}

}

function SetOptions()
{
	ConfirmX();
	SaveX();
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		var item = items[0];
		Location = Default;
		for (var i = document.F2.elements.length - 1; i >= 0; i--) {
			if (document.F2.elements[i].checked) {
				Location = document.F2.elements[i].value;
			}
		}
		item.setAttribute("Location", Location);
		returnValue = true;
	}
	window.close();
}

function LoadX()
{
	if (!g_List) {
		g_List = document.F.List;
		g_List.length = 0;
		var path = fso.GetParentFolderName(api.GetModuleFileName(null));
		var xml = external.Data["xml" + AddonName];
		if (!xml) {
			xml = external.CreateObject("Msxml2.DOMDocument");
			xml.async = false;
			xml.load(fso.BuildPath(path, "config\\" + AddonName + ".xml"));
			external.Data["xml" + AddonName] = xml;
		}

		var items = xml.getElementsByTagName("Item");
		var i = items.length;
		g_List.length = i;
		while (--i >= 0) {
			var item = items[i];
			SetData(g_List[i], new Array(item.getAttribute("Name"), item.text, item.getAttribute("Type")));
		}
		xml = null;
	}
}

function SaveX()
{
	if (g_Chg) {
		var xml = external.CreateObject("Msxml2.DOMDocument");
		xml.async = false;
		xml.appendChild(xml.createProcessingInstruction("xml", 'version="1.0" encoding="UTF-8"'));
		var root = xml.createElement("TablacusExplorer");
		var o = document.F.List;
		for (var i = 0; i < o.length; i++) {
			var item = xml.createElement("Item");
			var a = o[i].value.split(g_sep);
			item.setAttribute("Name", a[0]);
			item.text = a[1];
			item.setAttribute("Type", a[2]);
			root.appendChild(item);
		}
		xml.appendChild(root);
		SaveXmlEx(AddonName.toLowerCase() + ".xml", xml);
		external.Data["xml" + AddonName] = xml;
		xml = null;
	}
}

function SetData(sel, a)
{
	if (!a[0]) {
		return;
	}
	sel.value = PackData(a);
	sel.text = a[0];
}

function PackData(a)
{
	var i = a.length;
	while (--i >= 0) {
		a[i] = a[i].replace(g_sep, "`  ~");
	}
	return a.join(g_sep);
}

function ClearX()
{
	g_ChgData = false;
}

function ChangeX()
{
	g_ChgData = true;
}

function ConfirmX()
{
	if (g_ChgData && g_List.selectedIndex >= 0) {
		if (confirm(GetText("Do you want to replace?"))) {
			ReplaceX();
		}
		ClearX();
	}
}

function EditX()
{
	if (g_List.selectedIndex < 0) {
		return;
	}
	ClearX();
	var a = g_List[g_List.selectedIndex].value.split(g_sep);
	document.F.elements["Name"].value = a[0];
	document.F.elements["Path"].value = a[1];
	o = document.F.elements["Type"];
	i = o.length;
	while (--i >= 0) {
		if (o(i).value == a[2]) {
			o.selectedIndex = i;
			break;
		}
	}
}

function SwitchX()
{
	g_List.style.display = "none";
	g_List = document.F.elements[AddonName + o.value];
	g_List.style.display = "inline";
}

function AddX()
{
	g_List.selectedIndex = ++g_List.length - 1;
	ReplaceX(AddonName);
}

function ReplaceX()
{
	ClearX();
	if (g_List.selectedIndex < 0) {
		return;
	}
	var sel = g_List[g_List.selectedIndex];
	o = document.F.elements["Type"];
	SetData(sel, new Array(document.F.elements["Name"].value, document.F.elements["Path"].value, o[o.selectedIndex].value));
	g_Chg = true;
}

function RemoveX()
{
	ClearX();
	if (g_List.selectedIndex < 0 || !confirm(GetText("Are you sure?"))) {
		return;
	}
	g_List[g_List.selectedIndex] = null;
	g_Chg = true;
}

function MoveX(n)
{
	if (g_List.selectedIndex < 0 || g_List.selectedIndex + n < 0 || g_List.selectedIndex + n >= g_List.length) {
		return;
	}
	var src = g_List[g_List.selectedIndex];
	var dist = g_List[g_List.selectedIndex + n];
	var text = dist.text;
	var value = dist.value;
	dist.text = src.text;
	dist.value = src.value;
	src.text = text;
	src.value = value;
	g_List.selectedIndex += n;
	g_Chg = true;
}

function RefX(Id, bMultiLine)
{
	var commdlg = external.CommonDialog;
	var path = document.getElementById(Id).value;
	var te = fso.GetParentFolderName(api.GetModuleFileName(null));
	if (path.substr(0, 3) == "../") {
		path = te + (path.substr(2, MAXINT).replace(/\//g, "\\"));
	}
	commdlg.InitDir = path;
	commdlg.Filter = "All Files|*.*";
	commdlg.Flags = OFN_FILEMUSTEXIST;
	if (commdlg.ShowOpen()) {
		ChangeX();
		path = commdlg.FileName;
		if (Id == "Icon") {
			if (api.StrCmpI(te, path.substr(0, te.length)) == 0) {
				path = ".." + (path.substr(te.length, MAXINT).replace(/\\/g, "/"));
			}
		}
		else {
			path = api.PathQuoteSpaces(path);
		}
		if (bMultiLine) {
			AddPath(Id, path);
		}
		else {
			document.getElementById(Id).value = path;
		}
	}
}

function ClickTab(o)
{
	if (o) {
		nTabIndex = o.id.replace(new RegExp('tab', 'g'), '') - 0;
	}
	var i = 0;
	while (ovTab = document.getElementById('tab' + i)) {
		ovPanel = document.getElementById('panel' + i);
		if (i == nTabIndex) {
			setTimeout('BlurId("' + ovTab.id + '")', 100);
			ovTab.style.backgroundColor = '#ffffff';
			ovPanel.style.display = 'block';
			var h = document.body.clientHeight - 60;
			if (h > 0) {
				ovPanel.style.height = h;
			}
		}
		else {
			ovTab.style.backgroundColor = '';
			ovPanel.style.display = 'none';
		}
		i++;
	}
	nTabMax = i;
}

function WheelTab(o)
{
	nTabIndex -= event.wheelDelta / 120;
	while (nTabIndex < 0) {
		nTabIndex += nTabMax;
	}
	while (nTabIndex >= nTabMax) {
		nTabIndex -= nTabMax;
	}
	ClickTab();
}

