﻿var Addon_Id = "favoritesbar";
var Default = "LeftBar2";

if (Addon == 1) {
	window.g_FavBar = new Object();
	g_FavBar.ShowContextMenu = window.ShowContextMenu;
	g_FavBar.DragEnter = external.OnDragEnter;
	g_FavBar.DragOver = external.OnDragOver;
	g_FavBar.Drop = external.OnDrop;
	g_FavBar.DragLeave = external.OnDragleave;
	g_FavBar.AddFavorite = window.AddFavorite;

	if (!external.Data.Conf_LeftBarWidth) {
		external.Data.Conf_LeftBarWidth = 150;
	}
	var s = '<div id="' + Addon_Id + '" style="width: ' + external.Data.Conf_LeftBarWidth + 'px; height: 100%; background-color: window; border: 1px solid WindowFrame; overflow-x: hidden; overflow-y: auto;"></div>';
	SetAddon(Addon_Id, Default, s);
	ArrangeFav();

	window.ShowContextMenu = function (Ctrl, hwnd, msg, wParam, pt)
	{
		var menus = external.Data["xmlMenus"].getElementsByTagName('Favorites');
		if (menus && menus.length) {
			var items = menus[0].getElementsByTagName("Item");
			var i = GetFavFromPt(items.length, pt);
			if (i >= 0) {
				hMenu = api.CreatePopupMenu();
				var ContextMenu = api.ContextMenu(GetFavPath(items, i));
				if (ContextMenu) {
					ContextMenu.QueryContextMenu(hMenu, 0, 1, 0x7FFF, CMF_NORMAL);
					var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, external.hwnd, null, ContextMenu);
					if (nVerb) {
						ContextMenu.InvokeCommand(0, external.hwnd, nVerb - 1, null, null, SW_SHOWNORMAL, 0, 0);
					}
				}
				api.DestroyMenu(hMenu);
				return S_OK;
			}
		}
		if (g_FavBar.ShowContextMenu) {
			return g_FavBar.ShowContextMenu(Ctrl, hwnd, msg, wParam, pt);
		}
		return S_FALSE;
	}

	external.OnDragEnter = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = E_NOTIMPL;
		if (g_FavBar.DragEnter) {
			hr = g_FavBar.DragEnter(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		if (Ctrl.Type == CTRL_WB) {
			hr = S_OK;
		}
		return hr;
	}

	external.OnDragOver = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = S_OK;
		if (g_FavBar.DragOver) {
			hr = g_FavBar.DragOver(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		external.Data['grfKeyState'] = grfKeyState;
		var menus = external.Data["xmlMenus"].getElementsByTagName('Favorites');
		if (menus && menus.length) {
			var items = menus[0].getElementsByTagName("Item");
			var i = GetFavFromPt(items.length, pt);
			if (i >= 0) {
				hr = Exec(external, items[i].text, items[i].getAttribute("Type"), external.hwnd, pt, dataObj, external.Data['grfKeyState'], pdwEffect);
				if (hr == S_OK && pdwEffect.x) {
					MouseOver(document.getElementById("fav" + i));
				}
				return S_OK;
			}
		}
		if (HitTest(document.getElementById("favoritesbar"), pt) && dataObj.Count) {
			pdwEffect.x = DROPEFFECT_LINK;
			hr = S_OK;
		}
		MouseOut("fav");
		return hr;
	}

	external.OnDrop = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = S_OK;
		if (g_FavBar.Drop) {
			hr = g_FavBar.Drop(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		MouseOut();
		var menus = external.Data["xmlMenus"].getElementsByTagName('Favorites');
		if (menus && menus.length) {
			var items = menus[0].getElementsByTagName("Item");
			var i = GetFavFromPt(items.length + 1, pt);
			if (i >= 0) {
				return Exec(external, items[i].text, items[i].getAttribute("Type"), external.hwnd, pt, dataObj, external.Data['grfKeyState'], pdwEffect, true);
			}
		}
		if (HitTest(document.getElementById("favoritesbar"), pt) && dataObj.Count) {
			AddFavorite(dataObj.Item(0));
			hr = S_OK;
		}
		return hr;
	}
	external.OnDragleave = function (Ctrl)
	{
		var hr = S_OK;
		if (g_FavBar.DragLeave) {
			hr = g_FavBar.DragLeave(Ctrl);
		}
		MouseOut();
		return hr;
	}
	window.AddFavorite = function (o)
	{
		var r = false;
		if (g_FavBar.AddFavorite) {
			r = g_FavBar.AddFavorite(o);
		}
		if (r) {
			ArrangeFav();
		}
	}
}

function ArrangeFav()
{
	var s = "";
	var menus = external.Data["xmlMenus"].getElementsByTagName('Favorites');
	if (menus && menus.length) {
		var items = menus[0].getElementsByTagName("Item");
		var image = external.GdiplusBitmap;
		for (var i = 0; i < items.length; i++) {
			var strName = items[i].getAttribute("Name");
			if (strName == "-") {
				s += '<hr>';
			}
			else {
				var img = '';
				if (document.documentMode) { //IE8-
					var info = api.Memory("SHFILEINFO");
					var path = GetFavPath(items, i);
					var pidl = api.ILCreateFromPath(path);
					if (!pidl) {
						if (path.match(/"([^"]*)"/)) {
							pidl = api.ILCreateFromPath(RegExp.$1);
						}
						else if (path.match(/([^ ]*)/)) {
							pidl = api.ILCreateFromPath(RegExp.$1);
						}
					}
					if (pidl) {
						api.ShGetFileInfo(pidl, 0, info, info.Size, SHGFI_PIDL | SHGFI_ICON | SHGFI_SMALLICON);
						image.FromHICON(info.hIcon, api.GetSysColor(COLOR_BTNFACE));
						img = '<img src="data:image/png;base64,' + image.Base64("image/png" , info.hIcon) + '"> ';
						api.DestroyIcon(info.hIcon);
					}
				}
				else {
					var img = '<img src="../image/toolbar/s_3_3.png"> ';
					if (items[i].getAttribute("Type") != "Open") {
						img = '<img src="../image/toolbar/s_3_2.png"> ';
					}
				}
				s += '<div id="fav' + i + '" onclick="OpenFav(' + i + ')" onmouseover="MouseOver(this)" onmouseout="MouseOut()" class="button" title="' + items[i].text.replace(/"/g, "&quot;") + '" style="width: 100%">' + img + " " + strName.replace(/&/g, "") + '</div> ';
			}
		}
	}
	document.getElementById('favoritesbar').innerHTML = s;
}

function OpenFav(i)
{
	var menus = external.Data["xmlMenus"].getElementsByTagName("Favorites");
	if (menus && menus.length) {
		var items = menus[0].getElementsByTagName("Item");
		Exec(external, items[i].text, items[i].getAttribute("Type"), external.hwnd);
	}
}

function OpenFavOption()
{
	var Location = GetAddonLocation('FavoritesBar');
	if (showModalDialog("../addons/favoritesbar/options.html", window, "dialogWidth: 640px; dialogHeight: 480px; resizable: yes; status=0")) {
		if (Location == GetAddonLocation('FavBar')) {
			WriteFav();
			ApplyLang(document);
		}
		else {
//			SaveXmlEx("addons.xml", external.Data["Addons"]);
//			location.reload();
		}
	}
}

function GetFavFromPt(n, pt)
{
	while (--n >= 0) {
		if (HitTest(document.getElementById("fav" + n), pt)) {
			return n;
		}
	}
	return -1;
}

function GetFavPath(items, i)
{
	var line = items[i].text.split("\n");
	return api.PathUnquoteSpaces(ExtractMacro(null, line[0]));
}

