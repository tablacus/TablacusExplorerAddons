﻿var Addon_Id = "favoritesbar";
var Default = "LeftBar2";

if (!window.dialogArguments) {
	g_favbar =
	{
		DragEnter: te.OnDragEnter,
		DragOver: te.OnDragOver,
		Drop: te.OnDrop,
		DragLeave: te.OnDragleave,
		AddFavorite: window.AddFavorite,
		div: null,

		Init: function ()
		{
			var div = document.createElement("div");
			div.style.width = te.Data.Conf_LeftBarWidth + 'px';
			div.style.height = "100%";
			div.style.backgroundColor = "window";
			div.style.border = "1px solid WindowFrame";
			div.style.overflowX = "hidden";
			div.style.overflowY = "auto";
			SetAddon(Addon_Id, Default, div);
			this.div = div;
			this.Arrange();
		},

		Open: function (i)
		{
			var menus = te.Data.xmlMenus.getElementsByTagName("Favorites");
			if (menus && menus.length) {
				var items = menus[0].getElementsByTagName("Item");
				Exec(external, items[i].text, items[i].getAttribute("Type"), te.hwnd);
			}
		},

		Popup: function (i)
		{
			var menus = te.Data.xmlMenus.getElementsByTagName('Favorites');
			if (menus && menus.length) {
				var items = menus[0].getElementsByTagName("Item");
				if (i >= 0) {
					var hMenu = api.CreatePopupMenu();
					var ContextMenu = api.ContextMenu(this.GetPath(items, i));
					if (ContextMenu) {
						ContextMenu.QueryContextMenu(hMenu, 0, 0x1001, 0x7FFF, CMF_NORMAL);
						api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_SEPARATOR, 0, null);
					}
					api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_STRING, 1, GetText("&Edit"));
					var pt = api.Memory("POINT");
					api.GetCursorPos(pt);
					var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, te.hwnd, null, ContextMenu);
					if (nVerb >= 0x1001) {
						ContextMenu.InvokeCommand(0, te.hwnd, nVerb - 0x1001, null, null, SW_SHOWNORMAL, 0, 0);
					}
					if (nVerb == 1) {
						ShowOptions("Tab=Menus&Menus=Favorites");
					}
					api.DestroyMenu(hMenu);
				}
			}
		},

		Arrange: function ()
		{
			var s = "";
			var menus = te.Data.xmlMenus.getElementsByTagName('Favorites');
			if (menus && menus.length) {
				var items = menus[0].getElementsByTagName("Item");
				var image = te.GdiplusBitmap;
				for (var i = 0; i < items.length; i++) {
					var strName = items[i].getAttribute("Name");
					if (strName == "-") {
						s += '<div style="width: 100%; background-color: ActiveBorder; border: 2px solid window; font-size: 1px"></div>';
					}
					else {
						var img = '';
						if (document.documentMode) { //IE8-
							var info = api.Memory("SHFILEINFO");
							var path = this.GetPath(items, i);
							var pidl = api.ILCreateFromPath(path);
							if (!pidl) {
								if (path.match(/"([^"]*)"/)) {
									pidl = api.ILCreateFromPath(RegExp.$1);
								}
								else if (path.match(/([^ ]*)/)) {
									pidl = api.ILCreateFromPath(RegExp.$1);
								}
							}
							if (pidl) {
								api.ShGetFileInfo(pidl, 0, info, info.Size, SHGFI_PIDL | SHGFI_ICON | SHGFI_SMALLICON);
								image.FromHICON(info.hIcon, api.GetSysColor(COLOR_BTNFACE));
								img = '<img src="data:image/png;base64,' + image.Base64("image/png" , info.hIcon) + '"> ';
								api.DestroyIcon(info.hIcon);
							}
						}
						else {
							var img = '<img src="../image/toolbar/s_3_3.png"> ';
							if (items[i].getAttribute("Type") != "Open") {
								img = '<img src="../image/toolbar/s_3_2.png"> ';
							}
						}
						s += '<div id="fav' + i + '" onclick="g_favbar.Open(' + i + ')" oncontextmenu="g_favbar.Popup(' + i + '); return false" onmouseover="MouseOver(this)" onmouseout="MouseOut()" class="button" title="' + items[i].text.replace(/"/g, "&quot;") + '" style="width: 100%">' + img + " " + strName.replace(/&/g, "") + '</div> ';
					}
				}
			}
			g_favbar.div.innerHTML = s;
		},

		GetPath: function (items, i)
		{
			var line = items[i].text.split("\n");
			return api.PathUnquoteSpaces(ExtractMacro(null, line[0]));
		},

		FromPt: function (n, pt)
		{
			while (--n >= 0) {
				if (HitTest(document.getElementById("fav" + n), pt)) {
					return n;
				}
			}
			return -1;
		}

	};
	if (!te.Data.Conf_LeftBarWidth) {
		te.Data.Conf_LeftBarWidth = 150;
	}
	g_favbar.Init();

	te.OnDragEnter = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = g_favbar.DragEnter ? g_favbar.DragEnter(Ctrl, dataObj, grfKeyState, pt, pdwEffect) : E_FAIL;
		if (Ctrl.Type == CTRL_WB) {
			hr = S_OK;
		}
		return hr;
	}

	te.OnDragOver = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var menus = te.Data["xmlMenus"].getElementsByTagName('Favorites');
		if (menus && menus.length) {
			var items = menus[0].getElementsByTagName("Item");
			var i = g_favbar.FromPt(items.length, pt);
			if (i >= 0) {
				hr = Exec(external, items[i].text, items[i].getAttribute("Type"), te.hwnd, pt, dataObj, grfKeyState, pdwEffect);
				if (hr == S_OK && pdwEffect.x) {
					MouseOver(document.getElementById("fav" + i));
				}
				return S_OK;
			}
		}
		if (HitTest(g_favbar.div, pt) && dataObj.Count) {
			pdwEffect.x = DROPEFFECT_LINK;
			return S_OK;
		}
		MouseOut("fav");

		return g_favbar.DragOver ? g_favbar.DragOver(Ctrl, dataObj, grfKeyState, pt, pdwEffect) : E_FAIL;
	}

	te.OnDrop = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		MouseOut();
		var menus = te.Data.xmlMenus.getElementsByTagName('Favorites');
		if (menus && menus.length) {
			var items = menus[0].getElementsByTagName("Item");
			var i = g_favbar.FromPt(items.length + 1, pt);
			if (i >= 0) {
				return Exec(external, items[i].text, items[i].getAttribute("Type"), te.hwnd, pt, dataObj, grfKeyState, pdwEffect, true);
			}
		}
		if (HitTest(g_favbar.div, pt) && dataObj.Count) {
			AddFavorite(dataObj.Item(0));
			return S_OK;
		}

		return g_favbar.Drop ? g_favbar.Drop(Ctrl, dataObj, grfKeyState, pt, pdwEffect) : E_FAIL;
	}

	te.OnDragleave = function (Ctrl)
	{
		MouseOut();
		return g_favbar.DragLeave ? g_favbar.DragLeave(Ctrl) : S_OK;
	}

	window.AddFavorite = function (o)
	{
		var r = false;
		if (g_favbar.AddFavorite) {
			r = g_favbar.AddFavorite(o);
		}
		if (r) {
			g_favbar.Arrange();
		}
		return r;
	}
}
