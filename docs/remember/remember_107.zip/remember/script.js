﻿g_Remember =
{
	MAX: 1000,

	RememberFolder: function (FV)
	{
		if (FV && FV.Items) {
			var path = api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
			if (api.ILisEqual(path, FV.Data.Remember)) {
				te.Data.dbFolderView[path] = [new Date().getTime(), FV.CurrentViewMode, FV.IconSize, FV.Columns, FV.SortColumn, FV.FocusedItem];
			}
		}
		return S_OK;
	}
};

te.Data.dbFolderView = {};

var xmlfile = fso.BuildPath(te.Data.DataFolder, "config\\remember.xml");
var xml = te.CreateObject("Msxml2.DOMDocument");
xml.async = false;
xml.load(xmlfile);

var ID = ["Time", "ViewMode", "IconSize", "Columns", "SortColumn", "Focused", "Path"];
var items = xml.getElementsByTagName('Item');
for (i = items.length - 1; i >= 0; i--) {
	var item = items[i];
	var ar = new Array(ID.length);
	for (j = ID.length - 1; j >= 0; j--) {
		ar[j] = item.getAttribute(ID[j]);
	}
	te.Data.dbFolderView[ar.pop()] = ar;
}

AddEvent("BeforeNavigate", function (Ctrl, fs, wFlags, Prev)
{
	if (Ctrl.Type == CTRL_SB || Ctrl.Type == CTRL_EB) {
		if (Prev) {
			var path = api.GetDisplayNameOf(Prev, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
			te.Data.dbFolderView[path] = [new Date().getTime(), Ctrl.CurrentViewMode, Ctrl.IconSize, Ctrl.Columns, Ctrl.SortColumn, Ctrl.FocusedItem];
		}
		var path = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);

		var ar = te.Data.dbFolderView[path];
		if (ar) {
			fs.ViewMode = ar[1];
			fs.ImageSize = ar[2];
		}
		else if (Ctrl) {
			fs.ViewMode = Ctrl.CurrentViewMode;
			fs.ImageSize = Ctrl.IconSize;
			g_Remember.RememberFolder(Ctrl);
		}
	}
	return S_OK;
});

AddEvent("ListViewCreated", function (Ctrl)
{
	var path = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
	var ar = te.Data.dbFolderView[path];
	if (ar) {
		Ctrl.IconSize = ar[2];
		Ctrl.Columns = ar[3];
		Ctrl.SortColumn = ar[4];
		if (ar[5]) {
			Ctrl.SelectItem(ar[5], SVSI_FOCUSED | SVSI_ENSUREVISIBLE);
		}
		ar[0] = new Date().getTime();
	}
	Ctrl.Data.Remember = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
	return S_OK;
});

AddEvent("ChangeView", g_Remember.RememberFolder);

AddEvent("CloseView", g_Remember.RememberFolder);

AddEvent("Finalize", function ()
{
	g_Remember.RememberFolder(te.Ctrl(CTRL_FV));

	var arFV = [];
	for (path in te.Data.dbFolderView) {
		if (path) {
			var ar = te.Data.dbFolderView[path];
			ar.push(path);
			arFV.push(ar);
		}
	}

	arFV.sort(
		function(a, b) {
			return b[0] - a[0];
		}
	);

	arFV.splice(g_Remember.MAX, arFV.length);

	var xmlfile = fso.BuildPath(te.Data.DataFolder, "config\\remember.xml");
	var xml = CreateXml();
	var root = xml.createElement("TablacusExplorer");

	var ID = ["Time", "ViewMode", "IconSize", "Columns", "SortColumn", "Focused", "Path"];
	while (arFV.length) {
		var ar = arFV.shift()
		var item = xml.createElement("Item");
		for (j = ID.length - 1; j >= 0; j--) {
			item.setAttribute(ID[j], ar[j]);
		}
		root.appendChild(item);
	}
	xml.appendChild(root);
	xml.save(xmlfile);
});
