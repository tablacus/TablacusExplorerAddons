﻿if (Addon == 1) {
	MAX_REMEMBER_FOLDER = 1000;
	g_Remember_BeforeNavigate = external.OnBeforeNavigate;
	g_Remember_ListViewCreated = window.ListViewCreated;
	g_Remember_ChangeView = window.ChangeView;
	g_Remember_Finalize = window.Finalize;

	external.Data["dbFolderView"] = new Object();

	var xmlfile = fso.BuildPath(external.Data["DataFolder"], "config\\remember.xml");
	var xml = external.CreateObject("Msxml2.DOMDocument");
	xml.async = false;
	xml.load(xmlfile);

	var ID = ["Time", "ViewMode", "IconSize", "Columns", "SortColumn", "Path"];
	var items = xml.getElementsByTagName('Item');
	for (i = items.length - 1; i >= 0; i--) {
		var item = items[i];
		var ar = new Array(ID.length);
		for (j = ID.length - 1; j >= 0; j--) {
			ar[j] = item.getAttribute(ID[j]);
		}
		external.Data["dbFolderView"][ar.pop()] = ar;
	}
	xml = null;

	external.OnBeforeNavigate = function (Ctrl, fs, wFlags, Prev)
	{
		if (Prev) {
			var path = api.GetDisplayNameOf(Prev, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
			external.Data["dbFolderView"][path] = [new Date().getTime(), fs.ViewMode, fs.ImageSize, Ctrl.Columns, Ctrl.SortColumn];
		}
		path = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
		var ar = external.Data["dbFolderView"][path];
		if (ar) {
			fs.ViewMode = ar[1];
			fs.ImageSize = ar[2];
		}
		if (g_Remember_BeforeNavigate) {
			return g_Remember_BeforeNavigate(Ctrl, fs, wFlags, Prev);
		}
		return S_OK;
	}

	window.ListViewCreated = function (Ctrl)
	{
		var path = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
		var ar = external.Data["dbFolderView"][path];
		if (ar) {
			Ctrl.Columns = ar[3];
			Ctrl.SortColumn = ar[4];
			ar[0] = new Date().getTime();
		}
		if (g_Remember_ListViewCreated) {
			return g_Remember_ListViewCreated(Ctrl);
		}
		return S_OK;
	}

	window.ChangeView = function (Ctrl)
	{
		RememberFolder(Ctrl);
		if (g_Remember_ChangeView) {
			return g_Remember_ChangeView(Ctrl);
		}
		return S_OK;
	}

	window.Finalize = function ()
	{
		RememberFolder(external.Ctrl(CTRL_FV));

		var arFV = new Array();
		for (path in external.Data["dbFolderView"]) {
			var ar = external.Data["dbFolderView"][path];
			ar.push(path);
			arFV.push(ar)
		}

		arFV.sort(
			function(a, b) {
				return b[0] - a[0];
			}
		);
		arFV.splice(MAX_REMEMBER_FOLDER, arFV.length);

		var xmlfile = fso.BuildPath(external.Data["DataFolder"], "config\\remember.xml");
		var xml = external.CreateObject("Msxml2.DOMDocument");
		xml.async = false;

		xml.appendChild(xml.createProcessingInstruction("xml", 'version="1.0" encoding="UTF-8"'));

		var root = xml.createElement("TablacusExplorer");

		var ID = ["Time", "ViewMode", "IconSize", "Columns", "SortColumn", "Path"];
		while (arFV.length) {
			var ar = arFV.shift()
			var item = xml.createElement("Item");
			for (j = ID.length - 1; j >= 0; j--) {
				item.setAttribute(ID[j], ar[j]);
			}
			root.appendChild(item);
			item = null;
		}
		xml.appendChild(root);
		xml.save(xmlfile);
		xml = null;

		if (g_Remember_Finalize) {
			return g_Remember_Finalize();
		}
	}
}

function RememberFolder(FV)
{
	if (FV) {
		var path = api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
		external.Data["dbFolderView"][path] = [new Date().getTime(), FV.CurrentViewMode, FV.IconSize, FV.Columns, FV.SortColumn];
	}
}
