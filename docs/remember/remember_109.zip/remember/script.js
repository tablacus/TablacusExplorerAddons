if (window.Addon == 1) { (function () {
	Addons.Remember =
	{
		MAX: 1000,
		db: {},

		RememberFolder: function (FV)
		{
			if (FV && FV.Items) {
//				var path = api.GetDisplayNameOf(FV.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
//				if (api.ILisEqual(path, FV.Data.Remember)) {
//					Addons.Remember.db[path] = [new Date().getTime(), FV.CurrentViewMode, FV.IconSize, FV.Columns, FV.SortColumn, FV.FocusedItem];
//				}
			}
		}
	};

	var xml = OpenXml("remember.xml", true, false);
	if (xml) {
		var ID = ["Time", "ViewMode", "IconSize", "Columns", "SortColumn", "Focused", "Path"];
		var items = xml.getElementsByTagName('Item');
		for (i = items.length - 1; i >= 0; i--) {
			var item = items[i];
			var ar = new Array(ID.length);
			for (j = ID.length - 1; j >= 0; j--) {
				ar[j] = item.getAttribute(ID[j]);
			}
			if (ar[1]) {
				Addons.Remember.db[ar.pop()] = ar;
			}
		}
		xml = null;
	}

	AddEvent("BeforeNavigate", function (Ctrl, fs, wFlags, Prev)
	{
		if (Ctrl.Type == CTRL_SB || Ctrl.Type == CTRL_EB) {
			if (Prev) {
				var path = api.GetDisplayNameOf(Prev, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
				Addons.Remember.db[path] = [new Date().getTime(), Ctrl.CurrentViewMode, Ctrl.IconSize, Ctrl.Columns, Ctrl.SortColumn, Ctrl.FocusedItem];
			}
			var path = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);

			var ar = Addons.Remember.db[path];
			if (ar) {
				fs.ViewMode = ar[1];
				fs.ImageSize = ar[2];
			}
			else if (Ctrl && Ctrl.Items) {
				fs.ViewMode = Ctrl.CurrentViewMode;
				fs.ImageSize = Ctrl.IconSize;
			}
		}
	});

	AddEvent("ListViewCreated", function (Ctrl)
	{
		var path = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
		var ar = Addons.Remember.db[path];
		if (ar) {

			Ctrl.Columns = ar[3];
			Ctrl.SortColumn = ar[4];
			if (ar[5]) {
				Ctrl.SelectItem(ar[5], SVSI_FOCUSED | SVSI_ENSUREVISIBLE);
			}
			ar[0] = new Date().getTime();
		}
		Ctrl.Data.Remember = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
	});

	AddEvent("ChangeView", Addons.Remember.RememberFolder);

	AddEvent("CloseView", Addons.Remember.RememberFolder);

	AddEvent("Finalize", function ()
	{
		Addons.Remember.RememberFolder(te.Ctrl(CTRL_FV));

		var arFV = [];
		for (path in Addons.Remember.db) {
			if (path) {
				var ar = Addons.Remember.db[path];
				ar.push(path);
				arFV.push(ar);
			}
		}

		arFV.sort(
			function(a, b) {
				return b[0] - a[0];
			}
		);

		arFV.splice(Addons.Remember.MAX, arFV.length);

		var xml = CreateXml();
		var root = xml.createElement("TablacusExplorer");

		var ID = ["Time", "ViewMode", "IconSize", "Columns", "SortColumn", "Focused", "Path"];
		while (arFV.length) {
			var ar = arFV.shift()
			var item = xml.createElement("Item");
			for (j = ID.length - 1; j >= 0; j--) {
				item.setAttribute(ID[j], ar[j]);
			}
			root.appendChild(item);
		}
		xml.appendChild(root);
		SaveXmlEx("remember.xml", xml, true);
	});
})();}
