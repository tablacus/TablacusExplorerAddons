﻿if (Addon == 1) {
	window.ChangeTabName = function (Ctrl)
	{
		var s = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORPARSING | SHGDN_FORPARSINGEX);
		if (typeof(s) == "number") {
			s = api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_NORMAL);
		}
		else {
			var s2 = Ctrl.FolderItem.Name;
			if (s2.match(":")) {
				s = s2;
			}
			else {
				s = s2 + ' (' + fso.GetDriveName(s) + ')';
			}
		}
		Ctrl.Title = s.replace(/&/g, "&&");
	}
}
