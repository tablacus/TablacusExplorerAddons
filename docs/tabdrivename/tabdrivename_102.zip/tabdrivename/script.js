﻿if (window.Addon == 1) {
	AddEvent("GetTabName", function (Ctrl)
	{
		if (/^(\w):/.test(api.GetDisplayNameOf(Ctrl.FolderItem, SHGDN_FORADDRESSBAR | SHGDN_FORPARSING | SHGDN_FORPARSINGEX))) {
			var s = RegExp.$1;
			var s2 = Ctrl.FolderItem.Name;
			if (!/:/.test(s2)) {
				return [s2, ' (', s, ')'].join("");
			}
		}
	});
}
