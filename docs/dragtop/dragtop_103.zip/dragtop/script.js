if (window.Addon == 1) {
	const Addon_Id = "dragtop";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
