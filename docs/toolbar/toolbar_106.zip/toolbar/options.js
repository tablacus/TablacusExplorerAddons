var AddonName = "ToolBar";
var nTabIndex = 0;
var nTabMax = 0;
var g_List = null;

function InitToolOptions()
{
	ApplyLang(document);
	document.title = GetText(AddonName);
	LoadTB("List");
}

function SetToolOptions()
{
	ConfirmTB();
	SaveTB("List");
	TEOk();
	window.close();
}

function ShowLocation()
{
	showModelessDialog("../../script/location.html?toolbar", dialogArguments, 'dialogWidth: 640px; dialogHeight: 480px; resizable: yes; status=0;');
}

function ShowIcon()
{
	if (document.documentMode) {
		var s = showModalDialog("../../script/dialog.html?icon", dialogArguments, 'dialogWidth: 640px; dialogHeight: 480px; resizable: yes; status=0;');
		if (s) {
			document.F.Icon.value = s;
			ChangeX("List");
			SetImage();
		}
	}
}

function LoadTB(mode)
{
	if (!g_List) {
		LoadX(mode);
		g_List = g_x[mode];
	}
}

function SaveTB(mode)
{
	if (g_Chg[mode]) {
		var xml = CreateXml();
		var root = xml.createElement("TablacusExplorer");
		var o = document.F.List;
		for (var i = 0; i < o.length; i++) {
			var item = xml.createElement("Item");
			var a = o[i].value.split(g_sep);
			item.setAttribute("Name", a[0]);
			item.text = a[1];
			item.setAttribute("Type", a[2]);
			item.setAttribute("Icon", a[3]);
			item.setAttribute("Height", a[4]);
			root.appendChild(item);
		}
		xml.appendChild(root);
		SaveXmlEx(AddonName.toLowerCase() + ".xml", xml);
		te.Data["xml" + AddonName] = xml;
		xml = null;
	}
}

function EditTB(mode)
{
	if (g_List.selectedIndex < 0) {
		return;
	}
	ClearX("List");
	var a = g_List[g_List.selectedIndex].value.split(g_sep);
	SetType(document.F.Type, a[2]);
	var ix = ["Name", "Path", "Type", "Icon", "Height"];
	for (var i = ix.length - 1; i >= 0; i--) {
		if (i != 2) {
			document.F.elements[ix[i]].value = a[i];
		}
	}
	var p = { s: a[1] };
	MainWindow.OptionDecode(a[2], p);
	document.F.Path.value = p.s;
	SetImage();
}

function AddTB()
{
	g_List.selectedIndex = ++g_List.length - 1;
	ReplaceTB("List");
}

function ReplaceTB(mode)
{
	ClearX();
	if (g_List.selectedIndex < 0) {
		return;
	}
	var sel = g_List[g_List.selectedIndex];
	o = document.F.Type;
	var p = { s: document.F.Path.value };
	MainWindow.OptionEncode(o[o.selectedIndex].value, p);
	SetData(sel, new Array(document.F.Name.value, p.s, o[o.selectedIndex].value, document.F.Icon.value, document.F.Height.value));
	g_Chg[mode] = true;
}

function ConfirmTB()
{
	if (g_Chg.Data && g_x[g_Chg.Data].selectedIndex >= 0) {
		if (confirm(GetText("Do you want to replace?"))) {
			ReplaceTB(g_Chg.Data);
		}
		ClearX(g_Chg.Data);
	}
}

function SetImage()
{
	var icon = document.F.Icon.value;
	var image = te.GdiplusBitmap;
	var sh = "";
	var src = null;
	if(icon) {
		if (api.PathMatchSpec(icon, "*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.ico;data:*")) {
			src = icon;
		}
		else if (document.documentMode) { //IE8-
			var info = api.Memory("SHFILEINFO");
			var pidl = api.ILCreateFromPath(api.PathUnquoteSpaces(icon));
			if (pidl) {
				var uFlags = SHGFI_PIDL | SHGFI_ICON;
				if (h && h <= 16) {
					uFlags |= SHGFI_SMALLICON;
				}
				api.ShGetFileInfo(pidl, 0, info, info.Size, uFlags);
				image.FromHICON(info.hIcon, api.GetSysColor(COLOR_BTNFACE));
				src = image.DataURI("image/png", info.hIcon);
				api.DestroyIcon(info.hIcon);
			}
		}
	}
	if (src) {
		var h = api.LowPart(document.F.Height.value);
		document.getElementById("IconImage").innerHTML = '<img src="' + src + '" ' + (h ? 'height="' + h + 'px"' : "") + '>';
	}
	else {
		document.getElementById("IconImage").innerHTML = '';
	}
}
