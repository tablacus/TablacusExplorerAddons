﻿var Addon_Id = "toolbar";
var Default = "ToolBar2Left";

if (Addon == 1) {
	g_ToolBar_ShowContextMenu = window.ShowContextMenu;
	g_ToolBar_DragEnter = external.OnDragEnter;
	g_ToolBar_DragOver = external.OnDragOver;
	g_ToolBar_Drop = external.OnDrop;
	g_ToolBar_DragLeave = external.OnDragleave;

	var path = fso.GetParentFolderName(api.GetModuleFileName(null));
	var xml = external.CreateObject("Msxml2.DOMDocument");
	xml.async = false;

	xml.load(fso.BuildPath(path, "config\\toolbar.xml"));
	external.Data.xmlToolBar = xml;

	SetAddon(Addon_Id, Default, '<span id="_' + Addon_Id + '"></span>');
	ArrangeToolBar();

	window.ShowContextMenu = function (Ctrl, hwnd, msg, wParam, pt)
	{
		var items = external.Data["xmlToolBar"].getElementsByTagName("Item");
		var i = GetToolBarFromPt(items.length + 1, pt);
		if (i >= 0) {
			hMenu = api.CreatePopupMenu();
			var ContextMenu = null;
			if (i < items.length) {
				ContextMenu = api.ContextMenu(GetToolBarPath(items, i));
			}
			if (ContextMenu) {
				ContextMenu.QueryContextMenu(hMenu, 0, 0x1001, 0x7FFF, CMF_NORMAL);
				api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_SEPARATOR, 0, null);
			}
			api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_STRING, 1, GetText("&Edit"));

			var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, external.hwnd, null, ContextMenu);
			if (nVerb >= 0x1001) {
				ContextMenu.InvokeCommand(0, external.hwnd, nVerb - 0x1001, null, null, SW_SHOWNORMAL, 0, 0);
			}
			if (nVerb == 1) {
				OpenToolBarOption();
			}
			api.DestroyMenu(hMenu);
			return S_OK;
		}
		if (g_ToolBar_ShowContextMenu) {
			return g_ToolBar_ShowContextMenu(Ctrl, hwnd, msg, wParam, pt);
		}
		return S_FALSE;
	}

	external.OnDragEnter = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = E_NOTIMPL;
		if (g_ToolBar_DragEnter) {
			hr = g_ToolBar_DragEnter(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		if (Ctrl.Type == CTRL_WB) {
			hr = S_OK;
		}
		return hr;
	}

	external.OnDragOver = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = S_OK;
		if (g_ToolBar_DragOver) {
			hr = g_ToolBar_DragOver(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		external.Data['grfKeyState'] = grfKeyState;
		var items = external.Data["xmlToolBar"].getElementsByTagName("Item");
		var i = GetToolBarFromPt(items.length + 1, pt);
		if (i >= 0) {
			if (i == items.length) {
				pdwEffect.x = DROPEFFECT_LINK;
				MouseOver(document.getElementById("_toolbar" + i));
				return S_OK;
			}
			hr = Exec(external, items[i].text, items[i].getAttribute("Type"), external.hwnd, pt, dataObj, grfKeyState, pdwEffect);
			if (hr == S_OK && pdwEffect.x) {
				MouseOver(document.getElementById("_toolbar" + i));
			}
			return S_OK;
		}
		MouseOut("_toolbar");
		return hr;
	}

	external.OnDrop = function (Ctrl, dataObj, grfKeyState, pt, pdwEffect)
	{
		var hr = S_OK;
		if (g_ToolBar_Drop) {
			hr = g_ToolBar_Drop(Ctrl, dataObj, grfKeyState, pt, pdwEffect);
		}
		MouseOut();
		var items = external.Data["xmlToolBar"].getElementsByTagName("Item");
		var i = GetToolBarFromPt(items.length + 1, pt);
		if (i >= 0) {
			if (i == items.length) {
				var xml = external.Data["xmlToolBar"];
				var root = xml.documentElement;
				if (!root) {
					xml.appendChild(xml.createProcessingInstruction("xml", 'version="1.0" encoding="UTF-8"'));
					root = xml.createElement("TablacusExplorer");
					xml.appendChild(root);
				}
				if (root) {
					for (i = 0; i < dataObj.Count; i++) {
						var FolderItem = dataObj.Item(i);
						var item = xml.createElement("Item");
						item.setAttribute("Name", api.GetDisplayNameOf(FolderItem, SHGDN_INFOLDER));
						item.text = api.GetDisplayNameOf(FolderItem, SHGDN_FORPARSINGEX | SHGDN_FORPARSING);
						if (fso.FileExists(item.text)) {
							item.text = api.PathQuoteSpaces(item.text);
							item.setAttribute("Type", "Exec");
						}
						else {
							item.setAttribute("Type", "Open");
						}
						root.appendChild(item);
					}
					SaveXmlEx("toolbar.xml", xml);
					ArrangeToolBar();
					ApplyLang(document);
				}
				return S_OK;
			}
			return Exec(external, items[i].text, items[i].getAttribute("Type"), external.hwnd, pt, dataObj, grfKeyState, pdwEffect, true);
		}
		return hr;
	}
	external.OnDragleave = function (Ctrl)
	{
		var hr = S_OK;
		if (g_ToolBar_DragLeave) {
			hr = g_ToolBar_DragLeave(Ctrl);
		}
		MouseOut();
		return hr;
	}
}
function ArrangeToolBar()
{
	var s = "";
	var items = external.Data.xmlToolBar.getElementsByTagName("Item");
	var image = external.GdiplusBitmap;
	for (var i = 0; i < items.length; i++) {
		var img = items[i].getAttribute("Name");
		if (img == "/" || img == "//") {
			s += "<br>";
		}
		else {
			var icon = items[i].getAttribute("Icon");
			if (icon != "") {
				var h = items[i].getAttribute("Height").replace(/"/g, "");
				var sh = (h != "" ? ' height="' + h + '"' : '');
				h -= 0;
				if (api.PathMatchSpec(icon, "*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.ico")) {
					img = '<img src="' + icon + '"' + height + '>';
				}
				else if (document.documentMode) { //IE8-
					var info = api.Memory("SHFILEINFO");
					var pidl = api.ILCreateFromPath(api.PathUnquoteSpaces(icon));
					if (pidl) {
						var uFlags = SHGFI_PIDL | SHGFI_ICON;
						if (h && h <= 16) {
							uFlags |= SHGFI_SMALLICON;
						}
						api.ShGetFileInfo(pidl, 0, info, info.Size, uFlags);
						image.FromHICON(info.hIcon, api.GetSysColor(COLOR_BTNFACE));
						img = '<img src="data:image/png;base64,' + image.Base64("image/png" , info.hIcon) + '"' + sh + '>';
						api.DestroyIcon(info.hIcon);
					}
				}
			}
			s += '<span id="_toolbar' + i + '" onclick="OpenToolBar(' + i + ')" onmouseover="MouseOver(this)" onmouseout="MouseOut()" class="button" title="' + GetText(items[i].getAttribute("Name").replace(/"/g, "&quot;")) + '">' + img + '</span> ';
		}
	}
	if (items.length == 0) {
		s += '<label id="_toolbar' + items.length + '" title="Edit" onclick="OpenToolBarOption()"  onmouseover="MouseOver(this)" onmouseout="MouseOut()" class="button">';
		s += '<img src="../image/toolbar/s_2_22.png" bitmap="ieframe.dll,206,16,22"></label>';
	//	s += '+</label>';
	}
	document.getElementById('_toolbar').innerHTML = s;
}

function OpenToolBar(i)
{
	var items = external.Data["xmlToolBar"].getElementsByTagName("Item");
	Exec(external, items[i].text, items[i].getAttribute("Type"), external.hwnd, null);
}

function OpenToolBarOption()
{
	var Location = GetAddonLocation('toolbar');
	if (showModalDialog("../addons/toolbar/options.html", window, "dialogWidth: 640px; dialogHeight: 480px; resizable: yes; status=0")) {
		if (Location == GetAddonLocation('toolbar')) {
			ArrangeToolBar();
			ApplyLang(document);
		}
		else {
			SaveXmlEx("addons.xml", external.Data["Addons"]);
			location.reload();
		}
	}
}

function GetToolBarFromPt(n, pt)
{
	while (--n >= 0) {
		if (HitTest(document.getElementById("_toolbar" + n), pt)) {
			return n;
		}
	}
	return -1;
}

function GetToolBarPath(items, i)
{
	if (i < items.length) {
		var line = items[i].text.split("\n");
		return api.PathUnquoteSpaces(ExtractMacro(null, line[0]));
	}
	return '';
}

