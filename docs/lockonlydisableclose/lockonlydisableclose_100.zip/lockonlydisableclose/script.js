if (window.Addon == 1) {
	GetLock = function () {
		return false;
	}
}
