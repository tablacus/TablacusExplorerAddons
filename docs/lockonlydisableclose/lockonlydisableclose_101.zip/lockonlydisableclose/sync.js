GetLock = function () {
	return false;
}
