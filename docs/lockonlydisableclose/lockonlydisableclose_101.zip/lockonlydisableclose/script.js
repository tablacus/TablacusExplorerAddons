if (window.Addon == 1) {
	const Addon_Id = "lockonlydisableclose";
	$.importScript("addons\\" + Addon_Id + "\\sync.js");
}
