﻿var Addon_Id = "escape";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var n = 24;
	if (window.IconSize == 16) {
		n = 16;
	}
	var s = '<img alt="Escape Unicode" src="../addons/escape/' + n + '.png">';
	s = '<span class="button" onmousedown="PopupEscapeUnicode(this)" onmouseover="MouseOver(this)" onmouseout="MouseOut()">' + s + '</span> ';

	SetAddon(Addon_Id, Default, s);
}

function PopupEscapeUnicode(o)
{
	(function (o) { setTimeout(function () {
		hMenu = api.CreatePopupMenu();
		api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_STRING, 1, GetText("Escape Unicode"));
		api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_STRING, 2, GetText("Unescape Unicode"));
		var pt = GetPos(o, true);
		pt.y = pt.y + o.offsetHeight;
		var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, external.hwnd, null, null);
		api.DestroyMenu(hMenu);
		var s = "";
		if (nVerb) {
			var FV = external.Ctrl(CTRL_FV);
			var Items = FV.Items();
			var List = [];
			for (var i = 0; i < Items.Count; i++) {
				var Path =Items.Item(i).Path;
				var From = fso.GetFileName(Path);
				var To = EscapeFilename(From, nVerb);
				if (api.StrCmpI(From, To)) {
					List.push(From + "\0" + To + "\0" + fso.GetParentFolderName(Path));
				}
			}
			if (List.length) {
				var From = "";
				var To = "";
				var s = GetText("Are you sure?") + "\n";
				for (var i = 0; i < List.length; i++) {
					var Data = List[i].split(/\0/);
					s += Data[0] + ' -> ' + Data[1] + "\n";
					From += fso.BuildPath(Data[2], Data[0]) + "\0";
					To += fso.BuildPath(Data[2], Data[1]) + "\0";
				}
				if (confirm(s)) {
					fileop = api.Memory("SHFILEOPSTRUCT");
					fileop.wFunc = FO_MOVE;
					fileop.fFlags = FOF_MULTIDESTFILES | FOF_RENAMEONCOLLISION | FOF_ALLOWUNDO | FOF_NORECURSION;
					From += "\0";
					pFrom = api.Memory(api.SizeOf("WCHAR") * From.length);
					pFrom.Write(0, VT_LPWSTR, From, From.length);
					fileop.pFrom = pFrom.P;
					To += "\0";
					pTo = api.Memory(api.SizeOf("WCHAR") * To.length);
					pTo.Write(0, VT_LPWSTR, To, To.length);
					fileop.pTo = pTo.P;
					api.SHFileOperation(fileop);
				}
			}
		}
	}, 100);}) (o);
}

function EscapeFilename(uni, nMode)
{
	if (nMode == 2) {
		return unescape(uni);
	}
	var Mem = api.Memory(MAX_PATH);
	Mem.Write(0, VT_LPSTR, uni);
	for (var i = 1; i < MAX_PATH; i++) {
		var c = Mem.Read(i, VT_UI1);
		if (c == 0) {
			break;
		}
		if (c == 0x5c || c == 0x7c) {
			Mem.Write(i - 1, VT_UI1, 0x5c);
		}
	}
	var ansi = Mem.Read(0, VT_LPSTR).replace(/\\./g, "?");
	var enc = "";
	for (var i = 0; i < uni.length; i++) {
		if (ansi.charCodeAt(i) == uni.charCodeAt(i)) {
			enc += uni.charAt(i);
		}
		else {
			enc += escape(uni.charAt(i));
		}
	}
	return enc;
}
