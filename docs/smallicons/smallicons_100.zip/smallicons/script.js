﻿if (Addon == 1) {
	window.IconSize = 16;
}
