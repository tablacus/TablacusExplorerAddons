﻿var Addon_Id = "newtab";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var s;
	if (window.IconSize == 16) {
		s = '<img alt="New Tab" src="../image/toolbar/s_1_12.png" bitmap="ieframe.dll,216,16,12">';
	}
	else {
		s = '<img alt="New Tab" src="../image/toolbar/m_1_12.png" bitmap="ieframe.dll,214,24,12">';
	}
	s = '<span class="button" onclick="CreateTab()" onmouseover="MouseOver(this)" onmouseout="MouseOut()">' + s + '</span> ';

	SetAddon(Addon_Id, Default, s);
}
