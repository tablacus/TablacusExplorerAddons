﻿var Addon_Id = "newtab";
var Default = "ToolBar2Left";

if (Addon == 1) {
	var s;
	if (external.Data["Conf_IconSize"] == 16) {
		s = '<a href="#" onclick="this.blur(); CreateTab(); return false;" class="button"><input type="image" alt="New Tab" src="../image/toolbar/s_1_12.png" bitmap="ieframe.dll,216,16,12"></a> ';
	}
	else {
		s = '<a href="#" onclick="this.blur(); CreateTab(); return false;" class="button"><input type="image" alt="New Tab" src="../image/toolbar/m_1_12.png" bitmap="ieframe.dll,214,24,12"></a> ';
	}

	var Location = null;
	var items = external.Data["Addons"].getElementsByTagName(Addon_Id);
	if (items.length) {
		Location = items[0].getAttribute("Location");
	}
	if (!Location) {
		Location = Default;
	}
	var o = document.getElementById(Location);
	o.innerHTML += s;
	o.style.display = "block";
	external.Data["Locations"].push(Location + "\t" + Addon_Id);
}
