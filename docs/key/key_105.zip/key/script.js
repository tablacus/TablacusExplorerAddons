﻿g_Types.Key = ["All", "List", "Tree", "Browser"];

if (window.Addon == 1) {
	g_key = {};

	AddEvent("KeyMessage", function (Ctrl, hwnd, msg, key, keydata)
	{
		if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) {
			var nShift = 0;
			var n = 1;
			var vka = new Array(VK_SHIFT, VK_CONTROL, VK_MENU, VK_LWIN);
			for (var i in vka) {
				if (api.GetKeyState(vka[i]) < 0) {
					nShift += n;
				}
				n *= 2;
			}
			te.Data.cmdKey = nShift + "\t" + api.GetKeyNameText(keydata);
			var strKey = te.Data.cmdKey.toUpperCase();
			var cmd = g_key.All[strKey];
			if (cmd) {
				var a = cmd.split(g_sep);
				return Exec(Ctrl, a[0], a[1], hwnd, null);
			}
			switch (Ctrl.Type) {
				case CTRL_SB:
				case CTRL_EB:
					var strClass = api.GetClassName(hwnd);
					if (api.strcmpi(strClass, WC_LISTVIEW) == 0 || api.strcmpi(strClass, "DirectUIHWND") == 0) {
						var cmd = g_key.List[strKey];
						if (cmd) {
							var a = cmd.split(g_sep);
							return Exec(Ctrl, a[0], a[1], hwnd, null);
						}
					}
					break;
				case CTRL_TV:
					var strClass = api.GetClassName(hwnd);
					if (api.strcmpi(strClass, WC_TREEVIEW) == 0) {
						var cmd = g_key.Tree[strKey];
						if (cmd) {
							var a = cmd.split(g_sep);
							return Exec(Ctrl, a[0], a[1], hwnd, null);
						}
					}
					break;
				case CTRL_WB:
					var cmd = g_key.Browser[strKey];
					if (cmd) {
						var a = cmd.split(g_sep);
						return Exec(Ctrl, a[0], a[1], hwnd, null);
					}
					break;
				default:
					if (window.g_menu_click) {
						if (key == VK_RETURN) {
							var hSubMenu = api.GetSubMenu(window.g_menu_handle, window.g_menu_pos);
							if (hSubMenu) {
								var mii = api.Memory("MENUITEMINFO");
								mii.cbSize = mii.Size;
								mii.fMask = MIIM_SUBMENU;
								api.SetMenuItemInfo(window.g_menu_handle, window.g_menu_pos, true, mii);
								api.DestroyMenu(hSubMenu);
								api.PostMessage(hwnd, WM_CHAR, VK_LBUTTON, 0);
							}
							window.g_menu_button = api.GetKeyState(VK_SHIFT) >= 0 ? 1 : 2;
							if (api.GetKeyState(VK_CONTROL) < 0) {
								window.g_menu_button = 3;
							}
						}
					}
					break;
			}
		}
	});

	var xml = OpenXml("key.xml", false, true);
	for (t in g_Types.Key) {
		var mode = g_Types.Key[t];
		if (!g_key[mode]) {
			g_key[mode] = {};
		}
		var items = xml.getElementsByTagName(mode);
		if (items.length == 0 && api.strcmpi(mode, "List") == 0) {
			items = xml.getElementsByTagName("Folder");
		}
		for (i = 0; i < items.length; i++) {
			var item = items[i];
			var strKey = item.getAttribute("Key");
			SetKeyData(mode, strKey, item.text, item.getAttribute("Type"), "Key", g_key)
		}
	}
}
