﻿g_Types["Key"] = new Array("All", "List", "Tree", "Browser");

if (Addon == 1) {
	g_key_KeyMessage = external.OnKeyMessage;

	external.OnKeyMessage = function (Ctrl, hwnd, msg, key, keydata)
	{
		if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) {
			var nShift = 0;
			var n = 1;
			var vka = new Array(VK_SHIFT, VK_CONTROL, VK_MENU, VK_LWIN);
			for (var i in vka) {
				if (api.GetKeyState(vka[i]) < 0) {
					nShift += n;
				}
				n *= 2;
			}
			external.Data["cmdKey"] = nShift + "\t" + api.GetKeyNameText(keydata);
			var strKey = external.Data["cmdKey"].toUpperCase();
			var cmd = external.Data["KeyAll"][strKey];
			if (cmd) {
				var a = cmd.split(g_sep);
				return Exec(Ctrl, a[0], a[1], hwnd, null);
			}
			switch (Ctrl.Type) {
				case CTRL_SB:
				case CTRL_EB:
					var strClass = api.GetClassName(hwnd);
					if (strClass == WC_LISTVIEW || strClass == "DirectUIHWND") {
						var cmd = external.Data["KeyList"][strKey];
						if (cmd) {
							var a = cmd.split(g_sep);
							return Exec(Ctrl, a[0], a[1], hwnd, null);
						}
					}
					break;
				case CTRL_TV:
					var strClass = api.GetClassName(hwnd);
					if (strClass == WC_TREEVIEW) {
						var cmd = external.Data["KeyTree"][strKey];
						if (cmd) {
							var a = cmd.split(g_sep);
							return Exec(Ctrl, a[0], a[1], hwnd, null);
						}
					}
					break;
				case CTRL_WB:
					var cmd = external.Data["KeyBrowser"][strKey];
					if (cmd) {
						var a = cmd.split(g_sep);
						return Exec(Ctrl, a[0], a[1], hwnd, null);
					}
					break;
			}
		}
		if (g_key_KeyMessage) {
			return g_key_KeyMessage(Ctrl, hwnd, msg, key, keydata);
		}
		return S_FALSE;
	}

	var xml = OpenXml("key.xml", false, true);
	for (t in g_Types["Key"]) {
		external.Data["Key" + g_Types["Key"][t]] = new Array();
		var items = xml.getElementsByTagName(g_Types["Key"][t]);
		if (items.length == 0 && g_Types["Key"][t] == "List") {
			items = xml.getElementsByTagName("Folder");
		}
		for (i = 0; i < items.length; i++) {
			var item = items[i];
			var strKey = item.getAttribute("Key");
			SetKeyData(g_Types["Key"][t], strKey, item.text, item.getAttribute("Type"), "Key")
		}
	}
}
