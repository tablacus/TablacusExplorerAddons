﻿if (Addon == 1) {
	g_treeview_ChangeView = ChangeView;

	ChangeView = function(Ctrl)
	{
		if (Ctrl.FolderItem) {
			var TV = external.Ctrl(CTRL_TV);
			if (TV) {
				if (!api.ILIsEqual(Ctrl.FolderItem, TV.SelectedItem)) {
					TV.Expand(Ctrl.FolderItem, 1);
				}
			}
		}
		if (g_treeview_ChangeView) {
			return g_treeview_ChangeView(Ctrl);
		}
	}
}
