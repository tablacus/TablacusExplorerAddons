﻿var Addon_Id = "treeview";
var Default = "ToolBar2Left";

if (Addon == 1) {
	g_treeview_ChangeView = ChangeView;
	g_treeview_ShowContextMenu = window.ShowContextMenu;

	ChangeView = function(Ctrl)
	{
		if (Ctrl.FolderItem) {
			var TV = Ctrl.TreeView;
			if (TV) {
				if (!api.ILIsEqual(Ctrl.FolderItem, TV.SelectedItem)) {
					TV.Expand(Ctrl.FolderItem, 1);
				}
			}
		}
		if (g_treeview_ChangeView) {
			return g_treeview_ChangeView(Ctrl);
		}
	}
	var s;
	if (window.IconSize == 16) {
		s = '<img alt="Tree" src="../image/toolbar/m_1_43.png" bitmap="ieframe.dll,216,16,43">';
	}
	else {
		s = '<img alt="Tree" src="../image/toolbar/m_1_43.png" bitmap="ieframe.dll,214,24,43">';
	}
	s = '<span id="TreeViewButton" class="button" onclick="SwitchTreeView()" onmouseover="MouseOver(this)" onmouseout="MouseOut()">' + s + '</span> ';

	SetAddon(Addon_Id, Default, s);


	window.ShowContextMenu = function (Ctrl, hwnd, msg, wParam, pt)
	{
		var o = document.getElementById("TreeViewButton");
		if (HitTest(o, pt)) {
			var TV = external.Ctrl(CTRL_TV);
			if (TV) {
				hMenu = api.CreatePopupMenu();
				api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_STRING, 1, GetText("Width"));
				api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_STRING, 3, GetText("Auto"));
				api.InsertMenu(hMenu, MAXINT, MF_BYPOSITION | MF_STRING, 7, GetText("Left"));

				var nVerb = api.TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, external.hwnd, null, null);
				switch (nVerb) {
					case 1:	//Width
						var n = prompt(GetText("Width"), TV.Width);
						if (n) {
							TV.Width = n;
							TV.Align = TV.Align | 2;
						}
						break;
					case 3:	//Auto
					case 7:	//Left
						TV.Align = nVerb;
						break;
				}
				api.DestroyMenu(hMenu);
			}
			return S_OK;
		}
		if (g_treeview_ShowContextMenu) {
			return g_treeview_ShowContextMenu(Ctrl, hwnd, msg, wParam, pt);
		}
		return S_FALSE;
	}
}

function SwitchTreeView()
{
	TV = external.Ctrl(CTRL_TV);
	if (TV) {
		TV.Align = TV.Align ^ 2;
		if (TV.Width == 0 && TV.Align & 2) {
			TV.Width = 200;
		}
	}
}
