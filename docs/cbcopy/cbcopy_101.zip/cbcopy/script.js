﻿if (!window.dialogArguments) {
	g_cbcopy =
	{
		Command: te.OnCommand,
		OnInvokeCommand: te.OnInvokeCommand,

		Copy: function (Items)
		{
			var pdwEffect = Items.pdwEffect;
			if (pdwEffect) {
				pdwEffect.X = DROPEFFECT_COPY | DROPEFFECT_LINK;
			}
			api.OleSetClipboard(Items);
			return S_OK;
		}
	}

	te.OnCommand = function (Ctrl, hwnd, msg, wParam, lParam)
	{
		if (Ctrl.Type == CTRL_SB || Ctrl.Type == CTRL_EB) {
			if ((wParam & 0xfff) == CommandID_COPY - 1) {
				return g_cbcopy.Copy(Ctrl.SelectedItems);
			}
		}
		return g_cbcopy.Command ? g_cbcopy.Command(Ctrl, hwnd, msg, wParam, lParam) : S_FALSE;
	}

	te.OnInvokeCommand = function (ContextMenu, fMask, hwnd, Verb, Parameters, Directory, nShow, dwHotKey, hIcon)
	{
		if (Verb == CommandID_COPY - 1) {
			return g_cbcopy.Copy(ContextMenu.Items);
		}
		return g_cbcopy.OnInvokeCommand ? g_cbcopy.OnInvokeCommand(ContextMenu, fMask, hwnd, Verb, Parameters, Directory, nShow, dwHotKey, hIcon) : S_FALSE;
	}

	if (!ExtraMenus.Context) {
		ExtraMenus.Context = function (Ctrl, hMenu, nPos) {}
	}
}

