﻿if (Addon == 1) {
	g_cbcopy_Command = external.OnCommand;
	external.OnCommand = function (Ctrl, hwnd, msg, wParam, lParam)
	{
		if (Ctrl.Type == CTRL_SB || Ctrl.Type == CTRL_EB) {
			if ((wParam & 0xfff) == CommandID_COPY - 1) {
				CopyToClipboard(Ctrl.SelectedItems);
				return S_OK;
			}
		}
		if (g_cbcopy_Command) {
			return g_cbcopy_Command(Ctrl, hwnd, msg, wParam, lParam);
		}
		return S_FALSE;
	}

	g_cbcopy_OnInvokeCommand = external.OnInvokeCommand;
	external.OnInvokeCommand = function (ContextMenu, fMask, hwnd, Verb, Parameters, Directory, nShow, dwHotKey, hIcon)
	{
		if (Verb == CommandID_COPY - 1) {
			CopyToClipboard(ContextMenu.Items);
			return S_OK;
		}
		if (g_cbcopy_OnInvokeCommand) {
			return g_cbcopy_OnInvokeCommand(ContextMenu, fMask, hwnd, Verb, Parameters, Directory, nShow, dwHotKey, hIcon);
		}
		return S_FALSE;
	}
	if (!ExtraMenus["Context"]) {
		ExtraMenus["Context"] = function (Ctrl, hMenu, nPos) {}
	}
}

function CopyToClipboard(Items)
{
	var pdwEffect = Items.pdwEffect;
	if (pdwEffect) {
		pdwEffect.X = DROPEFFECT_COPY | DROPEFFECT_LINK;
	}
	api.OleSetClipboard(Items);
}
