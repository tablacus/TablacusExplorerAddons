﻿if (!window.dialogArguments) {
	g_extract = { Extract: window.Extract };

	Extract = function (Src, Dist)
	{
		var items = te.Data.Addons.getElementsByTagName("extract");
		if (items.length) {
			var item = items[0];
			var s = item.getAttribute("Path");
			if (s) {
				return wsh.Run(s.replace(/%src%/i, api.PathQuoteSpaces(Src)).replace(/%dist%/i, api.PathQuoteSpaces(Dist)), 1, true);
			}
		}
		return g_extract.Extract ? g_extract.Extract(Src, Dist) : E_FAIL;
	}
}
